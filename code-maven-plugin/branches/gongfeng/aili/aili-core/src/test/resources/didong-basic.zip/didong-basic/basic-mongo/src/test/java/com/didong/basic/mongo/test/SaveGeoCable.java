package com.didong.basic.mongo.test;

import java.util.concurrent.Callable;

import org.springframework.data.mongodb.core.MongoTemplate;

import com.alibaba.fastjson.JSON;
import com.didong.basic.mongo.test.bean.GeoOrderParamBean;

public class SaveGeoCable implements Callable<Integer>
{
    GeoOrderParamBean geoBean;
    MongoTemplate mongoTemplate;
	public GeoOrderParamBean getGeoBean() {
		return geoBean;
	}
	public void setGeoBean(GeoOrderParamBean geoBean) {
		this.geoBean = geoBean;
	}
	public MongoTemplate getMongoTemplate() {
		return mongoTemplate;
	}
	public void setMongoTemplate(MongoTemplate mongoTemplate) {
		this.mongoTemplate = mongoTemplate;
	}
	@Override
	public Integer call() throws Exception
	{
		try
		{
			System.out.println(JSON.toJSON(geoBean.getGps()));
			this.mongoTemplate.save(geoBean);
			return 1;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			return 0;
		}
	}

}
