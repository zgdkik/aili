package com.didong.basic.tools.other;



/**
 * 列表对象的过滤方法
 * @author wangyudong
 * @version   
 * @see       
 * @since
 */
public interface WhereCondition <T> {
    
    /**
     * 列表对象的过滤方法
     * @param bean 传入要检查的bean
     * @param index bean在列表beanList中的序号
     * @param beanList 被检查的列表
     * @return 
     *     如果要获取该对象，请返回bean对象。
     *     如果不想获取该对象，请返回空
     */
    public T filter(T bean , int index);

}
