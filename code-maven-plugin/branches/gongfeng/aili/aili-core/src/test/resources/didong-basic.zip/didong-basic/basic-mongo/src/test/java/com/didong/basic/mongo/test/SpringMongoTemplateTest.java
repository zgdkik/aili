package com.didong.basic.mongo.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.concurrent.CompletionService;
import java.util.concurrent.ExecutorCompletionService;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.GeoResult;
import org.springframework.data.geo.GeoResults;
import org.springframework.data.geo.Metrics;
import org.springframework.data.geo.Point;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.data.mongodb.gridfs.GridFsResource;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.didong.basic.mongo.test.bean.GeoOrderParamBean;
import com.didong.basic.mongo.test.bean.Gps;
import com.didong.basic.mongo.test.bean.SmsMessage;
import com.mongodb.BasicDBObject;
import com.mongodb.DBObject;
import com.mongodb.WriteResult;
import com.mongodb.gridfs.GridFSFile;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:mongo.xml")
public class SpringMongoTemplateTest extends AbstractJUnit4SpringContextTests 
{
    @Resource
    MongoTemplate mongoTemplate;
    @Resource
    GridFsTemplate gridFsTemplate;
	@Test
	public void testSaveText() throws Exception 
	{
		//短信内容
		SmsMessage sms = new SmsMessage();
		sms.setBizDesc("发货");
		sms.setContent("你好，你的快递包裹已经到达上海");
		sms.setPhoneNumbers("13917386691");
		sms.setStatus(0);
		sms.setCreateTime("2015-11-30 11:53:00");
		sms.setModifyTime("2015-11-30 11:53:00");
		sms.setSendTime("2015-11-30 11:53:00");
		for(int i=0;i<3;i++)
		{
			this.mongoTemplate.save(sms, "t_sms_message");
		}

	}
	
	@Test
	public void testFind()
	{
		Query query = new Query(Criteria.where("phoneNumbers").is("13917386691"));
		List<SmsMessage> msgList = this.mongoTemplate.find(query, SmsMessage.class,"t_sms_message");
		System.out.println(JSON.toJSONString(msgList));
	}
	
	@Test
	public void testUpdate()
	{
		Query query = new Query(Criteria.where("phoneNumbers").is("13917386691"));
		Update update = new Update();
		update.set("status", 1);
		//只更新第1条
		//WriteResult wr = this.mongoTemplate.updateFirst(query, update, "t_sms_message");
		//更新多条
		WriteResult wr = this.mongoTemplate.updateMulti(query, update, "t_sms_message");
		System.out.println(JSON.toJSONString(wr));
	}
	
	@Test
	public void testDel()
	{
		Query query = new Query(Criteria.where("phoneNumbers").is("13917386691"));
		WriteResult wr = this.mongoTemplate.remove(query, "t_sms_message");
		System.out.println(JSON.toJSONString(wr));
	}
	
	@Test
	public void testDrop()
	{
		this.mongoTemplate.dropCollection("t_sms_message");
	}
	
	
	@Test
	public void testSaveFile() throws Exception
	{
		String path = "src/test/resources/10221655592645877.jpg";
		GridFSFile fs = this.gridFsTemplate.store(new FileInputStream(path), "test.jpg");
		System.out.println(JSON.toJSONString(fs));
	}
	
	@Test
	public void testDowloadFile() throws Exception
	{
		String fileName = "test.jpg";
		GridFsResource fs = this.gridFsTemplate.getResource(fileName);
		String output = "d:/test.jpg";
		InputStream in = fs.getInputStream();
		int size = -1;
		byte[] buff = new byte[8*1024];
		OutputStream opf = new FileOutputStream(output);
		while((size = in.read(buff))!=-1)
		{
			opf.write(buff, 0, size);
		}
		in.close();
		opf.close();
	}
	
	
	@Test
	public void testGeoNear()
	{
		double lng = 121.0001225;
		double lat = 30.6948575;
		Point p = new Point(lat,lng);
		Distance dis = new Distance(10,Metrics.KILOMETERS);
        Query q = new Query(Criteria.where("isActive").is(1));
        NearQuery query = NearQuery.near(p).query(q).maxDistance(dis).num(400).spherical(false).skip(300);
        
        
//      List<GeoOrderParamBean> list = this.mongoTemplate.find(q, GeoOrderParamBean.class);
		GeoResults<GeoOrderParamBean> results = this.mongoTemplate.geoNear(query, GeoOrderParamBean.class,"t_geo_order");
		List<GeoResult<GeoOrderParamBean>> geoList = results.getContent();
		if(!CollectionUtils.isEmpty(geoList))
		{
			for(GeoResult<GeoOrderParamBean> geo:geoList)
			{
				//距离
				double distance = geo.getDistance().getValue();
				//数据信息
				GeoOrderParamBean value = geo.getContent();
			}
		}
	}
	
	
	@Test
	public void testInitGeo() throws Exception
	{
		//200W数据
		int size = 2000000;
		double minLat=30.694735;
		double maxLat=31.684735;
		double minLng=121.000000;
		double maxLng=121.990000;
		//线程数
		int poolSize = 200;
        ExecutorService pool = null;
        pool = Executors.newFixedThreadPool(poolSize);
        CompletionService<Integer> competionService = new ExecutorCompletionService<Integer>(
                pool);
        for(int i=0;i<size;i++)
        {
        	SaveGeoCable cable = new SaveGeoCable();
        	GeoOrderParamBean geo = new GeoOrderParamBean();
        	cable.setGeoBean(geo);
        	cable.setMongoTemplate(mongoTemplate);
        	//相关信息
        	geo.setId(BigInteger.valueOf(i));
        	geo.setConsigneeAddress("上海市 上海市 浦东新区广兰路780-临"+i+"号");
        	geo.setIsActive(1);
        	geo.setPickUpAddress("上海市 上海市 浦东新区鹤永路"+i+"号");
        	geo.setPkgCount(1);
        	geo.setReturnAmount(BigDecimal.valueOf(20));
        	Gps gps = new Gps();
        	double lat=minLat+i*0.0000005;
        	double lng=minLng+i*0.0000005;
        	gps.setLat(lat<=maxLat?lat:minLat+(i-1000)*0.000001);
        	gps.setLng(lng<maxLng?lng:minLng+(i-1000)*0.000001);
        	geo.setGps(gps);
        	//提交到线程池
        	competionService.submit(cable);
        }
        
        //获得结果
        long sum = 0;
        for(int i=0;i<size;i++)
        {
        	Integer result = competionService.take().get();
        	sum +=result;
        	System.out.println(sum);
        }
	}
	
	
	@Test
	public void testUpdateMongo()
	{
		Update update = new Update();
		update.set("_class", "com.didong.server.api.parambean.GeoOrderParamBean");
		this.mongoTemplate.updateMulti(null, update, "t_geo_order");
	}
	
	@Test
	public void test22()
	{
		DBObject stats = new BasicDBObject();
		Double dd = (Double) stats.get("avgDistance");
		Double averageDistanceObj = (stats == null ? Double.valueOf(0) : dd);
		double averageDistance = averageDistanceObj==null?0:averageDistanceObj;
	}

}
