package com.didong.basic.gis.server.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.didong.basic.gis.server.constant.GisConstant;

/**
 * 系统名称：递咚APP-开发平台
 * 模块名称：
 * 模块描述：获取地址经纬度工具类
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年12月19日 下午4:56:31
 * 模块路径：com.didong.basic.gis.server.util.AddrLngLatUtil
 * 更新记录：
 */
public class AddrLngLatUtil {
	
	private static Logger looger = LoggerFactory.getLogger(AddrLngLatUtil.class);

	/**
	 * 功能描述：获取指定地址经纬度
	 * 模块作者：zouyong
	 * 开发时间：2015年12月19日 下午5:15:27
	 * 更新记录：
	 * 返回数据：Map<String,Double>
	 */
	public static Map<String, Double> getLngAndLatByAddr(String address) {

		Map<String, Double> map = new HashMap<String, Double>();
		if(null != address && !"".equals(address)) {
			String url = GisConstant.BAIDU_MAL_REQ_URL.replace(GisConstant.BAIDU_MAP_ADDR, address);
			String json = loadJSON(url);
			JSONObject obj = JSONObject.parseObject(json);
			if (null != obj && "0".equals(obj.get("status").toString())) {
				double lng = obj.getJSONObject("result").getJSONObject("location")
						.getDouble(GisConstant.LONGITUDE);
				double lat = obj.getJSONObject("result").getJSONObject("location")
						.getDouble(GisConstant.LATITUDE);
				map.put(GisConstant.LONGITUDE, lng);
				map.put(GisConstant.LATITUDE, lat);
			} else {
				looger.info("未找到相匹配的经纬度！Address：" + address + "！");
			}
		}
		return map;
	}

	/**
	 * 功能描述：请求百度地图API获取经纬度信息
	 * 模块作者：zouyong
	 * 开发时间：2015年12月19日 下午5:12:16
	 * 更新记录：
	 * 返回数据：String
	 */
	public static String loadJSON(String url) {
		StringBuilder json = new StringBuilder();
		BufferedReader in = null;
		try {
			URL oracle = new URL(url);
			URLConnection yc = oracle.openConnection();
			in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
			String inputLine = null;
			while ((inputLine = in.readLine()) != null) {
				json.append(inputLine);
			}
		} catch (MalformedURLException e) {
			e.printStackTrace();
			looger.info("请求百度地图API获取经纬度信息失败！" + e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			looger.info("请求百度地图API获取经纬度信息失败！" + e.getMessage());
		} finally {
			if(null != in) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return json.toString();
	}
	
	public static void main(String[] args) {
		
		Map<String,Double> map = getLngAndLatByAddr("上海市长江南路180号");
		System.out.println("经度："+map.get(GisConstant.LONGITUDE)+"---纬度："+map.get(GisConstant.LATITUDE));

//		Thread one = new Thread(new Runnable() {
//            public void run(){
//            	for(int i=0; i<10000; i++) {
//        			int size = i+1;
//        			Map<String,Double> map = getLngAndLat("上海市长江南路"+size+"号");
//        			System.out.println("线程1：==经度："+map.get("lng")+"---纬度："+map.get("lat")+"---第" + 
//        					size + "次请求！");
//        		}
//            }
//		});  
//		one.start();
//		
//		Thread two = new Thread(new Runnable() {
//            public void run(){
//            	for(int i=0; i<10000; i++) {
//        			int size = i+1;
//        			Map<String,Double> map = getLngAndLat("上海市长江南路"+size+"号");
//        			System.out.println("线程2：==经度："+map.get("lng")+"---纬度："+map.get("lat")+"---第" + 
//        					size + "次请求！");
//        		}
//            }
//		});  
//		two.start();
//		
//		Thread three = new Thread(new Runnable() {
//            public void run(){
//            	for(int i=0; i<10000; i++) {
//        			int size = i+1;
//        			Map<String,Double> map = getLngAndLat("上海市长江南路"+size+"号");
//        			System.out.println("线程3：==经度："+map.get("lng")+"---纬度："+map.get("lat")+"---第" + 
//        					size + "次请求！");
//        		}
//            }
//		});  
//		three.start();
//		
//		Thread four = new Thread(new Runnable() {
//            public void run(){
//            	for(int i=0; i<10000; i++) {
//        			int size = i+1;
//        			Map<String,Double> map = getLngAndLat("上海市长江南路"+size+"号");
//        			System.out.println("线程4：==经度："+map.get("lng")+"---纬度："+map.get("lat")+"---第" + 
//        					size + "次请求！");
//        		}
//            }
//		});  
//		four.start();
//		
//		Thread five = new Thread(new Runnable() {
//            public void run(){
//            	for(int i=0; i<10000; i++) {
//        			int size = i+1;
//        			Map<String,Double> map = getLngAndLat("上海市长江南路"+size+"号");
//        			System.out.println("线程5：==经度："+map.get("lng")+"---纬度："+map.get("lat")+"---第" + 
//        					size + "次请求！");
//        		}
//            }
//		});  
//		five.start();
	
	}

}
