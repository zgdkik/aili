package com.didong.basic.data_cache.compensation;

import java.util.List;
import java.util.Map;

import com.didong.basic.data_cache.bean.AppCache;

/**
 * 
 * @ClassName:CompensationMeasure
 * @author: 韩旺坤
 * @Description:当缓存中查不到数据时的补偿措施，如从数据库获取，从接口获取等
 * @date:2015年10月26日 上午12:05:57
 */
public interface CompensationMeasure
{
   /**
    * 
    * @Title:getCompensationData
    * @Description:补偿措施
    * @param type
    * @param key->传入参数
    * @param searchURL->查找时的URL，如果是从数据库查找，那么它是SQL；如果从接口查找，它是接口地址
    * @return
    * List
    * @throws
    */
   public <T> List<T> getCompensationData(AppCache cache,Map<String,String> key,Class<T> clazz);
}
