package com.didong.basic.gis.test;

import java.text.DecimalFormat;

public class DistanceCalcTest {

	private static double EARTH_RADIUS = 6378.137;

	private static double rad(double d) {
		return d * Math.PI / 180.0;
	}

	/**
	 * 计算两个经纬度之间的距离
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		
		// X-经度-121.435006 Y-纬度-31.40956
		// X-经度-121.491931 Y-纬度-31.339941
		double y1 = 31.40956;
		double x1 = 121.435006;
		
		double y2 = 31.339941;
		double x2 = 121.491931;
		
		double jieguo = GetDistance(y1, x1, y2, x2);
		double jieguo2 = jieguo * 1000;
		double jieguo3 = Math.round(jieguo2);
		DecimalFormat df = new DecimalFormat("#####0.0");
		DecimalFormat dfa = new DecimalFormat("#####0");
		
		System.out.println(Double.valueOf(500 / 1000));
		System.out.println(jieguo3+"...............");
		if (jieguo3 >= 1000) {
			System.out.println(df.format(jieguo3 / 1000) + "公里");
		} else {
			System.out.println(dfa.format(jieguo3) + "米");
		}
	}
	
	public static double GetDistance(double y1, double x1, double y2, double x2) {
		
	   double radLat1 = rad(y1);
	   double radLat2 = rad(y2);
	   double a = radLat1 - radLat2;
	   double b = rad(x1) - rad(x2);
	   double s = 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a/2),2) + 
	   Math.cos(radLat1)*Math.cos(radLat2)*Math.pow(Math.sin(b/2),2)));
	   s = s * EARTH_RADIUS;
	   return s;
	}

}
