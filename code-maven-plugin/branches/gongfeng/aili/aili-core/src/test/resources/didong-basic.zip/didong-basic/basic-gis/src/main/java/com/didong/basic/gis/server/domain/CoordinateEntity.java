package com.didong.basic.gis.server.domain;

import java.io.Serializable;
import java.sql.Date;

/**
 * 系统名称：车辆运输跟踪系统（TTS）
 * 模块名称：
 * 模块描述：坐标信息实体
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2016年1月1日 下午10:52:16
 * 模块路径：com.didong.basic.gis.server.domain.CoordinateEntity
 * 更新记录：
 */
public class CoordinateEntity implements Serializable {

	/**
	 * 序列化ID
	 */
	private static final long serialVersionUID = 1681927930922114158L;
	
	// 主键唯一值
	private Integer id;
	
	// 区域分块编码
	private String code;

	// 最小纬度
	private double minLat;
	
	// 最大纬度
	private double maxLat;
	
	// 最小经度
	private double minLng;
	
	// 最大经度
	private double maxLng;

	// 截止纬度
	private double endLat;
	
	// 截止纬度
	private double endLng;
	
	// 城市编码
	private String cityCode;
	
	// 城市名称
	private String cityName;
	
	// 是否可用：Y-可用、N-禁用
	private String active;
	
	// 创建日期
	private Date createDate;
	
	// 创建人
	private String createUser;
	
	// 修改日期
	private Date modifyDate;
	
	// 修改人
	private String modifyUser;

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the code
	 */
	public String getCode() {
		return code;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param code the code to set
	 */
	public void setCode(String code) {
		this.code = code;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the minLat
	 */
	public double getMinLat() {
		return minLat;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param minLat the minLat to set
	 */
	public void setMinLat(double minLat) {
		this.minLat = minLat;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the maxLat
	 */
	public double getMaxLat() {
		return maxLat;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param maxLat the maxLat to set
	 */
	public void setMaxLat(double maxLat) {
		this.maxLat = maxLat;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the minLng
	 */
	public double getMinLng() {
		return minLng;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param minLng the minLng to set
	 */
	public void setMinLng(double minLng) {
		this.minLng = minLng;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the maxLng
	 */
	public double getMaxLng() {
		return maxLng;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param maxLng the maxLng to set
	 */
	public void setMaxLng(double maxLng) {
		this.maxLng = maxLng;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the endLat
	 */
	public double getEndLat() {
		return endLat;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param endLat the endLat to set
	 */
	public void setEndLat(double endLat) {
		this.endLat = endLat;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the endLng
	 */
	public double getEndLng() {
		return endLng;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param endLng the endLng to set
	 */
	public void setEndLng(double endLng) {
		this.endLng = endLng;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the cityCode
	 */
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the active
	 */
	public String getActive() {
		return active;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param active the active to set
	 */
	public void setActive(String active) {
		this.active = active;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the createDate
	 */
	public Date getCreateDate() {
		return createDate;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param createDate the createDate to set
	 */
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the createUser
	 */
	public String getCreateUser() {
		return createUser;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param createUser the createUser to set
	 */
	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the modifyDate
	 */
	public Date getModifyDate() {
		return modifyDate;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param modifyDate the modifyDate to set
	 */
	public void setModifyDate(Date modifyDate) {
		this.modifyDate = modifyDate;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @return the modifyUser
	 */
	public String getModifyUser() {
		return modifyUser;
	}

	/**
	 * 作者：zouyong
	 * 时间：2016年1月2日 上午11:36:09
	 * @param modifyUser the modifyUser to set
	 */
	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

}


