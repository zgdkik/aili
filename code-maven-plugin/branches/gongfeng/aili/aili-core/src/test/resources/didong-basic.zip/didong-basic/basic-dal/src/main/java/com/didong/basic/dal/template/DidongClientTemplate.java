package com.didong.basic.dal.template;

import org.mybatis.spring.SqlSessionTemplate;

/**
 *  设置数据源及其对应的namespace
 * @author han
 *
 */
public class DidongClientTemplate
{
	 /*
	  *  mapper文件中的命名空间
	  */
     String namespace;
     
     /*
      * 与数据源对应的数据库操作信息
      */
     SqlSessionTemplate sqlTemplate;


     
     /**
      * set 与 get 方法
      */
 	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace.toLowerCase();
	}

	public SqlSessionTemplate getSqlTemplate() {
		return sqlTemplate;
	}

	public void setSqlTemplate(SqlSessionTemplate sqlTemplate) {
		this.sqlTemplate = sqlTemplate;
	}
	
}
