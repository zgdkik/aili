package com.didong.basic.dal.daoimpl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.CollectionUtils;

import com.alibaba.druid.util.StringUtils;
import com.alibaba.fastjson.JSON;
import com.didong.basic.dal.BaseDao;
import com.didong.basic.dal.template.DidongClientTemplate;
import com.didong.basic.dal.util.DataSourceInitionUtil;
import com.didong.basic.zk.manage.ZkReader;

/**
 *  针对分库与未分库的数据源进行统一操作操作
 * @author han
 */
public class CommonBaseDao implements BaseDao,InitializingBean
{
	private static Logger LOG = LoggerFactory.getLogger(CommonBaseDao.class);
	private Resource mybatisConfig;  //mybatis.xml文件的位置
	private String appCode;
	private String moduleCode;
	private String envCode;
	private ZkReader zkReader;
	
	
    public ZkReader getZkReader() {
		return zkReader;
	}

	public void setZkReader(ZkReader zkReader) {
		this.zkReader = zkReader;
	}

	public String getEnvCode() {
		return envCode;
	}

	public void setEnvCode(String envCode) {
		this.envCode = envCode;
	}

	public Resource getMybatisConfig() {
		return mybatisConfig;
	}

	public void setMybatisConfig(Resource mybatisConfig) {
		this.mybatisConfig = mybatisConfig;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	private List<DidongClientTemplate> templateList;
    
	public List<DidongClientTemplate> getTemplateList() 
	{
		return templateList;
	}

	public void setTemplateList(List<DidongClientTemplate> templateList)
	{
		this.templateList = templateList;
	}
	
	/**
	 *  获得指定的template来进行数据库操作
	 * @param statement
	 * @return
	 */
	private SqlSessionTemplate getTemplate(String statement)
	{
        if(statement == null || statement.trim().equals(""))
        {
            throw new RuntimeException("执行数据库操作时【未填写】mapper文件中的SQL的ID信息");
        }
        LOG.info("SQL Statement ID is : "+statement);
        //提取namespace信息
        statement = statement.toLowerCase();  //转换为小写
		String namespace= statement.substring(0, statement.indexOf("."));
		if(StringUtils.isEmpty(namespace))
		{
            throw new RuntimeException("执行数据库操作时:SQL的ID信息未包含namespace信息");
		}
		//根据命令空间查找对应的template
		SqlSessionTemplate result = null;
		for(DidongClientTemplate template:this.templateList)
		{
			if(namespace.trim().equals(template.getNamespace()))
			{
				result = template.getSqlTemplate();
				break;
			}
		}
		if(result != null)
		{
			return result;
		}
		else
		{
            throw new RuntimeException("执行数据库操作时:路由不到相应的数据库，请检查namespace是否填写正确");
		}

	}
	
	@Override
	public <T> T selectOne(String statement)
	{
		return this.getTemplate(statement).selectOne(statement);
	}

	@Override
	public <T> T selectOne(String statement, Object parameter) 
	{
		return this.getTemplate(statement).selectOne(statement, parameter);
	}

	@Override
	public <K, V> Map<K, V> selectMap(String statement, String mapKey)
	{
		return this.getTemplate(statement).selectMap(statement,mapKey);
	}

	@Override
	public <K, V> Map<K, V> selectMap(String statement, Object parameter,
			String mapKey) 
	{
		return this.getTemplate(statement).selectMap(statement, parameter, mapKey);
	}

	@Override
	public <K, V> Map<K, V> selectMap(String statement, Object parameter,
			String mapKey, RowBounds rowBounds)
	{
		return this.getTemplate(statement).selectMap(statement, parameter, mapKey, rowBounds);
	}

	@Override
	public <E> List<E> selectList(String statement)
	{
		return this.getTemplate(statement).selectList(statement);
	}

	@Override
	public <E> List<E> selectList(String statement, Object parameter)
	{
		return this.getTemplate(statement).selectList(statement, parameter);
	}

	@Override
	public <E> List<E> selectList(String statement, Object parameter,
			RowBounds rowBounds)
	{
		return this.getTemplate(statement).selectList(statement, parameter, rowBounds);
	}

	@Override
	public void select(String statement, ResultHandler handler)
	{
		this.getTemplate(statement).select(statement, handler);
	}

	@Override
	public void select(String statement, Object parameter, ResultHandler handler)
	{
		this.getTemplate(statement).select(statement, parameter, handler);
	}

	@Override
	public int insert(String statement)
	{
		return this.getTemplate(statement).insert(statement);
	}

	@Override
	public int insert(String statement, Object parameter)
	{
		return this.getTemplate(statement).insert(statement, parameter);
	}

	@Override
	public int insertBatch(String statement, List<?> parameterList,
			int batchSize)
	{
        int count = 0;
        List<Object> templist = new ArrayList<Object>();
        for(int i=0 ; i<parameterList.size()  ; i++){
            templist.add(parameterList.get(i));
            if(templist.size()==batchSize || ((i+1)==parameterList.size() && templist.size()>0) ){
                count += this.insert(statement, templist);
                templist.clear();
            }
        }
        return count;
	}

	@Override
	public int update(String statement)
	{
		return this.getTemplate(statement).update(statement);
	}

	@Override
	public int update(String statement, Object parameter)
	{
		return this.getTemplate(statement).update(statement, parameter);
	}

	@Override
	public int delete(String statement)
	{
		return this.getTemplate(statement).delete(statement);
	}

	@Override
	public int delete(String statement, Object parameter) 
	{
		return this.getTemplate(statement).delete(statement, parameter);
	}

	//在这里面把DidongClientTemplate对象创建出来
	@Override
	public void afterPropertiesSet() throws Exception
	{
		List<Properties> props = getParamFromZk();  //从zk获得数据源配置信息
		templateList = DataSourceInitionUtil.create(props, mybatisConfig);
	}
	
	/**
	 * @throws Exception 
	 * @Title:getParamFromZk
	 * @Description:从zookeeper获得配置的参数信息,zookeeper中存储的是json格式的数据
	 * @return
	 * List<Properties>
	 * @throws
	 */
	private List<Properties> getParamFromZk() throws Exception
	{
		List<Properties> props = new ArrayList<Properties>();
		String path = "/"+this.appCode+"/"+this.envCode+(this.moduleCode==null?"":"/"+this.moduleCode);
		List<String> paths = this.zkReader.getZkMgr().getChildrenNode(path);
		if(paths != null && paths.size() > 0)
		{
				for(String module:paths)
				{
					String innerpath = path+"/"+module;
					String dsJson = this.zkReader.getNodeData(innerpath);
					Properties prop = JSON.parseObject(dsJson,Properties.class);
					props.add(prop);
				}
		}
		else
		{
			String dsJson = this.zkReader.getNodeData(path);
			Properties prop = JSON.parseObject(dsJson,Properties.class);
			props.add(prop);
		}
		
		return props;
	}

	@Override
	public long getCount(String statement, Object parameter)
	{
		List<Long> countList = this.selectList(statement,parameter);
		long countTotal = 0L;
		if(!CollectionUtils.isEmpty(countList))
		{
			LOG.debug("DAL执行中  countList明细："+JSON.toJSONString(countList));
			for(Long count:countList)
			{
				countTotal += count;
			}
		}
		else
		{
			throw new RuntimeException("DAL执行中  获得的countList为空，请检查SQL语句或数据库是否运行正常");
		}
		return countTotal;
	}

	@Override
	public long getMax(String statement, Object parameter)
	{
		List<Long> maxList = this.selectList(statement, parameter);
		long maxRs = 0L;
		if(!CollectionUtils.isEmpty(maxList))
		{
			LOG.debug("DAL执行中  maxList明细："+JSON.toJSONString(maxList));
			maxRs = Collections.max(maxList);
		}
		else
		{
			throw new RuntimeException("DAL执行中  获得的maxList为空，请检查SQL语句或数据库是否运行正常");
		}
		return maxRs;
	}

	@Override
	public long getMin(String statement, Object parameter)
	{
		List<Long> minList = this.selectList(statement, parameter);
		long minRs = 0L;
		if(!CollectionUtils.isEmpty(minList))
		{
			LOG.debug("DAL执行中  minList明细："+JSON.toJSONString(minList));
			minRs = Collections.min(minList);
		}
		else
		{
			throw new RuntimeException("DAL执行中  获得的minList为空，请检查SQL语句或数据库是否运行正常");
		}
		return minRs;
	}

	@Override
	public <T> List<T> orderBy(String statement, Object parameter,
			Comparator<T> comparator)
	{
		List<T> orderByList = this.selectList(statement, parameter);
		if(!CollectionUtils.isEmpty(orderByList))
		{
			LOG.debug("DAL执行中  orderByList条数："+orderByList.size());
			//按指定排序规则排序
			Collections.sort(orderByList, comparator);
		}
		else
		{
			throw new RuntimeException("DAL执行中  获得的orderByList为空，请检查SQL语句或数据库是否运行正常");
		}
		return orderByList;
	}

}
