package com.didong.basic.data_cache;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.didong.basic.data_cache.bean.AppCache;
import com.didong.basic.data_cache.compensation.CompensationMeasure;

/**
 * 
 * @ClassName:MyClientDataCacheTemplate
 * @author: 韩旺坤
 * @Description:缓存对外的调用接口类，要实现缓存的数据库查询，在mybatis必须以Map<String,String>作为传入参数
 * @date:2015年10月27日 上午8:07:38
 */
public class MyClientDataCacheTemplate
{
	Logger LOG = LoggerFactory.getLogger(MyClientDataCacheTemplate.class);
	
	//获取具体缓存实现工具类
    private DidongDataCacheTemplate dataCacheTemplate;
    public DidongDataCacheTemplate getDataCacheTemplate() {
		return dataCacheTemplate;
	}

	//缓存补偿措施工具类
    private CompensationMeasure compensationMeasure;

	public void setDataCacheTemplate(DidongDataCacheTemplate dataCacheTemplate)
	{
		this.dataCacheTemplate = dataCacheTemplate;
	}

	public void setCompensationMeasure(CompensationMeasure compensationMeasure)
	{
		this.compensationMeasure = compensationMeasure;
	}

	/**
	 * 
	 * @Title:getCacheData
	 * @Description:适用于KEY_VALUE，KEY_HASH_ONE，只返回1条数据
	 * @param type
	 * @param key
	 * @param clazz
	 * @return
	 * T
	 * @throws
	 */
	public <T> T getCacheData(String type, Map<String, String> key,
			Class<T> clazz)
	{
		AppCache cache = this.dataCacheTemplate.checkKey(type);
		T value = null;
		if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value())
		{
			value = this.dataCacheTemplate.getCacheData(type, clazz);
		}
		else if(cache.getCacheType() == CacheTypeEnum.KEY_HASH_ONE.value())
		{
			value = this.dataCacheTemplate.getCacheData(type, key, clazz);
		}
		//如果缓存没查到，则采取补偿措施查询数据，并把查到的数据放进缓存中
		if(value == null)
		{
			List<T> list = this.compensationMeasure.getCompensationData(cache,key,clazz);
			if(!CollectionUtils.isEmpty(list))
			{
				if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value())
				{
					this.dataCacheTemplate.setCacheData(type, list.get(0));
				}
				else if(cache.getCacheType() == CacheTypeEnum.KEY_HASH_ONE.value())
				{
					this.dataCacheTemplate.setCacheData(type, key, list.get(0));
				}
				
				return list.get(0);
			}
		}
		
		return value;
	}

	public <T> List<T> getCacheDataList(String type, Map<String, String> key,
			Class<T> clazz)
	{
		AppCache cache = this.dataCacheTemplate.checkKey(type);
		List<T> values = null;
		if(cache.getCacheType() == CacheTypeEnum.KEY_SET.value())
		{
			values = this.dataCacheTemplate.getCacheDataList(type, clazz);
		}
		else if(cache.getCacheType() == CacheTypeEnum.KEY_HASH_MUL.value())
		{
			values = this.dataCacheTemplate.getCacheDataList(type, key, clazz);
		}
		//如果缓存没查到，则采取补偿措施查询数据，并把查到的数据放进缓存中
		if(CollectionUtils.isEmpty(values))
		{
			List<T> list = this.compensationMeasure.getCompensationData(cache,key,clazz);
			if(!CollectionUtils.isEmpty(list))
			{
				if(cache.getCacheType() == CacheTypeEnum.KEY_SET.value())
				{
					this.dataCacheTemplate.setCacheData(type, list);
				}
				else if(cache.getCacheType() == CacheTypeEnum.KEY_HASH_MUL.value())
				{
					this.dataCacheTemplate.setCacheData(type, key, list);
				}
				
				return list;
			}
		}
		
		return values;
	}

	/**
	 * 
	 * @Title:refreshCacheDatas
	 * @Description:刷新缓存信息（1、对KEY_VALUE和KEY_SET，先把缓存信息删除，然后从数据库里面查到最新的信息，再放到缓存里面；
	 * 2、对于KEY_HASH，只要把缓存清空就可以）
	 * 3、刷新时，不能刷临时缓存
	 * void
	 * @throws
	 */
	public void refreshCacheDatas()
	{
		LOG.info("刷新缓存信息开始。。。 。。。");
		List<AppCache> cacheList = this.dataCacheTemplate.getCacheSettings();
		try
		{
			if(!CollectionUtils.isEmpty(cacheList))
			{
				for(AppCache cache:cacheList)
				{
					//先删除缓存
					this.dataCacheTemplate.deleteCacheData(cache.getType());
					//再判断缓存类型
					if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value()
							|| cache.getCacheType() == CacheTypeEnum.KEY_SET.value())
					{
						List queryList = this.compensationMeasure.getCompensationData(cache, null, Object.class);
						if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value())
						{
							this.dataCacheTemplate.setCacheData(cache.getType(), queryList.get(0));
						}
						else
						{
							this.dataCacheTemplate.setCacheData(cache.getType(), queryList);
						}
					}
				}
			}
		}
		catch(Exception ex)
		{
			LOG.error("刷新缓存信息失败。。。 。。。",ex);
			throw new RuntimeException(ex);
		}

		LOG.info("刷新缓存信息结束。。。 。。。");
	}
	
	/**
	 * 
	 * @Title:refreshCacheDataByType
	 * @Description:刷新指定type的缓存
	 * @param type
	 * void
	 * @throws
	 */
	public void refreshCacheDataByType(String type)
	{
		LOG.info("刷新缓存["+type+"]信息开始。。。 。。。");
		List<AppCache> cacheList = this.dataCacheTemplate.getCacheSettings();
		try
		{
			if(!CollectionUtils.isEmpty(cacheList))
			{
				for(AppCache cache:cacheList)
				{
                   if(cache.getType().equals(type))
                   {
   					//先删除缓存
   					this.dataCacheTemplate.deleteCacheData(cache.getType());
   					//再判断缓存类型
   					if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value()
   							|| cache.getCacheType() == CacheTypeEnum.KEY_SET.value())
   					{
   						List queryList = this.compensationMeasure.getCompensationData(cache, null, Object.class);
   						if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value())
   						{
   							this.dataCacheTemplate.setCacheData(cache.getType(), queryList.get(0));
   						}
   						else
   						{
   							this.dataCacheTemplate.setCacheData(cache.getType(), queryList);
   						}
   					}
   					break;
                   }
				}
			}
		}
		catch(Exception ex)
		{
			LOG.error("刷新缓存["+type+"]信息失败。。。 。。。",ex);
			throw new RuntimeException(ex);
		}

		LOG.info("刷新缓存["+type+"]信息结束。。。 。。。");
	}
	   /**
	    * 
	    * @Title:setTempData
	    * @Description:设置有一定生存时间的缓存
	    * @param type
	    * @param json
	    * @param timeout 存活时长，单位秒
	    * void
	    * @throws
	    */
	   public void setTempData(String type,String json,long timeout)
	   {
		   this.dataCacheTemplate.setTempData(type, json, timeout);
	   }
	   
	   /**
	    * 
	    * @Title:getTempData
	    * @Description:获取临时缓存值
	    * @param type
	    * @return
	    * String
	    * @throws
	    */
	   public String getTempData(String type)
	   {
		   return this.dataCacheTemplate.getTempData(type);
	   }

}
