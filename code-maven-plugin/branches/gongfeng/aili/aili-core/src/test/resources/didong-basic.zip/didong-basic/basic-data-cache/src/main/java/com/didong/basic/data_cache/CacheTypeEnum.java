package com.didong.basic.data_cache;
/**
 * 
 * @ClassName:CacheTypeEnum
 * @author: 韩旺坤
 * @Description:缓存类型
 * @date:2015年11月24日 下午5:01:51
 */
public enum CacheTypeEnum
{
   KEY_VALUE(0),
   KEY_SET(1),
   KEY_HASH_ONE(2),  //单条
   KEY_HASH_MUL(3);  //多条
	
	private int value;
	CacheTypeEnum(int type)
	{
		this.value = type;
	}
	
	public int value()
	{
		return value;
	}
	
}
