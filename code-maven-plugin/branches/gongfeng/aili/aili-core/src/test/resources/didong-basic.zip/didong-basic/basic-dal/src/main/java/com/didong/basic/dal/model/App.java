package com.didong.basic.dal.model;

/**
 * 
 * @ClassName:App
 * @author: 韩旺坤
 * @Description:t_app
 * @date:2015年10月13日 下午11:36:04
 */
public class App
{
	private long id;
	/**
	 * 应用名称
	 */
	private String appName;
	/**
	 * 应用编码
	 */
	private String appCode;
	/**
	 * 环境编码
	 */
	private String envCode;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public String getEnvCode() {
		return envCode;
	}

	public void setEnvCode(String envCode) {
		this.envCode = envCode;
	}

}
