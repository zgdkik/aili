package com.didong.basic.tools.encypt;

import java.io.IOException;

public class CEStreamExhausted extends IOException {

	/**
	 * 序列化ID
	 */
	private static final long serialVersionUID = 5632952018214005008L;

}
