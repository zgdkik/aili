package com.didong.app.sms.http;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.http.Header;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.http.MediaType;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.web.client.DefaultResponseErrorHandler;
import org.springframework.web.client.RestTemplate;

/**
 * 
 * @ClassName:RestClient
 * @author: 韩旺坤
 * @Description:采用连接池实现
 * @date:2015年11月22日 下午4:12:47
 */
public class RestClient implements InitializingBean
{
	public static Logger LOG = LoggerFactory.getLogger(RestClient.class);
    private RestTemplate httpTemplate;
    //连接池长连接保持时间，单位：s
    private int keepAliveTime;
    //总连接数
    private int maxTotal;
    //同路由的并发数
    private int defaultMaxPerRoute;
    
    //重试策略
    //是否开启重试
    private boolean isOpenRetry;
    //重试次数
    private int retryCount;
    
    //连接超时时间，毫秒
    private long connectTimeout;
    //读写超时时间，毫秒
    private long readTimeout;
    //连接不够用的等待时间
    private long connectionRequestTimeout;
    //缓冲请求数据，默认值是true。通过POST或者PUT大量发送数据时，建议将此属性更改为false，以免耗尽内存
    private boolean isOpenBufferRequestBody;
    
    //内容转换器
    List<HttpMessageConverter<?>> messageConverters;
    
	@Override
	public void afterPropertiesSet() throws Exception
	{
		LOG.debug("RestTemplate 初始化开始");
		PoolingHttpClientConnectionManager poolConnectionManager = new PoolingHttpClientConnectionManager(keepAliveTime,TimeUnit.SECONDS);
		poolConnectionManager.setMaxTotal(maxTotal);
		poolConnectionManager.setDefaultMaxPerRoute(defaultMaxPerRoute);
		
		HttpClientBuilder httpClientBuilder = HttpClients.custom();
		httpClientBuilder.setConnectionManager(poolConnectionManager);
		//重试次数，如果没有设置的话，默认是3次，没有开启
		httpClientBuilder.setRetryHandler(new DefaultHttpRequestRetryHandler(retryCount,isOpenRetry));
		//保持长连接配置，需要在头添加Keep-Alive
		httpClientBuilder.setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy());
		
		List<Header> headers = new ArrayList<Header>();
        headers.add(new BasicHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/31.0.1650.16 Safari/537.36"));
        headers.add(new BasicHeader("Connection", "Keep-Alive"));
        
        httpClientBuilder.setDefaultHeaders(headers);        
        HttpClient httpClient = httpClientBuilder.build();
        
        // httpClient连接配置，底层是配置RequestConfig
        HttpComponentsClientHttpRequestFactory clientHttpRequestFactory = new HttpComponentsClientHttpRequestFactory(httpClient);
        // 连接超时
        clientHttpRequestFactory.setConnectTimeout((int) connectTimeout);
        // 数据读取超时时间，即SocketTimeout
        clientHttpRequestFactory.setReadTimeout((int) readTimeout);
        // 连接不够用的等待时间，不宜过长，必须设置，比如连接不够用时，时间过长将是灾难性的
        clientHttpRequestFactory.setConnectionRequestTimeout((int) connectionRequestTimeout);
        // 缓冲请求数据，默认值是true。通过POST或者PUT大量发送数据时，建议将此属性更改为false，以免耗尽内存。
        clientHttpRequestFactory.setBufferRequestBody(isOpenBufferRequestBody);
        
        this.httpTemplate = new RestTemplate(clientHttpRequestFactory);
        this.httpTemplate.setErrorHandler(new DefaultResponseErrorHandler());
        this.httpTemplate.setMessageConverters(messageConverters);
        
		LOG.debug("RestTemplate 初始化结束");
	}

	
	//set 与  get 方法
	public RestTemplate getHttpTemplate()
	{
		return httpTemplate;
	}


	public int getKeepAliveTime() {
		return keepAliveTime;
	}


	public void setKeepAliveTime(int keepAliveTime) {
		this.keepAliveTime = keepAliveTime;
	}


	public int getMaxTotal() {
		return maxTotal;
	}


	public void setMaxTotal(int maxTotal) {
		this.maxTotal = maxTotal;
	}


	public int getDefaultMaxPerRoute() {
		return defaultMaxPerRoute;
	}


	public void setDefaultMaxPerRoute(int defaultMaxPerRoute) {
		this.defaultMaxPerRoute = defaultMaxPerRoute;
	}


	public boolean isOpenRetry() {
		return isOpenRetry;
	}


	public void setIsOpenRetry(boolean isOpenRetry) {
		this.isOpenRetry = isOpenRetry;
	}


	public int getRetryCount() {
		return retryCount;
	}


	public void setRetryCount(int retryCount) {
		this.retryCount = retryCount;
	}


	public long getConnectTimeout() {
		return connectTimeout;
	}


	public void setConnectTimeout(long connectTimeout) {
		this.connectTimeout = connectTimeout;
	}


	public long getReadTimeout() {
		return readTimeout;
	}


	public void setReadTimeout(long readTimeout) {
		this.readTimeout = readTimeout;
	}


	public long getConnectionRequestTimeout() {
		return connectionRequestTimeout;
	}


	public void setConnectionRequestTimeout(long connectionRequestTimeout) {
		this.connectionRequestTimeout = connectionRequestTimeout;
	}


	public boolean isOpenBufferRequestBody() {
		return isOpenBufferRequestBody;
	}


	public void setIsOpenBufferRequestBody(boolean isOpenBufferRequestBody) {
		this.isOpenBufferRequestBody = isOpenBufferRequestBody;
	}


	public List<HttpMessageConverter<?>> getMessageConverters() {
		return messageConverters;
	}


	public void setMessageConverters(List<HttpMessageConverter<?>> messageConverters) {
		this.messageConverters = messageConverters;
	}
	
	
  
}
