package com.didong.basic.mq.listener;


/**
 * 
 * @ClassName:DidongConsumer
 * @author: 韩旺坤
 * @Description:消费者需要实现的接口
 * @date:2015年11月13日 上午11:37:50
 */
public interface DidongConsumer 
{
	public void onMessage(String json) throws Exception;
}
