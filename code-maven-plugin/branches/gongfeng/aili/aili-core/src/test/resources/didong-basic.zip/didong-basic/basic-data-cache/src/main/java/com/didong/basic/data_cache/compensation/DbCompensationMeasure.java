package com.didong.basic.data_cache.compensation;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.didong.basic.dal.BaseDao;
import com.didong.basic.data_cache.CacheTypeEnum;
import com.didong.basic.data_cache.bean.AppCache;

/**
 * 
 * @ClassName:DbCompensationMeasure
 * @author: 韩旺坤
 * @Description:数据库补偿措施
 * @date:2015年10月26日 上午12:23:05
 */
public class DbCompensationMeasure implements CompensationMeasure
{
	Logger LOG = LoggerFactory.getLogger(DbCompensationMeasure.class);
    BaseDao baseDao;

	public void setBaseDao(BaseDao baseDao) {
		this.baseDao = baseDao;
	}

	@Override
	public <T> List<T> getCompensationData(AppCache cache, Map<String, String> key,Class<T> clazz)
	{
		LOG.debug("数据库补偿查询开始");
		List<T> result = new ArrayList<T>();
        if(cache.getCacheType() == CacheTypeEnum.KEY_VALUE.value() 
        		|| cache.getCacheType() == CacheTypeEnum.KEY_SET.value())
        {
        	Map<String,String> params = null;
        	if(!StringUtils.isEmpty(cache.getDefaultParam()))
        	{
        		params = JSON.parseObject(cache.getDefaultParam(), Map.class);
        	}       	
        	result = this.baseDao.selectList(cache.getSearchURL(),params);
        }
        else if(cache.getCacheType() == CacheTypeEnum.KEY_HASH_MUL.value()
        		|| cache.getCacheType() == CacheTypeEnum.KEY_HASH_ONE.value())
        {
        	result = this.baseDao.selectList(cache.getSearchURL(), key);
        }
		LOG.debug("数据库补偿查询结束");
        return result;
	}

}
