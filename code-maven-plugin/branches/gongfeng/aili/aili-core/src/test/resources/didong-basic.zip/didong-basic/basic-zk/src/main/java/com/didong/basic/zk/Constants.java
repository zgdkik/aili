package com.didong.basic.zk;



/**
 * Constants
 * 
 * @author 韩旺坤
 * @version
 * @see
 * @since
 */
public class Constants {
    /**
     * default retry count
     */
    public static final int DEFAULT_MAX_RETRIES = 5;

    /**
     * default retry interval 
     */
    public static final int DEFAULT_BASE_SLEEP_TIME_MS = 1000;
    /**
     * default connection timeout ms
     */
    public static final int DEFAULT_CONNECTION_TIMEOUT_MS = 5000;
    /**
     * default session timeout ms
     */
    public static final int DEFAULT_SESSION_TIMEOUT_MS = 5000;
    /**
     * 
     */
    public static final String CONSTANT_ZOOKEEPER_URL = "zookeeper.url";
    /**
     * 
     */
    public static final String CONSTANT_ZOOKEEPER_MAX_RETRIES = "zookeeper.max.retries";
    /**
     * 
     */
    public static final String CONSTANT_ZOOKEEPER_BASE_SLEEP_TIME = "zookeeper.base.sleep.time";
    /**
     * 
     */
    public static final String CONSTANT_ZOOKEEPER_CONNECTION_TIMEOUT = "zookeeper.connection.timeout";
    /**
     * 
     */
    public static final String CONSTANT_ZOOKEEPER_SESSION_TIMEOUT = "zookeeper.session.timeout";
    
    
    

}
