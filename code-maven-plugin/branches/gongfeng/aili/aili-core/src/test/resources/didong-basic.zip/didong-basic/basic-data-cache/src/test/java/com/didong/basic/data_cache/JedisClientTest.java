package com.didong.basic.data_cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class JedisClientTest extends AbstractJUnit4SpringContextTests 
{
	@Resource
	StringRedisTemplate redisTemplate;
	@Test
	public void test() throws Exception 
	{
		// String读写
		redisTemplate.delete("myStr");
		redisTemplate.opsForValue().set("myStr", "http://yjmyzz.cnblogs.com/");
		System.out.println(redisTemplate.opsForValue().get("myStr"));
		System.out.println("---------------");
		 
		// List读写
		redisTemplate.delete("myList");
		redisTemplate.opsForList().leftPush("myList", "A");
		redisTemplate.opsForList().leftPush("myList", "B");
		redisTemplate.opsForList().leftPush("myList", "0");
		List<String> listCache = redisTemplate.opsForList().range(
		        "myList", 0, 2);
		for (String s : listCache) {
		     System.out.println(s);
		   }
		
		System.out.println("---------------");
		
		// Set读写
		redisTemplate.delete("mySet");
		redisTemplate.opsForSet().add("mySet", "A");
		redisTemplate.opsForSet().add("mySet", "B");
		redisTemplate.opsForSet().add("mySet", "C");
		Set<String> setCache = redisTemplate.opsForSet().members(
		              "mySet");
		    for (String s : setCache) {
		          System.out.println(s);
		        }
		        System.out.println("---------------");
		
		// Hash读写
		redisTemplate.delete("myHash");
		redisTemplate.opsForHash().put("myHash", "PEK", "北京");
		redisTemplate.opsForHash().put("myHash", "SHA", "上海虹桥");
		redisTemplate.opsForHash().put("myHash", "PVG", "浦东");
		Map<Object, Object> hashCache = redisTemplate.opsForHash()
		          .entries("myHash");
		for (Map.Entry<Object, Object> entry : hashCache.entrySet()) {
		       System.out.println(entry.getKey() + " - " + entry.getValue());
		      }
		
		System.out.println("---------------");
	}
	
	@Test
	public void testSort()
	{
		Map<String,String> map1=new HashMap<String,String>();
		map1.put("aa", "CC");
		map1.put("bb", "AA");		
		map1.put("cc", "BB");	
		
		Map<String,String> map2=new HashMap<String,String>();
		map2.put("cc", "CC");
		map2.put("aa", "AA");		
		map2.put("bb", "BB");	
		
		System.out.println(JSON.toJSONString(map1));
		System.out.println(JSON.toJSONString(map2));		
		
	}

}