package com.didong.basic.dal;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

public interface BaseDao
{
    /**
     * {@inheritDoc}
     */
    public <T> T selectOne(String statement);

    /**
     * {@inheritDoc}
     */
    public <T> T selectOne(String statement, Object parameter);

    /**
     * {@inheritDoc}
     */
    public <K, V> Map<K, V> selectMap(String statement, String mapKey);

    /**
     * {@inheritDoc}
     */
    public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey);

    /**
     * {@inheritDoc}
     */
    public <K, V> Map<K, V> selectMap(String statement, Object parameter, String mapKey, RowBounds rowBounds);

    /**
     * {@inheritDoc}
     */
    public <E> List<E> selectList(String statement);

    /**
     * {@inheritDoc}
     */
    public <E> List<E> selectList(String statement, Object parameter);

    /**
     * {@inheritDoc}
     */
    public <E> List<E> selectList(String statement, Object parameter, RowBounds rowBounds);

    /**
     * {@inheritDoc}
     */
    public void select(String statement, ResultHandler handler);

    /**
     * {@inheritDoc}
     */
    public void select(String statement, Object parameter, ResultHandler handler);
    
    /**
     * {@inheritDoc}
     */
    public int insert(String statement);

    /**
     * {@inheritDoc}
     */
    public int insert(String statement, Object parameter);
    
    
    /**
     * {@inheritDoc}
     * 采用固定的insert select 的方式实现sql ， 来批量写入。
     * 建议batchSize不要太大，100-1000。
     */
    public int insertBatch(String statement, List<?> parameterList , int batchSize);
    
    
    /**
     * {@inheritDoc}
     */
    public int update(String statement);

    /**
     * {@inheritDoc}
     */
    public int update(String statement, Object parameter);

    /**
     * {@inheritDoc}
     */
    public int delete(String statement);

    /**
     * {@inheritDoc}
     */
    public int delete(String statement, Object parameter); 
    
    /**
     * 
     * @Title:getCount
     * @Description:TODO
     * @param statement
     * @param parameter
     * @return
     * long
     * @throws
     */
    public long getCount(String statement, Object parameter);
    
    /**
     * 
     * @Title:getMax
     * @Description:TODO
     * @param statement
     * @param parameter
     * @return
     * long
     * @throws
     */
    public long getMax(String statement, Object parameter);
    
    /**
     * 
     * @Title:getMin
     * @Description:TODO
     * @param statement
     * @param parameter
     * @return
     * long
     * @throws
     */
    public long getMin(String statement, Object parameter);
    
    /**
     * 
     * @Title:orderBy
     * @Description:排序功能
     * @param statement
     * @param parameter
     * @param comparator
     * @return
     * List<T>
     * @throws
     */
    public <T> List<T> orderBy(String statement, Object parameter,Comparator<T> comparator);

}

