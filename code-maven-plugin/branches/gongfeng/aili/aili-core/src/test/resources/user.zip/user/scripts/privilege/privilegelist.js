// 显示右键菜单
function showRMenu(type, x, y) {
	$("#rMenu ul").show();
	if (type == "root") {
		$("#m_del").hide();
		$("#m_check").hide();
		$("#m_unCheck").hide();
	}
	$("#rMenu").css({
		"top" : y + "px",
		"left" : x + "px",
		"display" : "block"
	});
}
// 新增树节点
function add(e) {
	var zTree = $.fn.zTree.getZTreeObj("treeDemo");
	isParent = e.isParent;
	id = e.id;
	pId = e.pId;
	name = e.name;
	icon = e.icon;
	nodes = zTree.getNodeByParam("id", pId);
	treeNode = zTree.addNodes(nodes, {
		id : id,
		pId : pId,
		icon : icon,
		open : true,
		isParent : isParent,
		name : name
	});
};

// 删除节点
function remove() {
	var zTree = $.fn.zTree.getZTreeObj("treeDemo");
	nodes = zTree.getSelectedNodes();
	treeNode = nodes[0];
	zTree.removeNode(treeNode);
};

// 修改节点
function edit(e) {
	var zTree = $.fn.zTree.getZTreeObj("treeDemo");
	name = e.name;
	id = e.id;
	pId = e.pId;
	nodes = zTree.getSelectedNodes();
	nodes2 = zTree.getNodeByParam("id", pId, null);
	treeNode = nodes[0];
	treeNode.name = name;
	treeNode.pId = pId;
	treeNode.open = true;
	// 先更新
	zTree.updateNode(treeNode);

};
function menuClick(event, treeId, treeNode, clickFlag) {
	ym.sendPost(base + "/privilege/getMenuInfo/" + treeNode.id, null, {
		successHandler : function(data, textStatus, jqXHR) {
			if (data != null) {
//				ym.setFormObj("privilege-info",data.data);
//				$('#privilege-info').find("select[name='appType']").val(data.data.appType).trigger("change");
//				$('#privilege-info').find("select[name='moduleType']").val(data.data.moduleType).trigger("change");
				$("#privilege-info").form("load",data.data);
			}
		}
	});

}

$(document).ready(function() {
	
	setting.callback = {onClick : menuClick};
	
	$.fn.zTree.init($("#treeDemo"), setting);
	
	$(".addnew").on("click",function(){
		var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
		nodes = zTree.getSelectedNodes();
		if ( nodes.length == 0) {
			layer.alert("请先选择一个节点");
			return;
		}
		var nodeId = nodes[0].id;
//		$('#myModal').find('input[name="id"]').val(null);
//		$('#myModal').find('input[name="parentCode"]').val(nodeId);
//		$('#myModal').find('input[name="privilegeCode"]').removeAttr("readonly");
//		$('#myModal').modal('show');
		
		$('#dialog-edit').dialog({
		    title: '权限编辑',    
		    width: 400,    
		    height: 200,    
		    closed: false,
		    buttons:[{
				text:'保存',
				iconCls:'icon-save',
				handler:function(){
					alert('edit')
				}
			}],
		    cache: false,
		    modal: true   
		});    

		
	});
	
	$(".update").on("click",function(){
		var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
		nodes = zTree.getSelectedNodes();
		if ( nodes.length == 0) {
			layer.alert("请先选择一个节点");
			return;
		}
		var nodeId = nodes[0].id;
		ym.sendPost(base + "/privilege/getMenuInfo/" + nodeId, null, {
			successHandler : function(data, textStatus, jqXHR) {
				if (data != null) {
					$('#myModal').find('input[name="privilegeCode"]').attr("readonly","readonly");
					ym.setFormObj("privilege-form",data.data);
					$('#myModal').find("select[name='appType']").val(data.data.appType).trigger("change");
					$('#myModal').find("select[name='moduleType']").val(data.data.moduleType).trigger("change");
					$('#myModal').modal('show');
				}
			}
		});
	});
	
	$(".remove").on("click",function(){
		var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
		nodes = zTree.getSelectedNodes();
		if ( nodes.length == 0) {
			layer.alert("请先选择一个节点");
			return;
		}
		var nodeId = nodes[0].id;
		bootbox.confirm("确定要删除吗?", function(result) {
			if(result){
				ym.sendPost(base + "/privilege/deleteMenu/" + nodeId,null, {
					successHandler : function(data, textStatus, jqXHR) {
						if (data != null) {
							if(data.success){
								remove();
							}
							layer.alert(data.msg);
						}
					}
				});
			}
		});
		
	});
	
	$(".save").on("click",function(){
		$('#privilege-form').bootstrapValidator('validate');
		var validate = $('#privilege-form').data('bootstrapValidator').isValid();
		if(!validate){
			return;
		}
		var param = $('#privilege-form').getFormObj();
		var id  =$('#privilege-form').find("input[name='id']").val();
		ym.sendPost(base+"/privilege/editMenu/",param, {
			successHandler : function(data, textStatus, jqXHR) {
				if (data != null) {
					if(data.success){
						$('#myModal').modal('hide');
						var node = {id:param.privilegeCode,pId:param.parentCode,name:param.functionName};
						node.icon=base+"/images/home/icon/jd.png";
						if(id=="" || id==null){
							add(node);
						}else{
							edit(node);
						}
					}
					layer.alert(data.msg);
				}
			}
		});
	});
	
});



