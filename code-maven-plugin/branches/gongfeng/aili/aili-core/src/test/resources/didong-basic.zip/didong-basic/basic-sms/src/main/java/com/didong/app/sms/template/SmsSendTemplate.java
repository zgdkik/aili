package com.didong.app.sms.template;

import com.didong.app.sms.bean.SmsMessage;

public interface SmsSendTemplate
{
   /**
    * 
    * @Title:syncSendMessage
    * @Description:同步发送短信，直接调用供应商发送短信接口
    * @param sms
    * void
    * @throws
    */
   public void syncSendMessage(SmsMessage sms);
   
   
   /**
    * 
    * @Title:asynSendMessage
    * @Description:异步发送短信，启用线程，然后发到MQ里面，后面再慢慢消费
    * @param sms
    * void
    * @throws
    */
   public void asynSendMessage(SmsMessage sms);
}
