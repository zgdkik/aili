package com.didong.basic.tools.encypt;

import java.io.IOException;

/**
 * 系统名称：双至开发平台-SZSP
 * 模块名称：
 * 模块描述：解密出错异常
 * 功能列表：
 * 模块作者：zouyong-ocean
 * 开发时间：2015年9月17日 下午7:01:24
 * 模块路径：com.paireach.szsp.framework.base.shared.encypt.base64.CEFormatException
 * 更新记录：
 */
public class CEFormatException extends IOException {

	/**
	 * 序列化ID
	 */
	private static final long serialVersionUID = -5645294385484242272L;

	public CEFormatException(String s) {
        super(s);
	}
	
}
