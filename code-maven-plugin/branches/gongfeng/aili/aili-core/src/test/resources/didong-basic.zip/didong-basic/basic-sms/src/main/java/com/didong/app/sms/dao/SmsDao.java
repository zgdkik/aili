package com.didong.app.sms.dao;

import java.util.List;

import com.didong.app.sms.bean.SmsGateWay;
import com.didong.app.sms.bean.SmsPercentage;
import com.didong.app.sms.bean.Suppliers;

public interface SmsDao
{
   /**
    * 
    * @Title:selectSups
    * @Description:查出所有供应商信息
    * @return
    * List<Suppliers>
    * @throws
    */
   public List<Suppliers> selectSups();
   
   /**
    * 
    * @Title:selectGateWay
    * @Description:查询出所有网关信息
    * @return
    * List<SmsGateWay>
    * @throws
    */
   public List<SmsGateWay> selectGateWay();
   
   /**
    * 
    * @Title:selectPercentage
    * @Description:查询出供应商占比信息
    * @return
    * List<SmsPercentage>
    * @throws
    */
   public List<SmsPercentage> selectPercentage();
}
