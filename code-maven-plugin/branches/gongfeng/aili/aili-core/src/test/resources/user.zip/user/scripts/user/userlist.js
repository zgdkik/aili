
function detailFormatter(index, row) {
        var html = [];
        $.each(row, function (key, value) {
            html.push('<p><b>' + key + ':</b> ' + value + '</p>');
    });
    return html.join('');
}

$(document).ready(function() {
	var columns = [{
		field : 'userName', 
		title : '用户名' 
		},{
		field : 'modifiedTime', 
		title : '修改时间',
		formatter : function(modifiedTime,obj){
			
			return  ym.formatTime(modifiedTime);
		}},{
		field : 'pwdModidiedTime', 
		title : '密码修改时间'  ,
		formatter : function(pwdModidiedTime,obj){
			return  ym.formatTime(pwdModidiedTime);
		}
		},{
		field : 'compCode', 
		title : '公司'
		},
		{
		field : 'status', 
		title : '状态',
		formatter : function(status,obj){
			if("enable"==status){
				return "启用";
			}else{
				return "禁用";
			}
		}
		}
		,{
		field : 'id',
		title : '操作列',
		formatter : function(id,obj){
			var toolmenu =  
				'<div class="btn-group btn-group-xs"> '+
	       		'<a type="button" class="btn btn-default grain" data-pid="'+obj.userName+'"> <i class="fa fa-edit"></i>授权</a>'+
	       		'</div>';
			return toolmenu;
		}
	} ];
	 function queryData(){
	    	ym.initPage(base + "/user/getuserlist", {
	    		queryParams : function(params) {
	    			 var formObj = $(".query-form").getFormObj();
	    			for(var p in formObj) {
	    				//属性名称 
		    			var name=p;
		    			//属性对应的值 
		    			var val=formObj[p];
		    			params[name]=val; 
	    			} 
	    			return params;
	    		}
	    	}, "#table", columns);
	 }
	
	queryData();
	
	$('.btn-search').on("click",function(){
		queryData();
	});
	
	var role_columns = [ {
			field : 'state',
			checkbox:true
		}, {
			field : 'roleName',
			title : '角色名称'
		}, {
			field : 'compCode',
			title : '角色公司'
		}, {
			field : 'roleDesc',
			title : '角色描述'
		}
	 ];
	 function queryRoleData(){
		 roleTable = ym.initPage(base + "/role/getRoleList",  {
	    		queryParams : function(params) {
	    			params["page.pageSize"]=100;
	    			return params;
	    		}
	    	}, "#table-role", role_columns);
	 }
	var roleTable;
	queryRoleData();
	$('#table').on("click",".grain",function(){
		var userName = $(this).data("pid");
		$('#myModal').find(".userName").val(userName);
		//设置用户已有权限
		ym.sendPost(base+'/user/grain/'+userName,null,{
    		successHandler:function(data,textStatus, jqXHR){
    			if(data.success){
    				queryRoleData();
    				var roleCodes = data.data;
    				$('#myModal').modal('show');
    				setTimeout(function(){
    					var rows = roleTable.bootstrapTable('getData');
    					if(rows!=null){
    						for (var i = 0; i < rows.length; i++) {
    							var r1 = rows[i].roleCode;
    							for (var j = 0; j < roleCodes.length; j++) {
        							 var r2 = roleCodes[j];
        							 if(r1==r2){
        								 roleTable.bootstrapTable('check',i);
        							 }
    							}
							}
    					}
    				},300);
    			}
    		}});
		
	});
	
	$('#myModal').on("click",".save",function(){
		  
		   var selections = roleTable.bootstrapTable('getSelections');
		   if(selections==null ||selections.length==0){
	    		layer.alert("请选择角色");
	    		return;
	    	}
		   var roleCodes = "";
		   for (var i = 0; i < selections.length; i++) {
				var n = selections[i];
				if(selections.length==(i+1)){
					roleCodes  = roleCodes+n.roleCode+"";
				}else{
					roleCodes  = roleCodes+n.roleCode+",";
				}
			}
		   var userName = $('#myModal').find(".userName").val();
		   ym.sendPost(base+'/user/grain',{userName:userName,roleCodes:roleCodes},{
	    		successHandler:function(data,textStatus, jqXHR){
	    			if(data.success){
	    				$('#myModal').modal('hide');
	    			}
	    			layer.alert(data.msg);
	    	}});
	});

});
