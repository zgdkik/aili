package com.didong.basic.tools.other;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

import org.apache.log4j.Logger;



/**
 * 
 * TODO 查询一个对象所占用的内存大小
 * TODO 对象的所有字段必须要能够进行序列化才行
 * @author    韩旺坤
 * @version   
 * @see       
 * @since    2015年3月24日
 */
public  class JavaSizeOf 
{
    private static Logger logger = Logger.getLogger(JavaSizeOf.class);
    
    
    public static int sizeOfObj(Object obj)
    {
        if(obj != null)
        {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream ops = null;            
            try 
            {
                ops = new ObjectOutputStream(baos);
                ops.writeObject(obj);
                ops.flush();
                
                int size = baos.size();
                
                return size;
                
            } catch (IOException e) 
            {
                logger.error("对象序列化发生异常 ，请检查");
                e.printStackTrace();
                return 0;
            }
            finally
            {
                try 
                {
                    ops.close();
                    baos.close();
                } 
                catch (IOException e) 
                {
                    e.printStackTrace();
                }

            }
        }
        else
        {
            logger.error("对象为 null ，请检查");
            return 0;
        }
    }

}
