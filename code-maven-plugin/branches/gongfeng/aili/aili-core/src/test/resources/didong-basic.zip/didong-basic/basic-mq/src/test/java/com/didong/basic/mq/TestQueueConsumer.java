package com.didong.basic.mq;

import com.didong.basic.mq.listener.DidongConsumer;

public class TestQueueConsumer implements DidongConsumer {

	@Override
	public void onMessage(String json) throws Exception
	{
        System.out.println("消费消息："+json);
	}

}
