package com.didong.basic.mongo.server.gridfs;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.didong.basic.mongo.shared.constant.MongoConstants;
import com.didong.basic.mongo.shared.util.FileUtil;
import com.didong.basic.mongo.shared.util.MongoDBUtil;
import com.didong.basic.mongo.shared.util.UUIDUtils;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSDBFile;
import com.mongodb.gridfs.GridFSInputFile;

/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：Mongodb文件服务
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 上午11:10:11
 * 模块路径：com.didong.basic.mongo.server.gridfs.MongoGridFsServer
 * 更新记录：
 */
public class MongoGridFsServer {

	private static Log log = LogFactory.getLog(MongoGridFsServer.class);
	
	// Mongodb数据库客户端操作对象
	private static MongoClient mongoClient;
	
	// Mongodb数据库文件操作对象
	private static GridFS gridFs;
	
	static {
		mongoClient = MongoDBUtil.getMgdbClientByMgdb(
				MongoConstants.mgdbAdrs, MongoConstants.mgdbPort);
		DB db = mongoClient.getDB(MongoConstants.mgGdfsTabName);
		gridFs = new GridFS(db);
	}
	
	/**
	 * 功能描述：将指定文件路径的文件保存到Mongdb数据库中
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午12:17:39
	 * 更新记录：
	 * 返回数据：String
	 */
	public static String saveFileByPath(String filePath) throws FileNotFoundException {
		if(StringUtils.isNotBlank(filePath)) {
			return saveFile(new File(filePath));
		}
		return null;
	}
	
	/**
	 * 功能描述：保存文件，返回保存的文件名称
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 上午11:24:46
	 * 更新记录：
	 * @param file 要存储的文件对象
	 * 返回数据：String
	 * @throws FileNotFoundException 
	 */
	public static String saveFile(File file) throws FileNotFoundException {
		
		if(null != file && file.exists() && null != gridFs) {
			// 获取文件后缀
			String endSuff = FileUtil.getFileSuffixes(file.getName());
			// 文件前缀
			String startSuff = UUIDUtils.getUUID();
			// 文件名称
			String fileName = startSuff + "." + endSuff;
			// 根据名称查询该名称是否已保存
			DBObject query = new BasicDBObject("_id", fileName);
			GridFSDBFile gridFSDBFile = gridFs.findOne(query);
			// 如果该文件已存储则先删除，再新增
			if(null != gridFSDBFile) {
				gridFs.remove(query);
			}
			InputStream iptStm = new FileInputStream(file);
			return saveFileByIptStm(iptStm, fileName);
		}
		return null;
	}
	
	/**
	 * 功能描述：将文件流保存到Mongdb数据库中
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午12:15:41
	 * 更新记录：
	 * 返回数据：String
	 */
	public static String saveFileByIptStm(InputStream iptStm, String fileName) {
		if(null != gridFs) {
			GridFSInputFile gridFSInputFile = gridFs.createFile(iptStm);
			gridFSInputFile.setId(fileName);
			gridFSInputFile.setFilename(fileName);
			gridFSInputFile.save();
			return fileName;
		}
		return null;
	}
	
	/**
	 * 功能描述：删除Mongodb数据库中指定文件名称的文件数据
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午12:19:39
	 * 更新记录：
	 * 返回数据：boolean
	 */
	public static boolean removeFile(String fileName) {
		if(null != gridFs) {
			// 据文件名从gridfs中读取到文件
			DBObject query  = new BasicDBObject("filename", fileName);
	        gridFs.remove(query);
		}
		return false;
	}

	/**
	 * 功能描述：根据文件名称获取Mongodb数据库中文件流
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午12:03:46
	 * 更新记录：
	 * 返回数据：InputStream
	 */
	public static InputStream getMongoFileIptStm(String fileName) {
		if(null == gridFs) {
			return null;
		}
		// 据文件名从gridfs中读取到文件
		DBObject query  = new BasicDBObject("filename", fileName);
        GridFSDBFile gridFSDBFile = gridFs.findOne(query);
        if(gridFSDBFile != null){
        	log.info("filename:" + gridFSDBFile.getFilename());
        	log.info("md5:" + gridFSDBFile.getMD5());
        	log.info("length:" + gridFSDBFile.getLength());
        	log.info("uploadDate:" + gridFSDBFile.getUploadDate());
            return gridFSDBFile.getInputStream();
        }
		return null;
	}

}

