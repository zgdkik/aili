package com.didong.app.sms.http;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

public class HttpUtil 
{
   public static Logger LOG = LoggerFactory.getLogger(HttpUtil.class);
   
   RestClient restClient;
   
   public RestClient getRestClient() {
	return restClient;
}

public void setRestClient(RestClient restClient)
{
	this.restClient = restClient;
}

/**
    * post请求
    * @param url
    * @param formParams
    * @return
    */
   public String doPost(String url, Map<String, String> formParams)
   {
       if (formParams == null || formParams.isEmpty())
       {
           return doPost(url);
       }

       try
       {
           MultiValueMap<String, String> requestEntity = new LinkedMultiValueMap<String, String>();
           for(String key:formParams.keySet())
           {
        	   requestEntity.add(key, formParams.get(key));
           }
           return restClient.getHttpTemplate().postForObject(url, requestEntity, String.class);
       } 
       catch (Exception e)
       {
           LOG.error("POST请求出错：{}", url, e);
       }

       return null;
   }

   /**
    * post请求
    * @param url
    * @return
    */
   public String doPost(String url)
   {
       try 
       {
           return restClient.getHttpTemplate().postForObject(url, null, String.class);
       } 
       catch (Exception e)
       {
           LOG.error("POST请求出错：{}", url, e);
       }

       return null;
   }

   /**
    * get请求
    * @param url
    * @return
    */
   public String doGet(String url)
   {
       try
       {
           return restClient.getHttpTemplate().getForObject(url, String.class);
       } 
       catch (Exception e)
       {
           LOG.error("GET请求出错：{}", url, e);
       }

       return null;
   }
}
