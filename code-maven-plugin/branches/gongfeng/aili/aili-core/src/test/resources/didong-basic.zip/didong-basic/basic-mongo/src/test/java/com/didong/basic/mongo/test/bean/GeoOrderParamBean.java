package com.didong.basic.mongo.test.bean;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 
 * @ClassName:GeoOrderParamBean
 * @author: 韩旺坤
 * @Description:Mongo里面供查询的订单信息
 * @date:2016年1月3日 下午8:10:30
 */
@Document(collection="t_geo_order")
public class GeoOrderParamBean {
	// 订单ID
	private BigInteger id;
	// 取货地址
	private String pickUpAddress;
	// 送货地址
	private String consigneeAddress;
	// 收益（单位：元）
	private BigDecimal returnAmount;
	// 打包数量
	private int pkgCount;
    //取货地址经纬度信息
	private Gps gps;
	// 是否被抢：0-》已被抢单，1->未被抢单
	private int isActive;
	//距离，与所传位置的距离
	private double distance;

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public String getPickUpAddress() {
		return pickUpAddress;
	}

	public void setPickUpAddress(String pickUpAddress) {
		this.pickUpAddress = pickUpAddress;
	}

	public String getConsigneeAddress() {
		return consigneeAddress;
	}

	public void setConsigneeAddress(String consigneeAddress) {
		this.consigneeAddress = consigneeAddress;
	}

	public BigDecimal getReturnAmount() {
		return returnAmount;
	}

	public void setReturnAmount(BigDecimal returnAmount) {
		this.returnAmount = returnAmount;
	}

	public int getPkgCount() {
		return pkgCount;
	}

	public void setPkgCount(int pkgCount) {
		this.pkgCount = pkgCount;
	}

	public int getIsActive() {
		return isActive;
	}

	public void setIsActive(int isActive) {
		this.isActive = isActive;
	}

	public Gps getGps() {
		return gps;
	}

	public void setGps(Gps gps) {
		this.gps = gps;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}	

}
