package com.didong.basic.gis.server.util;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import com.didong.basic.gis.server.domain.CoordinateEntity;


/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 下午3:38:38
 * 模块路径：com.didong.basic.gis.server.util.DistanceCalcUtil
 * 更新记录：
 */
public class DistanceCalcUtil {
	
	/**
	 * 常用三个坐标系,WGS84,、北京54、西安80
	 * WGS84椭球的长半轴就为：637813
	 */
	private static double EARTH_RADIUS = 6378.137;
	/**
	 * 至西向东步增值：1Km左右
	 */
	private static double westStart = 0.03;

	/**
	 * 至南向北步增值：1Km左右
	 */
	private static double southStart = 0.03;
	/**
	 * 初始化城市区域划分编码
	 */
	private static int cityCoordCode = 0;
	/**
	 * 功能描述：圆周率/π
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午3:45:39
	 * 更新记录：
	 * 返回数据：double
	 */
	public static double rad(double d) {
		return d * Math.PI / 180.0;
	}
	
	/**
	 * 功能描述：精确计算两地直线距离
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午4:11:58
	 * 更新记录：
	 * @param startLat-开始地址纬度
	 * @param startLng-开始地址经度
	 * @param endLat-结束地址纬度
	 * @param endLng-结束地址经度
	 * 返回数据：double
	 */
	public static double allDistanceRes(
			double startLat, double startLng, double endLat, double endLng) {
		
		// 初略计算两地直线距离
		double oneResult = calcDistance(startLat, startLng, endLat, endLng);
		// 结果四舍五入
		oneResult = oneResult * 1000;
		oneResult = Math.round(oneResult);
		
		return oneResult;
	}

	/**
	 * 功能描述：初略算出两地距离
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 下午3:49:18
	 * 更新记录：
	 * 返回数据：double
	 */
	public static double calcDistance(double startLat, double startLng, double endLat, double endLng) {
		
		// 开始地址纬度
		double radLat1 = rad(startLat);
		// 结束地址纬度
		double radLat2 = rad(endLat);
		
		// 纬度值：开始地址纬度-结束地址纬度
		double latRes = radLat1 - radLat2;
		
		double lngRes = rad(startLng) - rad(endLng);
		
		double latLngRes = 2 * Math.asin(
			Math.sqrt(
				Math.pow(Math.sin(latRes/2),2) + 
					Math.cos(radLat1) * Math.cos(radLat2) * Math.pow(Math.sin(lngRes/2),2)
			)
		);
		latLngRes = latLngRes * EARTH_RADIUS;
		
		return latLngRes;
	}
	
	public static void main(String[] args) {
		
		// 两经纬度直线距离计算
		test();

		/**
		 * 计算城市-区域划分
		 * 取上海市【区域分块列表】
		// 西北交点
		double a1 = 31.870045;
		double a2 = 121.000000;
		// 西南交点
		double b1 = 30.694735;
		double b2 = 121.000000;
		// 东南交点
		double c1 = 30.694735;
		double c2 = 122.003930;
		// 东北交点
		double d1 = 31.870045;
		double d2 = 122.003930;
		 */
		double east = 122.003930; // 东边终点
		double west = 121.000000; // 西边终点
		double south = 30.694735; // 南边终点
		double north = 31.870045; // 北边终点
		String cityCode = "310100"; // 上海市行政区域编码
		String cityName = "上海市"; // 上海市行政区域名称
		List<CoordinateEntity> list = 
				calcCityMapCell(east, west, south, north, cityCode, cityName);
		System.out.println("===========" + list.size());
	}
	
	/**
	 * 功能描述：获取指定城市四个坐标值的划分区块
	 * 模块作者：zouyong
	 * 开发时间：2016年1月2日 上午11:06:41
	 * 更新记录：
	 * 返回数据：void
	 */
	public static List<CoordinateEntity> calcCityMapCell(double east, double west, 
			double south, double north, String cityCode, String cityName) {
		List<CoordinateEntity> list = new ArrayList<CoordinateEntity>();
		// 开始运算
		double southPoint = south;
		double westPoint = west;
		cityCoordCode = 8698;
		while((southPoint = getSouthPoint(southPoint, north)) <= north) {
			//System.out.println(south + "===" + southPoint + "===" + north);
			westPoint = calcCoordinate(south, southPoint, westPoint, east, north, cityCode, cityName, list);
			south = southPoint;
		}
		return list;
	}

	/**
	 * 功能描述：计算并汇总
	 * 模块作者：zouyong
	 * 开发时间：2016年1月2日 上午11:06:36
	 * 更新记录：
	 * 返回数据：double
	 * @param code 
	 */
	private static double calcCoordinate(double south, double southPoint, 
			double west, double east, double north, String cityCode, String cityName, List<CoordinateEntity> list) {
		// 获取东边步增后数据
		double westPoint = getWestPoint(west, east);
		if(westPoint >= east) {
			westPoint = east;
		}
		// 递归执行
		if(westPoint != east) {
			CoordinateEntity coordinate = new CoordinateEntity();
			coordinate.setMinLat(south);		// 最小纬度
			coordinate.setMaxLat(southPoint);	// 最大纬度
			coordinate.setMinLng(west);			// 最小经度
			coordinate.setMaxLng(westPoint);	// 最大经度
			coordinate.setEndLat(north);		// 截止纬度
			coordinate.setEndLng(east);			// 截止经度
			coordinate.setCityCode(cityCode);
			coordinate.setCityName(cityName);
			coordinate.setCreateDate(new Date(System.currentTimeMillis()));
			coordinate.setCreateUser("000000");
			coordinate.setCode(cityCoordCode+"");
			list.add(coordinate);
			cityCoordCode++;
//			System.out.println(
//					"[" + westPoint + ", " + south + "]=[" + west + ", " + southPoint + "]=[" + 
//					westPoint + ", " + southPoint + "]=[" + west + ", " + south + "]");
			calcCoordinate(south, southPoint, westPoint, east, north, cityCode, cityName, list);
		}
		return westPoint;
	}

	/**
	 * 功能描述：从南至北，获取步增值
	 * 模块作者：zouyong
	 * 开发时间：2016年1月1日 下午7:06:26
	 * 更新记录：
	 * 返回数据：double
	 */
	private static double getSouthPoint(double south, double north) {
		if(south <= north) {
			return south = south + southStart;
		}
		return south;
	}

	/**
	 * 功能描述：从西至东，获取步增值
	 * 模块作者：zouyong
	 * 开发时间：2016年1月1日 下午7:03:12
	 * 更新记录：
	 * 返回数据：double
	 */
	private static double getWestPoint(double west, double east) {
		if(west <= east) {
			return west = west + westStart;
		}
		return west;
	}

	/**
	 * 功能描述：两坐标经纬度直线距离计算
	 * 模块作者：zouyong
	 * 开发时间：2016年1月2日 上午10:42:43
	 * 更新记录：
	 * 返回数据：void
	 */
	private static void test() {
		/**
		 * 两地直线距离为：1113.0米！
		 * 两地直线距离为：2226.0米！
		 */
//		double y1 = 31.870045;
//		double x1 = 121.000000;
//		double y2 = 31.860045;
//		double x2 = 121.000000;
		/**
		 * 两地直线距离为：9454.0米！
		 * 两地直线距离为：945.0米！
		 */
		double y1 = 31.870045;
		double x1 = 121.000000;
		double y2 = 31.870045;
		double x2 = 121.010000;

		double result = allDistanceRes(y1, x1, y2, x2);
		System.out.println("两地直线距离为：" + result + "米！");
	}

}
