package com.didong.basic.message_push;

import java.util.ArrayList;
import java.util.List;

import com.gexin.rp.sdk.base.IPushResult;
import com.gexin.rp.sdk.base.impl.AppMessage;
import com.gexin.rp.sdk.http.IGtPush;
import com.gexin.rp.sdk.template.AbstractTemplate;
import com.gexin.rp.sdk.template.LinkTemplate;
import com.gexin.rp.sdk.template.NotificationTemplate;
import com.gexin.rp.sdk.template.NotyPopLoadTemplate;

/**
 * 
 * @author daizhiqing
 *
 */
public class GetuiUtil {
	static String appId = "3GohHFdFJS8BmNGOk6yV31";
	static String appkey = "seYD9Zqo2t8BTvMTyTtpn3";
	static String master = "MKGoEF7qio9YHsfFBuQj02";
	static String host = "http://sdk.open.api.igexin.com/apiex.htm";

	/**
	 * 推送一个带有自定义链接的地址
	 * @param Title  推送的标题
	 * @param text   推送的文本内容
	 * @param icon   推送的图标
	 * @param iconUrl	推送图标的链接地址
	 * @param linkUrl	点击打开的页面  ［didong://push.app/openwith?数据］可打开原生界面
	 * @return
	 * @throws Exception
	 */
	public static LinkTemplate buildLinkTemplate_all(String Title , String text ,String icon ,String iconUrl , String linkUrl ) throws Exception {
		LinkTemplate template = new LinkTemplate();
		template.setAppId(appId);
		template.setAppkey(appkey);
		template.setTitle(Title);
		template.setText(text);
		if(icon != null )
		template.setLogo(icon);
		if(iconUrl != null){
			template.setLogoUrl(iconUrl);
		}
		template.setIsRing(true);
		template.setIsVibrate(true);
		template.setIsClearable(true);
		template.setUrl(linkUrl);
		// template.setPushInfo("actionLocKey", 1, "message", "sound",
		// "payload",
		// "locKey", "locArgs", "launchImage",1);
		return template;
	}
	/**
	 * 发送通知内容，强制打开应用程序
	 * @param title
	 * @param text
	 * @param icon
	 * @param iconUrl
	 * @return
	 */
	public static NotificationTemplate buildNotificationTemplate(String title , String text , String icon , String iconUrl) {
	    NotificationTemplate template = new NotificationTemplate();
	    // 设置APPID与APPKEY
	    template.setAppId(appId);
	    template.setAppkey(appkey);
	    // 设置通知栏标题与内容
	    template.setTitle(title);
	    template.setText(text);
	    // 配置通知栏图标
	    if(icon != null)
	    template.setLogo(icon);
	    // 配置通知栏网络图标
	    if(iconUrl != null){
	    	template.setLogoUrl(iconUrl);
	    }
	    // 设置通知是否响铃，震动，或者可清除
	    template.setIsRing(true);
	    template.setIsVibrate(true);
	    template.setIsClearable(true);
	    // 透传消息设置，1为强制启动应用，客户端接收到消息后就会立即启动应用；2为等待应用启动
	    template.setTransmissionType(1);
//	    template.setTransmissionContent("请输入您要透传的内容");
	    // 设置定时展示时间
	    // template.setDuration("2015-01-16 11:40:00", "2015-01-16 12:24:00");
	    return template;
	}
	/**
	 * 在通知栏显示一条含图标、标题等的通知，用户点击后弹出框，用户可以选择直接下载应用或者取消下载应用。（iOS不支持该模板）
	 * @param title		"请输入通知栏标题"
	 * @param content	"请输入通知栏内容"
	 * @param icon
	 * @param popTitle	"弹框标题"
	 * @param popContent"弹框内容"
	 * @param popImageUrl 设置弹框显示的图片
	 * @param loadTitle   下载标题
	 * @param loadIcon    下载图标
	 * @param loadUrl 下载地址   
	 * @return
	 */
	public static NotyPopLoadTemplate buildNotyPopLoadTemplate(String title , 
																String content ,
																String icon,
																String popTitle,
																String popContent,
																String popImageUrl,
																String loadTitle,
																String loadIcon,
																String loadUrl) {
	    NotyPopLoadTemplate template = new NotyPopLoadTemplate();
	    // 设置APPID与APPKEY
	    template.setAppId(appId);
	    template.setAppkey(appkey);
	    // 设置通知栏标题与内容
	    template.setNotyTitle(title);
	    template.setNotyContent(content);
	    // 配置通知栏图标
	    if(icon != null)
	    template.setNotyIcon(icon);
	    // 设置通知是否响铃，震动，或者可清除
	    template.setBelled(true);
	    template.setVibrationed(true);
	    template.setCleared(true);
	   
	    // 设置弹框标题与内容
	    template.setPopTitle(popTitle);
	    template.setPopContent(popContent);
	    // 设置弹框显示的图片
	    template.setPopImage(popImageUrl);
	    template.setPopButton1("下载");
	    template.setPopButton2("取消");
	   
	    // 设置下载标题
	    template.setLoadTitle("下载标题");
	    if(loadIcon != null)
	    template.setLoadIcon(loadIcon);
	    //设置下载地址        
	    template.setLoadUrl(loadUrl);
	    // 设置定时展示时间
	    // template.setDuration("2015-01-16 11:40:00", "2015-01-16 12:24:00");
	    return template;
	}
	/**
	 * 根据所传的Template来进行不同功能的推送
	 * @param template
	 * @return
	 */
	public static String sendNoticeALL(AbstractTemplate template){
		return sendNoticeWithTags(template , null);
	} 
	
	 /**
	  * 根据所传的Template来进行推送给不同Tag的用户
	  * @param template
	  * @param tagList
	  * @return
	  */
	public static String sendNoticeWithTags(AbstractTemplate template , List<String> tagList){
		IGtPush push = new IGtPush(host, appkey, master);
		AppMessage message = new AppMessage();
		message.setData(template);
		message.setOffline(true);
		message.setOfflineExpireTime(24 * 1000 * 3600); //
		if(!tagList.isEmpty()){
			message.setTagList(tagList);
		}
		List<String> appIdList = new ArrayList<String>();
		appIdList.add(appId);
		message.setAppIdList(appIdList);
		IPushResult ret = push.pushMessageToApp(message,"任务别名_toApp");
		return ret.getResponse().toString();
	} 
	public static void main(String[] args) {
		
	}
}
