package com.didong.basic.mq.manager;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.util.StringUtils;

import com.didong.basic.mq.container.DidongMqContainer;
import com.didong.basic.tools.collection.CollectionUtil;

/**
 * 
 * @ClassName:MqConsumerManager
 * @author: 韩旺坤
 * @Description:提供对队列消息消费者的管理，包括开启消费、关闭消费
 * @date:2015年11月17日 上午11:23:22
 */
public class MqConsumerManager
{
	// 监听容器列表，通过spring容器注入即可
	private List<DidongMqContainer> containerList;
    Logger logger = LoggerFactory.getLogger(MqConsumerManager.class);
    
    /**
     * 
     * @Title:start
     * @Description:开启队列监听
     * @param queueName 队列名称
     * void
     * @throws
     */
	public void start(String queueName)
	{
		logger.debug("开启队列："+(queueName==null?"null":queueName)+" 消费监听。。。 。。。");
		if(!StringUtils.isEmpty(queueName) && !CollectionUtil.isEmpty(containerList))
		{
			for(DidongMqContainer container:containerList)
			{
				String queue ="queue://"+queueName;
				if(queue.toLowerCase().equals(container.getListenerContainer().getDestination().toString().toLowerCase()))
				{
					container.getListenerContainer().start();
					break;
				}
			}
		}
	}
	
	/**
	 * 
	 * @Title:stop
	 * @Description:停止队列消息监听
	 * @param queueName
	 * void
	 * @throws
	 */
	public void stop(String queueName)
	{
		logger.debug("关闭队列："+(queueName==null?"null":queueName)+" 消费监听。。。 。。。");
		if(!StringUtils.isEmpty(queueName) && !CollectionUtil.isEmpty(containerList))
		{
			for(DidongMqContainer container:containerList)
			{
				String queue ="queue://"+queueName;
				if(queue.toLowerCase().equals(container.getListenerContainer().getDestination().toString().toLowerCase()))
				{
					container.getListenerContainer().stop();
					break;
				}
			}
		}
	}
	
	
    //set与get方法
	
	public List<DidongMqContainer> getContainerList() {
		return containerList;
	}

	public void setContainerList(
			List<DidongMqContainer> containerList) {
		this.containerList = containerList;
	}

}
