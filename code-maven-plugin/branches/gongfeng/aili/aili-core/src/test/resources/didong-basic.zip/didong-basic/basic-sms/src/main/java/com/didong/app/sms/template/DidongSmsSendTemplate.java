package com.didong.app.sms.template;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.alibaba.fastjson.JSON;
import com.didong.app.sms.bean.SmsMessage;
import com.didong.app.sms.bean.Suppliers;
import com.didong.app.sms.http.SendSmsHttpRequest;
import com.didong.app.sms.rule.DistRule;
import com.didong.basic.mq.template.DidongJmsTemplate;
import com.didong.basic.mq.thread.SendMessageRunnable;
import com.didong.basic.tools.other.HttpInvoker;

public class DidongSmsSendTemplate implements SmsSendTemplate,InitializingBean
{
	SendSmsHttpRequest httpClient;
	DistRule distRule;
	HttpInvoker httpInvoker;
	@Override
	public void syncSendMessage(SmsMessage sms)
	{
		Suppliers sup = distRule.selectSup();
		sms.setSup(sup);
		this.httpClient.send(sms);        
	}

	DidongJmsTemplate didongJmsTemplate;
	@Override
	public void asynSendMessage(SmsMessage sms)
	{
		SendMessageRunnable runnable = new SendMessageRunnable();
        runnable.setJmsTemplate(didongJmsTemplate.getJmsTemplate());
        runnable.setJsonMessage(JSON.toJSONString(sms));
        //异步发送
        this.threadPool.execute(runnable);
	}
	
	@Override
	public void afterPropertiesSet() throws Exception
	{
		// 1、创建线程池
		this.threadPool = new ThreadPoolTaskExecutor();
		this.threadPool.setCorePoolSize(corePoolSize);
		this.threadPool.setMaxPoolSize(maxPoolSize);
		this.threadPool.setDaemon(daemon);
		this.threadPool.setKeepAliveSeconds(keepAliveSeconds);
		this.threadPool.afterPropertiesSet();
		
		// 2、创建Http客户端发送工具类
		httpClient = new SendSmsHttpRequest();
		httpClient.setHttpClient(httpInvoker);
	}
	
	private ThreadPoolTaskExecutor threadPool;
	// 初始线程数
	private int corePoolSize;
	// 最大线程数
	private int maxPoolSize;
	// 是否后台线程
	private boolean daemon;
	// 线程存储时间，单位：s
	private int keepAliveSeconds;
	public int getCorePoolSize() {
		return corePoolSize;
	}

	public void setCorePoolSize(int corePoolSize) {
		this.corePoolSize = corePoolSize;
	}

	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public void setMaxPoolSize(int maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public boolean isDaemon() {
		return daemon;
	}

	public void setDaemon(boolean daemon) {
		this.daemon = daemon;
	}

	public int getKeepAliveSeconds() {
		return keepAliveSeconds;
	}

	public void setKeepAliveSeconds(int keepAliveSeconds) {
		this.keepAliveSeconds = keepAliveSeconds;
	}

	public DistRule getDistRule() {
		return distRule;
	}

	public void setDistRule(DistRule distRule) {
		this.distRule = distRule;
	}

	public HttpInvoker getHttpInvoker() {
		return httpInvoker;
	}

	public void setHttpInvoker(HttpInvoker httpInvoker) {
		this.httpInvoker = httpInvoker;
	}

	public DidongJmsTemplate getDidongJmsTemplate() {
		return didongJmsTemplate;
	}

	public void setDidongJmsTemplate(DidongJmsTemplate didongJmsTemplate) {
		this.didongJmsTemplate = didongJmsTemplate;
	}
	
	

}
