package com.didong.basic.tools.collection;

import java.util.Collection;

/**
 * 
 * @ClassName:CollectionUtil
 * @author: 韩旺坤
 * @Description:集合工具类
 * @date:2015年10月25日 下午10:36:16
 */
public class CollectionUtil 
{
   /**
    * 
    * @Title:isEmpty
    * @Description:判断集合是否为空
    * @param collec
    * @return
    * boolean
    * @throws
    */
   public static boolean isEmpty(Collection collec)
   {
	   boolean empty = true;
	   if(collec != null && collec.size() > 0)
	   {
		   empty = false;
	   }
	   
	   return empty;
   }
}
