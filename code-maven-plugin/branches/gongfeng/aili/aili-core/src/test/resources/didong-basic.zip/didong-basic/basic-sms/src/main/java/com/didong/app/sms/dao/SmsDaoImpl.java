package com.didong.app.sms.dao;

import java.util.List;

import com.didong.app.sms.bean.SmsGateWay;
import com.didong.app.sms.bean.SmsPercentage;
import com.didong.app.sms.bean.Suppliers;
import com.didong.basic.dal.BaseDao;

public class SmsDaoImpl implements SmsDao
{
    private BaseDao baseDao;

	public void setBaseDao(BaseDao baseDao)
	{
		this.baseDao = baseDao;
	}
	
	@Override
	public List<Suppliers> selectSups()
	{
		return this.baseDao.selectList("service.selectSups");
	}

	@Override
	public List<SmsGateWay> selectGateWay()
	{
		return this.baseDao.selectList("service.selectGateWay");
	}

	@Override
	public List<SmsPercentage> selectPercentage()
	{
		return this.baseDao.selectList("service.selectPercentage");
	}

}
