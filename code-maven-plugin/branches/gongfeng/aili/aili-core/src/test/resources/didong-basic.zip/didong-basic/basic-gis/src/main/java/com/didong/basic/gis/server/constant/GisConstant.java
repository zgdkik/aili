package com.didong.basic.gis.server.constant;

import java.text.DecimalFormat;

/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 下午4:08:44
 * 模块路径：com.didong.basic.gis.server.constant.GisConstant
 * 更新记录：
 */
public class GisConstant {
	
	public static DecimalFormat dfm = new DecimalFormat("#####0.0");
	
	public static DecimalFormat dfa = new DecimalFormat("#####0");
	
	// 经度
	public static String LONGITUDE = "lng";
	
	// 纬度
	public static String LATITUDE = "lat";
	
	// 百度地图-地址常量
	public static String BAIDU_MAP_ADDR = "#ADDRESS#";
	
	// 百度API的AK值
	public static String BAIDU_MAP_AK_VAL = "l81pGHjScqV13vnAdqjGUFew";
	
	// 百度地图调用URL
	public static String BAIDU_MAL_REQ_URL = 
			"http://api.map.baidu.com/geocoder/v2/?output=json&address=" + BAIDU_MAP_ADDR + "&ak=" + BAIDU_MAP_AK_VAL;

}

