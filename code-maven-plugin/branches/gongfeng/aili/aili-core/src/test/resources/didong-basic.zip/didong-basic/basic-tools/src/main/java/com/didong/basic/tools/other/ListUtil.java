package com.didong.basic.tools.other;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 处理list 的工具类
 * @author wangyudong
 * @version   
 * @see       
 * @since
 */
public class ListUtil {
    
    
    /**
     * 根据对象的一个属性，把该对象列表分组（相同的属性作为map的key ， 对应的对象数组作为value）
     * @param list
     * @param propertyName
     * @return
     */
    public static <T> Map<Object,List<T>> groupList(List<T> list , String propertyName){
        if(list==null){
            return null;
        }
        Map<Object,List<T>> map = new HashMap<Object,List<T>>();
        
        if(list.size()==0){
            return map;
        }
        
        for(T bean : list){
            Object key = ReflectUtil.getFieldValue(bean , propertyName);
            if(map.containsKey(key)){
                List<T> mlist = map.get(key);
                mlist.add(bean);
            }else{
                List<T> mlist = new ArrayList<T>();
                mlist.add(bean);
                map.put(key , mlist);
            }
        }
        return map;
    }
    
    
    
    /**
     * 分组查询，类似sql查询中的group by
     * @param list
     * @param columnNames 需要分组查询的字段数组，
     *                       支持五种组函数运算  ：
     *                       sum(columnName) , max(columnName) , min(columnName) , avg(columnName) , count(columnName)
     * @param zlass 要转换的类型
     * @param whereCondition 列表查询过滤器（过滤不需要的对象）
     * @return 返回group by后的list 
     */
    public static <T1, T2> List<T1> groupBy(List<T2> list , String[] columnNames , 
            Class<T1> zlass , WhereCondition<T2> whereCondition){
        if(list==null){
            return null;
        }
        
        List<T1> rlist = new ArrayList<T1>();
        if(list.size()==0){
            return rlist;
        }
        
        List<GroupValue> gvlist = new ArrayList<GroupValue>();
        for(int index=0 ; index<list.size() ; index++){
            T2 bean = list.get(index);
            if(whereCondition!=null){
                if(whereCondition.filter(bean,index)==null){
                    continue;
                }
            }
            GroupValue gv = new GroupValue(bean,columnNames);
            boolean contain = false;
            for(int i=0 ; i<gvlist.size() ;i++){
                GroupValue gv_i = gvlist.get(i);
                if(gv.equals(gv_i)){
                    contain = true;
                    int size = gv_i.getSize();
                    int[] types = gv_i.getFieldTypes();
                    Object[] fvs_gv_i = gv_i.getFieldValues();
                    Object[] fvs_gv   = gv.getFieldValues();
                    int[] fvcs_gv_i = gv_i.getFieldValueCounts();
                    int[] fvcs_gv   = gv.getFieldValueCounts();
                    
                    for(int ti=0 ;ti<size ; ti++){
                        fvcs_gv_i[ti] += fvcs_gv[ti];
                        
                        if(types[ti]==GroupValue.TYPE_MAX){
                            fvs_gv_i[ti] = GroupValue.MAX(fvs_gv_i[ti], fvs_gv[ti]);
                        }
                        if(types[ti]==GroupValue.TYPE_MIN){
                            fvs_gv_i[ti] = GroupValue.MIN(fvs_gv_i[ti], fvs_gv[ti]);
                        }
                        if(types[ti]==GroupValue.TYPE_SUM){
                            fvs_gv_i[ti] = GroupValue.SUM(fvs_gv_i[ti], fvs_gv[ti]);
                        }
                        if(types[ti]==GroupValue.TYPE_AVG){
                            fvs_gv_i[ti] = GroupValue.SUM(fvs_gv_i[ti], fvs_gv[ti]);
                        }
                    }
                    break;
                }
            }
            if(!contain){
                gvlist.add(gv);
            }
        }
        
        for(GroupValue gv : gvlist){
            int size = gv.getSize();
            int[] types = gv.getFieldTypes();
            Object[] values = gv.getFieldValues();
            int[] valueCounts = gv.getFieldValueCounts();
            for(int i=0 ; i<size ;i++){
                if(types[i]==GroupValue.TYPE_AVG){
                    values[i]=GroupValue.AVG( values[i] , valueCounts[i]);
                }
                if(types[i]==GroupValue.TYPE_COUNT){
                    values[i]=new Integer(valueCounts[i]);
                }
            }
            rlist.add(gv.toBean(zlass));
        }
        return rlist;
    }
    
    
    
    /**
     * 分组查询，类似sql查询中的group by
     * @param list
     * @param columnNames 需要分组查询的字段数组，
     *                      支持五种组函数运算 ：
     *                      sum(columnName) , max(columnName) , min(columnName), avg(columnName) , count(columnName)
     * @param zlass 要转换的类型
     * 
     * @return 返回group by后的list 
     */
    public static <T1,T2> List<T2> groupBy(List<T1> list , String[] columnNames , Class<T2> zlass){
        return groupBy(list ,columnNames , zlass , null);
    }
    
    
    /**
     * 分组查询 , ，类似sql查询中的group by
     * @param list
     * @param columnNames 需要分组查询的字段数组，
     *                      支持五种组函数运算 ：
     *                       sum(columnName) , max(columnName) , min(columnName), avg(columnName) , count(columnName)
     * @param whereCondition 列表查询过滤器（过滤不需要的对象）
     * @return  返回group by后的list 
     */
    public static <T> List<T> groupBy(List<T> list , String[] columnNames , 
            WhereCondition<T> whereCondition){
        if(list==null || list.size()==0){
            return list;
        }
        @SuppressWarnings("unchecked")
        Class<T> zlass = (Class<T>)list.get(0).getClass();
        return groupBy( list ,  columnNames ,zlass , whereCondition);
    }
    
    
    
    /**
     * 分组查询 , ，类似sql查询中的group by
     * @param <T>
     * @param list
     * @param columnNames 需要分组查询的字段数组，
     *                      支持五种组函数运算 ：
     *                      sum(columnName) , max(columnName) , min(columnName), avg(columnName) , count(columnName)
     * @return  返回group by后的list 
     */
    public static <T> List<T> groupBy(List<T> list , String[] columnNames){
        WhereCondition<T> whereCondition = null;
        return groupBy(list , columnNames , whereCondition);
    }
    
    
    
    /**
     * 转换，将存放map 的list 转换成为  指定存放指定类的list
     * @param mlist
     * @param zlass
     * @return
     */
    public static <T> List<T> transform(List<Map> mlist , Class<T> zlass){
        if(mlist==null){
            return null;
        }
        List<T> tlist = new ArrayList<T>();
        if(mlist.size()==0){
            return tlist;
        }
        for(Map map:mlist){
            T bean = ReflectUtil.map2Bean(map, zlass);
            tlist.add(bean);
        }
        return tlist;
    }
    
    
    /**
     * 转换，将存放bean 对象的list 转换成为一个 存放map 的list
     * TODO 一句话功能简述
     * TODO 功能详细描述
     * @param mlist
     * @return
     */
    public static List<Map> transform(List list){
        if(list==null){
            return null;
        }
        List<Map> mlist = new ArrayList<Map>();
        if(list.size()==0){
            return mlist;
        }
        for(Object bean : list){
            Map map = ReflectUtil.bean2Map(bean);
            mlist.add(map);
        }
        return mlist;
    }
    
    /**
     * 拆分list汇总子list
     * @param list
     * @return
     */
    public static <T> List<List<T>> splitList(List<T> list, int groupSize){
        List<List<T>> totalList = new ArrayList<List<T>>();
        int totalcount = list.size();
        int pagecount = 0;
        int m = totalcount % groupSize;

        if (m > 0) {
            pagecount = totalcount / groupSize + 1;
        } else {
            pagecount = totalcount / groupSize;
        }

        for (int i = 1; i <= pagecount; i++) {
            List<T> subList = null;
            
            if (m == 0) {
                subList = list.subList(
                        (i - 1) * groupSize,
                        groupSize * (i));
            } else {
                if (i == pagecount) {
                    subList = list.subList(
                            (i - 1) * groupSize,
                            totalcount);
                } else {
                    subList = list.subList(
                            (i - 1) * groupSize,
                            groupSize * (i));
                }
            }

            if(subList != null) {
                totalList.add(subList);
            }
        }
        return totalList;
    }

}
