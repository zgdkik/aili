package com.didong.basic.tools.other;

import java.util.Random;

/**
 * 系统名称：递咚APP-开发平台
 * 模块名称：
 * 模块描述：随机数处理工具类
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年11月29日 下午7:22:11
 * 模块路径：com.didong.basic.dal.util.RandomUtil
 * 更新记录：
 */
public class RandomUtil {
	
	// 随机数格式
	private static String numberChar = "0123456789";

	/**
	 * 功能描述：根据系统时间获得指定位数的随机数
	 * 模块作者：zouyong-ocean 
	 * 开发时间：2015年9月2日 下午12:22:35
	 * 更新记录：
	 * 返回数据：String 获得的随机数
	 */
    public static String getRandom(int size) {
        Long seed = System.currentTimeMillis();	// 获得系统时间，作为生成随机数的种子
        StringBuffer str = new StringBuffer();	// 装载生成的随机数
        Random random = new Random(seed);		// 调用种子生成随机数
        for (int i = 0; i < size; i++) {
        	str.append(numberChar.charAt(
        			random.nextInt(numberChar.length())));
        }
        return str.toString();
    }
	
}
