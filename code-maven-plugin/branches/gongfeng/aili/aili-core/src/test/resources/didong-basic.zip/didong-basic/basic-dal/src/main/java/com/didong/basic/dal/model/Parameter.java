package com.didong.basic.dal.model;

/**
 * 
 * @ClassName:Parameter
 * @author: 韩旺坤
 * @Description:t_app_module_param
 * @date:2015年10月13日 下午11:36:27
 */
public class Parameter {
	private long id;
	/**
	 * 模块编码
	 */
	private String moduleCode;
	/**
	 * 参数名称
	 */
	private String paramName;
	/**
	 * 参数编码
	 */
	private String paramCode;
	/**
	 * 参数值
	 */
	private String paramValue;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	public String getParamCode() {
		return paramCode;
	}

	public void setParamCode(String paramCode) {
		this.paramCode = paramCode;
	}

	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}

}
