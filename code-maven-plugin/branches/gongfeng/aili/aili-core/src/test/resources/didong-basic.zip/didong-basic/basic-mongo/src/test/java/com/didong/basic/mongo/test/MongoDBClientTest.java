package com.didong.basic.mongo.test;

import java.io.File;
import java.util.Date;

import com.mongodb.DB;
import com.mongodb.DBCursor;
import com.mongodb.Mongo;
import com.mongodb.gridfs.GridFS;
import com.mongodb.gridfs.GridFSInputFile;

/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：MongoDB关系型数据库-管理
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 上午10:08:43
 * 模块路径：com.didong.basic.mongo.test.MongoDBClientTest
 * 更新记录：
 */
public class MongoDBClientTest {

	public static void main(String[] args) {
		
		initData4GridFS();
	}

	private static void initData4GridFS() {
		
		long start = new Date().getTime();
		try {
			Mongo db = new Mongo("127.0.0.1", 27017);
			DB mydb = db.getDB("wlb");
			File f = new File("D:\\SERVER\\DB-SERVER\\COBAR\\cobar-server-1.2.7\\lib\\log4j-1.2.17.jar");
			GridFS myFS = new GridFS(mydb); 
			GridFSInputFile inputFile = myFS.createFile(f);
			inputFile.save();
			
			DBCursor cursor = myFS.getFileList();
			while(cursor.hasNext()) {
				System.out.println(cursor.next());
			}
			db.close();
			long endTime = new Date().getTime();
			System.out.println(endTime - start);
			System.out.println((endTime - start) / 10000000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
