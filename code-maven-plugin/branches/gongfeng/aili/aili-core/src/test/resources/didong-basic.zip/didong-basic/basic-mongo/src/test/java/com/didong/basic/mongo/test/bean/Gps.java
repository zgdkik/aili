package com.didong.basic.mongo.test.bean;

public class Gps {
	// 经度
	private double lat;
	// 纬度
	private double lng;

	public double getLat() {
		return lat;
	}

	public void setLat(double lat) {
		this.lat = lat;
	}

	public double getLng() {
		return lng;
	}

	public void setLng(double lng) {
		this.lng = lng;
	}

}
