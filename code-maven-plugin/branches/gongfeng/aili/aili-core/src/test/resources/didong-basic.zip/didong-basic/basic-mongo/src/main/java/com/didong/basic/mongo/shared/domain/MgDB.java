package com.didong.basic.mongo.shared.domain;

import java.io.Serializable;

/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 上午10:53:14
 * 模块路径：com.didong.basic.mongo.shared.domain.BaseDataBase
 * 更新记录：
 */
public class MgDB implements Serializable {

	/**
	 * 序列化ID
	 */
	private static final long serialVersionUID = 5961202682684141802L;

	private String dbAddress;	//数据库地址

	private int dbPort;			//数据库端口

	private String dbType; 		//数据库类型

	private String dbUrl; 		//数据库URL

	private String dbDriver; 	//数据库驱动

	private String dbAccount;	//数据库账号

	private String dbPassword;	//数据库密码

	public MgDB() {
		// TODO Auto-generated constructor stub
	}

	//构造函数
	public MgDB(String dbAddress, int dbPort) {
		this.dbAddress = dbAddress;
		this.dbPort = dbPort;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:38
	 * @return the dbAddress
	 */
	public String getDbAddress() {
		return dbAddress;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbAddress the dbAddress to set
	 */
	public void setDbAddress(String dbAddress) {
		this.dbAddress = dbAddress;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @return the dbPort
	 */
	public int getDbPort() {
		return dbPort;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbPort the dbPort to set
	 */
	public void setDbPort(int dbPort) {
		this.dbPort = dbPort;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @return the dbType
	 */
	public String getDbType() {
		return dbType;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbType the dbType to set
	 */
	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @return the dbUrl
	 */
	public String getDbUrl() {
		return dbUrl;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbUrl the dbUrl to set
	 */
	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @return the dbDriver
	 */
	public String getDbDriver() {
		return dbDriver;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbDriver the dbDriver to set
	 */
	public void setDbDriver(String dbDriver) {
		this.dbDriver = dbDriver;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @return the dbAccount
	 */
	public String getDbAccount() {
		return dbAccount;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbAccount the dbAccount to set
	 */
	public void setDbAccount(String dbAccount) {
		this.dbAccount = dbAccount;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @return the dbPassword
	 */
	public String getDbPassword() {
		return dbPassword;
	}

	/**
	 * 作者：zouyong
	 * 时间：2015年10月31日 上午11:06:39
	 * @param dbPassword the dbPassword to set
	 */
	public void setDbPassword(String dbPassword) {
		this.dbPassword = dbPassword;
	}
	
}
