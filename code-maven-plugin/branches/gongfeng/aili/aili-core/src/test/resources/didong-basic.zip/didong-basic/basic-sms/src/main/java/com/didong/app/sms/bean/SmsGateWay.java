package com.didong.app.sms.bean;

/**
 * 
 * @ClassName:SmsGateWay
 * @author: 韩旺坤
 * @Description:短信网关
 * @date:2015年11月16日 下午5:23:00
 */
public class SmsGateWay {
	private int id;
	// 短信供应商编码
	private String supCode;
	// 是否开启
	private int isOpen;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSupCode() {
		return supCode;
	}

	public void setSupCode(String supCode) {
		this.supCode = supCode;
	}

	public int getIsOpen() {
		return isOpen;
	}

	public void setIsOpen(int isOpen) {
		this.isOpen = isOpen;
	}



}
