package com.didong.app.sms.http;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.didong.app.sms.bean.SmsMessage;
import com.didong.basic.tools.other.HttpInvoker;

/**
 * 
 * @ClassName:SendSmsHttpRequest
 * @author: 韩旺坤
 * @Description:采用连接池
 * @date:2015年11月22日 下午1:48:23
 */
public class SendSmsHttpRequest
{
	Logger LOG = LoggerFactory.getLogger(SendSmsHttpRequest.class);
	//http调用工具类
	HttpInvoker httpClient;
	
    public HttpInvoker getHttpClient() {
		return httpClient;
	}

	public void setHttpClient(HttpInvoker httpClient) {
		this.httpClient = httpClient;
	}

	public Object send(SmsMessage msg)
    {
    	Object result = null;
    	Map<String,String> params = JSON.parseObject(msg.getSup().getOtherParams(), Map.class);
    	params.put(msg.getSup().getContentField(), msg.getContent());
    	params.put(msg.getSup().getPhoneField(), msg.getPhoneNumbers());
    	try
    	{
			result = this.httpClient.doPost(msg.getSup().getSmsUrl(), params);
		} catch (Exception e) 
		{
			LOG.error("短信发送失败:"+JSON.toJSONString(msg), e);
			throw new RuntimeException(e);
		}
    	return result;
    }

}
