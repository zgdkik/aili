package com.didong.basic.zk.manage;



import java.util.List;
import java.util.ResourceBundle;

import org.apache.curator.RetryPolicy;
import org.apache.curator.framework.CuratorFramework;
import org.apache.curator.framework.CuratorFrameworkFactory;
import org.apache.curator.framework.api.UnhandledErrorListener;
import org.apache.curator.framework.recipes.cache.NodeCache;
import org.apache.curator.framework.recipes.cache.PathChildrenCache;
import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.apache.curator.framework.state.ConnectionState;
import org.apache.curator.framework.state.ConnectionStateListener;
import org.apache.curator.retry.ExponentialBackoffRetry;
import org.apache.curator.utils.CloseableUtils;
import org.apache.zookeeper.CreateMode;
import org.apache.zookeeper.data.Stat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.didong.basic.zk.Constants;
import com.didong.basic.zk.processor.Processor;
import com.google.common.collect.Lists;


/**
 * ZK manager that encapsulates zk connection and registration and retry mechanism
 * 
 * @author 韩旺坤
 * @version
 * @see
 * @since
 */
public class ZookeeperManager implements
        InitializingBean, DisposableBean {

    private static  final Logger LOG = LoggerFactory.getLogger(ZookeeperManager.class);

    /**
     * zookeeper curator framework client
     */
    private CuratorFramework zkClient;

    /**
     * zookeeper listeners
     */
    protected List<Processor> processors;
    protected List<Processor> reProcessors;

    public void setProcessors(List<Processor> processors) {
        this.processors = processors;
    }
    
    public void setReProcessors(List<Processor> reProcessors) {
        this.reProcessors = reProcessors;
    }

    /**
     * zookeeper url
     */
    private String zookeeperUrls;
    
    private int baseSleepTimeMs = Constants.DEFAULT_BASE_SLEEP_TIME_MS;
    private int maxRetries = Constants.DEFAULT_MAX_RETRIES;
    private int sessionTimeoutMs = Constants.DEFAULT_SESSION_TIMEOUT_MS;
    private int connectionTimeoutMs = Constants.DEFAULT_CONNECTION_TIMEOUT_MS;

    public void setZookeeperUrls(String zookeeperUrls) {
        this.zookeeperUrls = zookeeperUrls;
    }

    public void setBaseSleepTimeMs(int baseSleepTimeMs) {
        this.baseSleepTimeMs = baseSleepTimeMs;
    }

    public void setMaxRetries(int maxRetries) {
        this.maxRetries = maxRetries;
    }

    public void setSessionTimeoutMs(int sessionTimeoutMs) {
        this.sessionTimeoutMs = sessionTimeoutMs;
    }

    public void setConnectionTimeoutMs(int connectionTimeoutMs) {
        this.connectionTimeoutMs = connectionTimeoutMs;
    }

    /**
     * Node cache list
     */
    private List<NodeCache> ncLst = Lists.newArrayList();
    private List<PathChildrenCache> pccLst = Lists.newArrayList();
    
    public NodeCache getNodeCache(String path)
    {
        NodeCache nc = new NodeCache(zkClient, path);
        ncLst.add(nc);
        return nc;
    }
    
    public PathChildrenCache getPathChildrenCache(String path){
        PathChildrenCache pcc = new PathChildrenCache(zkClient, path, true);
        pccLst.add(pcc);
        return pcc;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        ResourceBundle bundle = null;
        try {
            bundle = ResourceBundle.getBundle("zkconfig");
        } catch (Exception e) {
            LOG.info("zkconfig.properties not set, using default value.");
        }
        if (!StringUtils.hasText(zookeeperUrls)) {
            Assert.notNull(bundle, "zkconfig.properties should exist when zookeeper url has not been injected in client.");
            zookeeperUrls = bundle.getString(Constants.CONSTANT_ZOOKEEPER_URL);
            Assert.hasText(zookeeperUrls, "zookeeper url has not been set in zkconfig.properties.");
        }
        if (bundle != null) {
            String str = null;
            try {
                str = bundle
                        .getString(Constants.CONSTANT_ZOOKEEPER_BASE_SLEEP_TIME);
                if (StringUtils.hasText(str)) {
                    baseSleepTimeMs = Integer.parseInt(str);
                }
            } catch (Exception e) {
                LOG.info("Zookeeper base sleep time not set, using default value.");
            }
            try {
                str = bundle
                        .getString(Constants.CONSTANT_ZOOKEEPER_MAX_RETRIES);
                if (StringUtils.hasText(str)) {
                    maxRetries = Integer.parseInt(str);
                }
            } catch (Exception e) {
                LOG.info("Zookeeper max retries not set, using default value.");
            }
            try {
                str = bundle
                        .getString(Constants.CONSTANT_ZOOKEEPER_SESSION_TIMEOUT);
                if (StringUtils.hasText(str)) {
                    sessionTimeoutMs = Integer.parseInt(str);
                }
            } catch (Exception e) {
                LOG.info("Zookeeper session timeout not set, using default value.");
            }
            try {
                str = bundle
                        .getString(Constants.CONSTANT_ZOOKEEPER_CONNECTION_TIMEOUT);
                if (StringUtils.hasText(str)) {
                    connectionTimeoutMs = Integer.parseInt(str);
                }
            } catch (Exception e) {
                LOG.info("Zookeeper connection timeout not set, using default value.");
            }
        }
        LOG.info("Zookeeper url is {}.", new Object[] { zookeeperUrls });
        LOG.info("Zookeeper base sleep time is {} ms.", new Object[] { baseSleepTimeMs });
        LOG.info("Zookeeper max retries is {}.", new Object[] { maxRetries });
        LOG.info("Zookeeper session timeout is {} ms.", new Object[] { sessionTimeoutMs });
        LOG.info("Zookeeper connection timeout is {} ms.", new Object[] { connectionTimeoutMs });
        /*
         * ---------------- Retry Extension ----------------
         * Curator内部实现的几种重试策略: 
         * ExponentialBackoffRetry:重试指定的次数, 且每一次重试之间停顿的时间逐渐增加.
         * RetryNTimes:指定最大重试次数的重试策略
         * RetryOneTime:仅重试一次
         * RetryUntilElapsed:一直重试直到达到规定的时间
         */
        RetryPolicy retryPolicy = new ExponentialBackoffRetry(baseSleepTimeMs,
                maxRetries);
        zkClient = CuratorFrameworkFactory.builder().connectString(zookeeperUrls)
                .connectionTimeoutMs(connectionTimeoutMs)
                .sessionTimeoutMs(sessionTimeoutMs)
                .retryPolicy(retryPolicy)
                .build();
        registerReconnectProcessors(zkClient);
        zkClient.start();
    }

    /**
     * register reconnect initialization listener when connected
     * 
     * @param zkClient
     */
    private void registerReconnectProcessors(CuratorFramework zkClient) {
        zkClient.getConnectionStateListenable().addListener(
                new ConnectionStateListener() {

                    @Override
                    public void stateChanged(CuratorFramework client,
                            ConnectionState newState) {
                        LOG.info("Connection state changed: {}", newState);
                        if (newState == ConnectionState.RECONNECTED) {
                            try {
                                processorExecute(reProcessors);
                            } catch (Exception e) {
                                LOG.error("Processor execute error happened when re-connected.", e);
                            }
                        }
                    }

                });
        
        zkClient.getUnhandledErrorListenable().addListener(
                new UnhandledErrorListener() {

                    @Override
                    public void unhandledError(String message, Throwable e) {
                        LOG.error("CuratorFramework unhandledError: {}", message, e);
                    }
                });
    }

    public CuratorFramework getObject(){
        return zkClient;
    }

    @Override
    public void destroy() throws Exception {
        if(ncLst.size() > 0) {
            for(NodeCache nc : ncLst) {
                CloseableUtils.closeQuietly(nc);
            }
        }
        if(pccLst.size() > 0) {
            for(PathChildrenCache pcc : pccLst) {
                CloseableUtils.closeQuietly(pcc);
            }
        }
        CloseableUtils.closeQuietly(zkClient);
    }
    
    /**
     * processor execute
     * @param zkMgr
     * @throws Exception 
     */
    public void processorExecute() throws Exception {
        processorExecute(processors);
    }
    
    /**
     * processor execute
     * @param zkMgr
     * @throws Exception 
     */
    public void processorExecute(List<Processor> processors) throws Exception {
        if(processors != null && processors.size() > 0) {
            for (Processor processor : processors) {
                processor.execute(this);
            }
        }
    }
    
    public void createNode(String path, byte[] data, CreateMode mode) throws Exception {
        zkClient.
            create().
            creatingParentsIfNeeded().
            withMode(mode).
            forPath(path);
        
        if (data != null && data.length > 0) {
            zkClient.
                setData().
                forPath(path, data);
        }
    }
    
    public void createOrUpdateNode(String path, byte[] data) throws Exception {
        if (zkClient.checkExists().forPath(path) == null) {
            createNode(path, data, CreateMode.PERSISTENT);
        } else {
            setData4Node(path, data);
        }
    }
    
    public void createOrUpdateNode(String path, byte[] data, CreateMode mode) throws Exception {
        if (zkClient.checkExists().forPath(path) == null) {
            createNode(path, data, mode);
        } else {
            setData4Node(path, data);
        }
    }
    
    public void createNode(String path, CreateMode mode) throws Exception {
        createNode(path, null, mode);
    }
    
    public void createNode(String path) throws Exception {
        createNode(path, null, CreateMode.PERSISTENT);
    }
    
    public void createNodes(List<String> paths) throws Exception {
        if (paths != null && paths.size() > 0) {
            for (String path : paths) {
                createNode(path);
            }
        }
    }
    
    public Stat setData4Node(String path, byte[] data) throws Exception {
        if (data == null || data.length == 0 || zkClient.checkExists().forPath(path) == null) {
            return null;
        }
        Stat stat = zkClient.setData().forPath(path, data);
        return stat;
    }

    public void delNode(String path) throws Exception {
        if (zkClient.checkExists().forPath(path) == null) return;
        zkClient.delete().forPath(path);
    }
    
    public void delNodes(List<String> paths) throws Exception {
        if (paths != null && paths.size() > 0) {
            for (String path : paths) 
            {
                delNode(path);
            }
        }
    }
    
    public byte[] getNodeData(String path) throws Exception {
        if (zkClient.checkExists().forPath(path) == null) return null;
        byte[] bytes = zkClient.getData().forPath(path);
        return bytes;
    }
    
    public List<String> getChildrenNode(String path) throws Exception {
        return zkClient.getChildren().forPath(path);
    }
    
    /**
     * 
     * @Title:isExistNode
     * @Description:判断一个指定路径的节点是否存在
     * @param path
     * @return
     * @throws Exception
     * boolean
     * @throws
     */
    public boolean isExistNode(String path) throws Exception
    {
    	return this.zkClient.checkExists().forPath(path) != null;
    }
    
    /**
     * 
     * @Title:getDistLock
     * @Description:根据指定的路径获得分布式锁
     * @param path
     * @return
     * InterProcessMutex
     * @throws
     */
    public InterProcessMutex getDistLock(String path)
    {
    	InterProcessMutex lock = new InterProcessMutex(zkClient,path);
    	return lock;
    }
}
