package com.didong.basic.tools.other;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.log4j.Logger;

/**
 * 
 * TODO 对数据进行Gzip压缩与解压缩
 * TODO 相对于CompressObjectUtil来说，它压缩率高，但是它的压缩时间与解压缩时间比较长
 * @author    韩旺坤
 * @version   
 * @see       
 * @since    2015年3月18日
 */
public class GzipCompress 
{
    //打印日志
    private static Logger logger = Logger.getLogger(GzipCompress.class);
    
    /**
     * 
     * TODO 压缩内存数据
     * TODO 功能详细描述
     * @param orderCode->订单编码
     * @param src->源字节数组
     * @return
     * @since 2015年3月18日
     */
    public static byte[] compressBytes(byte[] src)
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        GZIPOutputStream gzipOut = null;
        try 
        {
            logger.info("压缩【前】分配过程日志字节数->"+src.length);
            gzipOut = new GZIPOutputStream(baos);
            gzipOut.write(src);
            gzipOut.finish();
            gzipOut.flush();
            byte[] after = baos.toByteArray();
            logger.info("压缩【后】分配过程日志字节数->"+after.length);
            //返回压缩后的数据
            return after;
        } 
        catch (IOException e) 
        {
            e.printStackTrace();
            return null;
        }
        finally{
            try 
            {
                baos.close();
                gzipOut.close();
            } catch (IOException e) 
            {
                e.printStackTrace();
            }

        }
    }
    
    /**
     * 
     * TODO 解压缩内存中的被压缩数据
     * TODO 功能详细描述
     * @param orderCode->订单编码
     * @param src->已经被Gzip压缩过的源字节数组
     * @return
     * @since 2015年3月18日
     */
    public static byte[] uncompressBytes(byte[] src)
    {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ByteArrayInputStream bais = new ByteArrayInputStream(src);
        byte[] buff = new byte[8*1024];
        int n = -1;
        GZIPInputStream gzip = null;
        try 
        {
            logger.info("解压缩【前】分配过程日志字节数->"+src.length);
            gzip = new GZIPInputStream(bais);
            while((n=gzip.read(buff))!=-1)
            {
                baos.write(buff, 0, n);
            }
            byte[] after = baos.toByteArray();
            logger.info("解压缩【后】分配过程日志字节数->"+after.length);
            return after;
        } catch (IOException e) 
        {
            e.printStackTrace();
            return null;
        }
        finally
        {
            try 
            {
                baos.close();
                bais.close();
                gzip.close();
            } catch (IOException e) 
            {
                e.printStackTrace();
            } 
        }
    }
}
