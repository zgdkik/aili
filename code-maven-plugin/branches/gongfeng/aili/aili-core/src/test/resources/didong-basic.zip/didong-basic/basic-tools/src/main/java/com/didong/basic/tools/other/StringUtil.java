package com.didong.basic.tools.other;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

/**
 * 字符都换
 * @author wangyudong
 * @version   
 * @see       
 * @since
 */
public class StringUtil {
    
    
    /**
     * 是否在数组中
     * @param value
     * @param array
     * @return
     */
    public static <T> boolean inArray(T value , T[] array){
        for(T a : array){
            if(a.equals(value)){
                return true;
            }
        }
        return false;
    }
    
    
    /**
     * 一个字符串的byteLength
     * @param str
     * @return
     */
    public static int byteLength(String str){
        if(str == null || str.length() == 0) {
            return 0;
        }
        int count = 0;
        char[] chs = str.toCharArray();
        for(int i = 0; i < chs.length; i++) {
            count += (chs[i] > 0xff) ? 2 : 1;
        }
        return count;
    }
    
    
    /**
     * 根据最大的byte size 获得 子字符串
     * @param str
     * @param maxByteLength
     * @return
     */
    public static String subStringByteLength(String str , int maxByteLength){
        if(str==null || str.length()==0){
            return str;
        }
        if(str.length()*2<maxByteLength){
            return str;
        }
        StringBuilder sb = new StringBuilder();
        int count = 0 ;
        char[] chs = str.toCharArray();
        for(int i=0; i<chs.length; i++){
            count += (chs[i] > 0xff) ? 2 : 1;
            if(count>maxByteLength){
                break;
            }
            sb.append(chs[i]);
        }
        return sb.toString();
    }
    
    
    /**
     * 把异常转换成字符串
     * @param ex
     * @return
     */
    public static String excepMsg(Exception ex){
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        ex.printStackTrace(pw);
        pw.flush();
        String msg = sw.toString();
        try {pw.close();} catch (Exception e) {}
        try {sw.close();} catch (Exception e) {}
        return msg;
    }
    
    /**
     * tranform list to string
     * @param list
     * @return
     */
    public static String listToString(List<String> list) {  
        StringBuilder sb = new StringBuilder();  
        if (list != null && list.size() > 0) {  
            for (int i = 0; i < list.size(); i++) {  
                if (i < list.size() - 1) {  
                    sb.append(list.get(i) + ",");  
                } else {  
                    sb.append(list.get(i));  
                }  
            }  
        }  
        return sb.toString();  
    }
    
    
    
    public static String getHTMLString(String msg){
        if(msg==null){
            return null;
        }
        String htmlMsg = msg.replaceAll("&", "&amp;");
        htmlMsg = msg.replaceAll(" ", "&nbsp;");
        htmlMsg = htmlMsg.replaceAll("<", "&lt;");
        htmlMsg = htmlMsg.replaceAll(">", "&gt;");
        htmlMsg = htmlMsg.replaceAll("\r\n", "<br/>");
        htmlMsg = htmlMsg.replaceAll("\n", "<br/>");
        return htmlMsg;
    }
    
    
    
    public static boolean equals(Object o1 , Object o2){
        if(o1==null && o2==null){
            return true;
        }
        if(o1!=null && o2!=null){
            return o1.equals(o2);
        }
        return false;
    }

}
