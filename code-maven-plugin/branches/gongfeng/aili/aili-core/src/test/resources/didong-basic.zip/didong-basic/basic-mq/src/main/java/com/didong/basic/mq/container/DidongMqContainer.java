package com.didong.basic.mq.container;

import javax.jms.Destination;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.listener.adapter.MessageListenerAdapter;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import com.didong.basic.mq.connection.DidongConnectionFactory;
import com.didong.basic.mq.convert.ByteMessage2String;
import com.didong.basic.mq.listener.DidongConsumer;
import com.didong.basic.tools.other.MessageCompressUtil;

/**
 * 
 * @ClassName:DidongMqContainer
 * @author: 韩旺坤
 * @Description:1个队列1个容器
 * @date:2015年11月13日 下午12:19:50
 */
public class DidongMqContainer implements InitializingBean {
	private DefaultMessageListenerContainer listenerContainer;

	@Override
	public void afterPropertiesSet() throws Exception {
		// 1、创建线程池
		this.threadPool = new ThreadPoolTaskExecutor();
		this.threadPool.setCorePoolSize(corePoolSize);
		this.threadPool.setMaxPoolSize(maxPoolSize);
		this.threadPool.setDaemon(daemon);
		this.threadPool.setKeepAliveSeconds(keepAliveSeconds);
		this.threadPool.afterPropertiesSet();

		// 2、创建消费者监听
		this.messageListener = new MessageListenerAdapter(consumer);
		this.messageListener.setDefaultListenerMethod("onMessage");
		if (this.isDeCompress) {
			this.messageConverter = new ByteMessage2String();
			this.messageConverter
					.setMessageCompressUtil(new MessageCompressUtil<String>());
			this.messageListener.setMessageConverter(messageConverter);
		}

		// 3、创建监听容器
		this.listenerContainer = new DefaultMessageListenerContainer();
		this.listenerContainer.setConnectionFactory(connectionFactory
				.getSpringConnectionFactory());
		this.listenerContainer.setDestination(destination);
		this.listenerContainer.setMessageListener(messageListener);
		this.listenerContainer.setTaskExecutor(threadPool);
		this.listenerContainer.setConcurrentConsumers(concurrentConsumers);
		this.listenerContainer
				.setMaxConcurrentConsumers(maxConcurrentConsumers);
		this.listenerContainer.afterPropertiesSet();
		//启动监控容器，监听才会起作用
		this.listenerContainer.start();
	}

	// 其他属性及相关set，get方法
	// 连接工厂
	private DidongConnectionFactory connectionFactory;
	// 队列
	private Destination destination;
	// 自己定义的消息监听器
	private MessageListenerAdapter messageListener;
	// 初始消费者数量
	private int concurrentConsumers;
	// 最大消费者数量
	private int maxConcurrentConsumers;
	// 消费者业务
	private DidongConsumer consumer;
	// 消息转换器
	private ByteMessage2String messageConverter;
	// 是否要对消息进行解压缩
	private boolean isDeCompress;
	/**
	 * 线程池相关，每个消费者独享
	 */
	private ThreadPoolTaskExecutor threadPool;
	// 初始线程数
	private int corePoolSize;
	// 最大线程数
	private int maxPoolSize;
	// 是否后台线程
	private boolean daemon;
	// 线程存储时间，单位：s
	private int keepAliveSeconds;

	public DefaultMessageListenerContainer getListenerContainer() {
		return listenerContainer;
	}

	public boolean isDeCompress() {
		return isDeCompress;
	}

	public void setIsDeCompress(boolean isDeCompress) {
		this.isDeCompress = isDeCompress;
	}

	public MessageConverter getMessageConverter() {
		return messageConverter;
	}

	public void setMessageConverter(ByteMessage2String messageConverter) {
		this.messageConverter = messageConverter;
	}

	public DidongConnectionFactory getConnectionFactory() {
		return connectionFactory;
	}

	public void setConnectionFactory(DidongConnectionFactory connectionFactory) {
		this.connectionFactory = connectionFactory;
	}

	public Destination getDestination() {
		return destination;
	}

	public void setDestination(Destination destination) {
		this.destination = destination;
	}

	public MessageListenerAdapter getMessageListener() {
		return messageListener;
	}

	public void setMessageListener(MessageListenerAdapter messageListener) {
		this.messageListener = messageListener;
	}

	public int getConcurrentConsumers() {
		return concurrentConsumers;
	}

	public void setConcurrentConsumers(int concurrentConsumers) {
		this.concurrentConsumers = concurrentConsumers;
	}

	public int getMaxConcurrentConsumers() {
		return maxConcurrentConsumers;
	}

	public void setMaxConcurrentConsumers(int maxConcurrentConsumers) {
		this.maxConcurrentConsumers = maxConcurrentConsumers;
	}

	public DidongConsumer getConsumer() {
		return consumer;
	}

	public void setConsumer(DidongConsumer consumer) {
		this.consumer = consumer;
	}

	public ThreadPoolTaskExecutor getThreadPool() {
		return threadPool;
	}

	public void setThreadPool(ThreadPoolTaskExecutor threadPool) {
		this.threadPool = threadPool;
	}

	public int getCorePoolSize() {
		return corePoolSize;
	}

	public void setCorePoolSize(int corePoolSize) {
		this.corePoolSize = corePoolSize;
	}

	public int getMaxPoolSize() {
		return maxPoolSize;
	}

	public void setMaxPoolSize(int maxPoolSize) {
		this.maxPoolSize = maxPoolSize;
	}

	public boolean isDaemon() {
		return daemon;
	}

	public void setDaemon(boolean daemon) {
		this.daemon = daemon;
	}

	public int getKeepAliveSeconds() {
		return keepAliveSeconds;
	}

	public void setKeepAliveSeconds(int keepAliveSeconds) {
		this.keepAliveSeconds = keepAliveSeconds;
	}

}
