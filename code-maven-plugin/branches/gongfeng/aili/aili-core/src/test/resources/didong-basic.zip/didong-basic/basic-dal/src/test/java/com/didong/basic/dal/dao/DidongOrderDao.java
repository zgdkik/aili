package com.didong.basic.dal.dao;

import java.util.List;
import java.util.Map;

import com.didong.basic.dal.order.DidongOrder;

public interface DidongOrderDao
{
    public int addOrder(long id,String code);
    
    public long getOrderCount();
    
    public long addBatchOrders(List<Map<String,?>> list);
    
    public void createDidongOrder();
    
    public long getCount();
    
    public long getMax();
    
    public long getMin();
    
    public List<DidongOrder> getOrdersById();
    
}
