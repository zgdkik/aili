package com.didong.app.sms.rule;

import java.math.BigDecimal;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.CollectionUtils;

import com.alibaba.fastjson.JSON;
import com.didong.app.sms.bean.SmsGateWay;
import com.didong.app.sms.bean.SmsPercentage;
import com.didong.app.sms.bean.Suppliers;
import com.didong.app.sms.dao.SmsDao;

public class DistRule implements InitializingBean
{
    private List<Suppliers> supList;
    private List<SmsPercentage> percentageList;
    private List<SmsGateWay> gateWayList;
    private SmsDao smsDao;
    Logger LOG = LoggerFactory.getLogger(DistRule.class);
	public void setSmsDao(SmsDao smsDao) {
		this.smsDao = smsDao;
	}
	/**
     * 
     * @Title:selectSup
     * @Description:选择
     * @return
     * Suppliers
     * @throws
     */
	public Suppliers selectSup()
	{
		if(CollectionUtils.isEmpty(supList))
		{
			throw new RuntimeException("可发短信的供应商列表为空，请检查设置");
		}
		Suppliers result_sup = null;
	    //获得当前时间
		long currentTime = System.currentTimeMillis();
		int index = (int) (currentTime%supList.size());
		result_sup = this.supList.get(index);				
		return result_sup;
	}
	@Override
	public void afterPropertiesSet() throws Exception
	{
		this.supList = this.smsDao.selectSups();
		this.gateWayList = this.smsDao.selectGateWay();
		this.percentageList = this.smsDao.selectPercentage();
		//剔除未开网关的供应商
		for(SmsGateWay gateWay:gateWayList)
		{
			if(gateWay.getIsOpen()==0)
			{
				for(Suppliers sup:supList)
				{
					if(sup.getCode().equals(gateWay.getSupCode()))
					{
						supList.remove(sup);
						LOG.info("供应商："+JSON.toJSONString(sup)+"  由于网关未开，所以剔除");
						break;
					}
				}
			}
		}
		
		//剔除比例为0的供应商
		for(SmsPercentage per:percentageList)
		{
			if(per.getPercentage().compareTo(BigDecimal.ZERO)<=0)
			{
				for(Suppliers sup:supList)
				{
					if(sup.getCode().equals(per.getSupCode()))
					{
						supList.remove(sup);
						LOG.info("供应商："+JSON.toJSONString(sup)+"  由于发送比例小于等于0，被剔除");
						break;
					}
				}
			}
		}
		
		
	}
}
