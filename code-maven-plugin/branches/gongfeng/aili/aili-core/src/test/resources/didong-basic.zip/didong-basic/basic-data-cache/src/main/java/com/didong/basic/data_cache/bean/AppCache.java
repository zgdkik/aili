package com.didong.basic.data_cache.bean;

/**
 * 
 * @ClassName:AppCache
 * @author: 韩旺坤
 * @Description:缓存配置信息
 * @date:2015年11月24日 下午4:56:36
 */
public class AppCache {
	// 主键
	private int id;
	// 应用编码
	private String appCode;
	// 缓存key
	private String type;
	// 数据来源
	private String searchURL;
	// 缓存类型：0->单个值，1->集合，2->(key,value)
	private int cacheType;
	//缓存默认查询参数
	private String defaultParam;
    //返回结果条数，
	private String createTime;

	private String createUser;

	private String modifyTime;

	private String modifyUser;

	public String getDefaultParam() {
		return defaultParam;
	}

	public void setDefaultParam(String defaultParam) {
		this.defaultParam = defaultParam;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}


	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getSearchURL() {
		return searchURL;
	}

	public void setSearchURL(String searchURL) {
		this.searchURL = searchURL;
	}

	public int getCacheType() {
		return cacheType;
	}

	public void setCacheType(int cacheType) {
		this.cacheType = cacheType;
	}

	public String getCreateTime() {
		return createTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}

	public String getCreateUser() {
		return createUser;
	}

	public void setCreateUser(String createUser) {
		this.createUser = createUser;
	}

	public String getModifyTime() {
		return modifyTime;
	}

	public void setModifyTime(String modifyTime) {
		this.modifyTime = modifyTime;
	}

	public String getModifyUser() {
		return modifyUser;
	}

	public void setModifyUser(String modifyUser) {
		this.modifyUser = modifyUser;
	}

}
