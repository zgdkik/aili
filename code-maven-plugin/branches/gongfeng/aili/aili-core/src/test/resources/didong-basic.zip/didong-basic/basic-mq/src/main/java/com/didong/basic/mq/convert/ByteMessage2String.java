package com.didong.basic.mq.convert;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.support.converter.MessageConversionException;
import org.springframework.jms.support.converter.MessageConverter;

import com.didong.basic.tools.other.MessageCompressUtil;

public class ByteMessage2String implements MessageConverter
{

	@Override
	public Object fromMessage(Message message) throws JMSException,
			MessageConversionException
	{		
		return this.messageCompressUtil.fromMessageByJson(message, String.class.getName());
	}

	@Override
	public Message toMessage(Object json, Session session) throws JMSException,
			MessageConversionException
    {
		return this.messageCompressUtil.toMessageByJson(json, session);
	}
    
	//消息压缩工具
	private MessageCompressUtil<String> messageCompressUtil;

	public MessageCompressUtil<String> getMessageCompressUtil()
	{
		return messageCompressUtil;
	}

	public void setMessageCompressUtil(
			MessageCompressUtil<String> messageCompressUtil)
	{
		this.messageCompressUtil = messageCompressUtil;
	}
	
}
