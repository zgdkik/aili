$(document).ready(function() {
	var columns = [[ {
		field : 'state',
		checkbox:true,
	}, {
		field : 'roleName',
		title : '角色名称'
	}, {
		field : 'roleCode',
		title : '角色编码'
	}, {
		field : 'compCode',
		title : '角色公司'
	}, {
		field : 'roleDesc',
		title : '角色描述'
	}
	/*, 
	{
		field : 'createUser',
		title : '创建人'
	},{
		field : 'createTime',
		title : '创建时间',
		formatter : function(date){
        	return ym.formatDate(date);
		}
	}, {
		field : 'updateUser',
		title : '更新人'
	}, {
		field : 'updateTime',
		title : '更新时间',
		formatter : function(date){
        	return ym.formatDate(date);
		}
	}*/
	,{
		field : 'id',
		title : '操作列',
		formatter : function(val,row,index){
			var toolmenu =  
	       		'<a  class="update" data-pid="'+val+'"> <i></i>修改</a>'+
	       		'<a class="delete" data-pid="'+val+'"> <i></i>复制</a>'+
	       		'<a  class="delete" data-pid="'+val+'"> <i></i>删除</a>';
			return toolmenu;
		}
	} 
	
	]];
	
	$('#dg').datagrid({columns:columns,toolbar: [{
			iconCls: 'icon-edit',
			handler: function(){
				openDialog()
			}
		},'-',{
			iconCls: 'icon-help',
			handler: function(){
				openDialog()
			}
		}]
	});
	
	$('.btn-search').on("click",function(){
		queryData();
	});
	//根据ID删除单挑数据	
	$('#dg').on("click",".delete",function(){
		var id=$(this).data("pid");
		bootbox.confirm("确定要删除吗?", function(result) {
			if(result){
				ym.sendPost(base+'/user/deleteuser/'+id,null,{
		    		successHandler:function(data,textStatus, jqXHR){
		    			if(data.success){
		    				queryData();
		    				bootbox.alert(data.msg);
		    			}
		    		}});
			}
		});
	});
    
	
	//根据ID删除单挑数据	
	$('#dg').on("click",".update",function(){
		var id=$(this).data("pid");
		ym.sendPost(base+'/role/getRoleByid/'+id,null,{
    		successHandler:function(data,textStatus, jqXHR){
    			if(data.success){
    				var  modal = $('#myModal');
    				ym.setFormObj("edit-form",data.data);
    				modal.find("select[name='compCode']").val(data.data.compCode).trigger("change");
    				modal.modal('show');
    			}
    	}});
	});
	
	function openDialog(){
		$('#dialog-edit').dialog({
		    title: '权限编辑',    
		    width: 280,
		    height: 200,
		    closed: false,
		    buttons:[{
				text:'保存',
				iconCls:'icon-save',
				handler:function(){
					alert('edit')
				}
			}],
		});    
	}

	var setting = {
		data : {
			simpleData : {
				enable : true
			}
		}
	};
	setting.check = {
		enable : true
	}
	setting.callback = {
		onCheck : onCheck
	}
	$.fn.zTree.init($("#treeDemo"), setting,tree);
    $('.addnew').on("click",function(){
    	ym.sendPost(base+'/role/getTree/',null,{
    		successHandler:function(data,textStatus, jqXHR){
    			if(data.success){
    				$('#myModal').modal('show');
    				$.fn.zTree.init($("#treeDemo"), setting,data.data.tree);
    			}
    	}});
    })
    function queryData(){
    	var opts={};
    	var params = $(".query-form").getFormObj();
    	opts.onCheck=function(index,row){
        	var roleCode = row.roleCode;
        	ym.sendPost(base+"/role/getRolePrivilege/"+roleCode,null, {
    			successHandler : function(data, textStatus, jqXHR) {
    				if (data != null) {
    					if(data.success){
    						var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    						zTree.checkAllNodes(false);
    						for (var i = 0; i < data.data.length; i++) {
    							var node = zTree.getNodeByParam("id", data.data[i],null);
    							if(node){
    								zTree.checkNode(node); 
    								zTree.expandNode(node, true, true, null, false);
    							}
    							
    						}
    					}
    				}
    			}
    		});
    	};
    	opts.toolbar=[{
    		iconCls: 'icon-edit',
    		handler: function(){
    			openDialog();
    		}
    	},'-',{
    		iconCls: 'icon-help',
    		handler: function(){
    			openDialog();
    		}
    	}];

    	ym.initPage(base + "/role/getRoleList",opts,params,'#dg',columns)
    }
    $(".save").on("click",function(){
		$('#edit-form').bootstrapValidator('validate');
		var validate = $('#edit-form').data('bootstrapValidator').isValid();
		if(!validate){
			return;
		}
		var param = $('#edit-form').getFormObj();
		ym.sendPost(base+"/role/editRole/",param, {
			successHandler : function(data, textStatus, jqXHR) {
				if (data != null) {
					if(data.success){
						$('#myModal').modal('hide');
						queryData();
					}
					layer.alert(data.msg);
				}
			}
		});
	});
    
    $(".save-pri").on("click",function(){
        var roleCode =  $("#table").bootstrapTable('getSelections')[0].roleCode;
        var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    	var nodes = zTree.getCheckedNodes(true);
    	if(nodes==null ||nodes.length==0){
    		layer.alert("请选择权限");
    		return;
    	}
    	var privilegeCodes = "";
    	for (var i = 0; i < nodes.length; i++) {
			var n = nodes[i];
			if(nodes.length==(i+1)){
				privilegeCodes  = privilegeCodes+n.id+"";
			}else{
				privilegeCodes  = privilegeCodes+n.id+",";
			}
		}
		var param = {'roleCode':roleCode,'privilegeCodes':privilegeCodes};
		ym.sendPost(base+"/role/saveRole/",param, {
			successHandler : function(data, textStatus, jqXHR) {
				if (data != null) {
					layer.alert(data.msg);
				}
			}
		});
	});
    
    $("#table").on('check.bs.table', function (e, row) {
    	var roleCode = row.roleCode;
    	ym.sendPost(base+"/role/getRolePrivilege/"+roleCode,null, {
			successHandler : function(data, textStatus, jqXHR) {
				if (data != null) {
					if(data.success){
						var zTree = $.fn.zTree.getZTreeObj("treeDemo");
						zTree.checkAllNodes(false);
						for (var i = 0; i < data.data.length; i++) {
							var node = zTree.getNodeByParam("id", data.data[i],null);
							if(node){
								zTree.checkNode(node); 
								zTree.expandNode(node, true, true, null, false);
							}
							
						}
					}
				}
			}
		});
    })
});

function onCheck(e, treeId, treeNode) {
	expandNode(treeNode);
}

function expandNode(treeNode) {
	var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
	nodes = zTree.getCheckedNodes();
	var result = new Array();
	getAllChildrenNodes(treeNode,result);
	if(result.length>0){
		for (var i = 0; i < result.length; i++) {
			zTree.expandNode(result[i], true, true, null, false);
			zTree.checkNode(result[i], treeNode.checked);
		}
	}
}

function getAllChildrenNodes(treeNode,result){
	 result.push(treeNode);
    if (treeNode.isParent) {
      var childrenNodes = treeNode.children;
      if (childrenNodes) {
          for (var i = 0; i < childrenNodes.length; i++) {
              result.push(childrenNodes[i]);
              //getAllChildrenNodes(childrenNodes[i], result);
          }
      }
  }
  return result;
}

