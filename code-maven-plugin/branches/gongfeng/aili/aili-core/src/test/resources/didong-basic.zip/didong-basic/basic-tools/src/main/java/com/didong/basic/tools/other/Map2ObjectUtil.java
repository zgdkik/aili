package com.didong.basic.tools.other;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Map2ObjectUtil
{
   public static Logger logger = LoggerFactory.getLogger(Map2ObjectUtil.class);
   
   /**
    * 
    * 把map转换成Object
    * @param map
    * @param clzz
    * @return
    * @throws Exception
    * @since 2015年8月24日
    */
   public static Object map2Object(Map<String,String> map,Class clzz) throws Exception
   {
       if(map == null)
       {
           throw new RuntimeException("调度任务的传递参数不全");
       }
       
       Object rs = clzz.newInstance();
       Field[] fs = clzz.getDeclaredFields();
       for(Field key:fs)
       {
           String value = map.get(key.getName());
           if(value == null)
           {
               String info = "NRR 属性："+key.getName()+"在Map中不存在，所以不设置值";
               logger.info(info);
               continue;
           }
           //存在属性，则设置成map中的值
           key.setAccessible(true); //先设置私有属性的访问权限
           key.set(rs, map.get(key.getName()));
       }
       
       return rs;
   }
   
   /**
    * 
    * 把Object转换成Map
    * @param obj
    * @return
    * @throws Exception
    * @since 2015年8月24日
    */
   public static Map<String,Object> object2Map(Object obj) throws Exception
   {
       Field[] fields = obj.getClass().getDeclaredFields();
       if(fields == null)
           return null;
       Map<String,Object> map = new HashMap<String,Object>();
       for(Field f:fields)
       {
           f.setAccessible(true);
           map.put(f.getName(), f.get(obj));
       }
       
       return map;
       
   }

}
