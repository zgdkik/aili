package com.didong.basic.data_cache;

import java.util.List;
import java.util.Map;

import com.didong.basic.data_cache.bean.AppCache;

/**
 * 
 * @ClassName:DidongDataCacheTemplate
 * @author: 韩旺坤
 * @Description:数据存储缓存模板接口，可针对不同的缓存进行不同的实现
 * @date:2015年10月25日 上午11:40:08
 */
public interface DidongDataCacheTemplate 
{
   /**
    * 
    * @Title:getCacheData
    * @Description:查找简单数据缓存,type->value
    * @param type
    * @param clazz
    * @return
    * T
    * @throws
    */
   public <T> T getCacheData(String type,Class<T> clazz);
   
   /**
    * 
    * @Title:getCacheData
    * @Description:查找大数据量缓存，{type-key}->value，适合如使用SQL查询的场所
    * @param type
    * @param key
    * @param clazz
    * @return
    * T
    * @throws
    */
   public <T> T getCacheData(String type,Map<String,String> key,Class<T> clazz);
   /**
    * 
    * @Title:getCacheData
    * @Description:查找简单数据缓存,type->value
    * @param type
    * @param clazz
    * @return
    * List<T>
    * @throws
    */
   public <T> List<T> getCacheDataList(String type,Class<T> clazz);
   
   /**
    * 
    * @Title:getCacheData
    * @Description:查找大数据量缓存，{type-key}->value，适合如使用SQL查询的场所
    * @param type
    * @param key
    * @param clazz
    * @return
    * List<T>
    * @throws
    */
   public <T> List<T> getCacheDataList(String type,Map<String,String> key,Class<T> clazz);   
   /**
    * 
    * @Title:setCacheData
    * @Description:KEY_VALUE
    * @param type
    * @param value
    * void
    * @throws
    */
   public <T> void setCacheData(String type,T value);

   /**
    * 
    * @Title:setCacheData
    * @Description:KEY_SET
    * @param type
    * @param value
    * void
    * @throws
    */
   public <T> void setCacheData(String type,List<T> value);
   
   /**
    * 
    * @Title:setCacheData
    * @Description:KEY_HASH
    * @param type
    * @param key
    * @param value
    * void
    * @throws
    */
   public <T> void setCacheData(String type,Map<String,String> key,T value);
   
   /**
    * 
    * @Title:deleteCacheData
    * @Description:清除指定type的缓存数据
    * @param type
    * void
    * @throws
    */
   public void deleteCacheData(String type);
   
   /**
    * 
    * @Title:deleteAllCacheData
    * @Description:清除所有缓存数据
    * void
    * @throws
    */
   public void deleteAllCacheData();
   
   /**
    * 
    * @Title:checkKey
    * @Description:检查所给type是否已经注册
    * @param type
    * void
    * @throws
    */
   public AppCache checkKey(String type);
   
   /**
    * 
    * @Title:getCacheSettings
    * @Description:获得缓存配置信息
    * @return
    * List<AppCache>
    * @throws
    */
   public List<AppCache> getCacheSettings();
   
   /**
    * 
    * @Title:setTempData
    * @Description:设置有一定生存时间的缓存
    * @param type
    * @param json
    * @param timeout 存活时长，单位秒
    * void
    * @throws
    */
   public void setTempData(String type,String json,long timeout);
   
   /**
    * 
    * @Title:getTempData
    * @Description:获取临时缓存值
    * @param type
    * @return
    * String
    * @throws
    */
   public String getTempData(String type);
   
   /**
    * 
    * @Title:startTransaction
    * @Description:开启一个redis事务
    * void
    * @throws
    */
   public void startTransaction();
   
   /**
    * 
    * @Title:execTranscation
    * @Description:执行一个redis事务
    * void
    * @throws
    */
   public void execTranscation();
}
