package com.didong.basic.tools.other;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.log4j.Logger;

/**
 * 
 * TODO 对象序列化压缩与解压缩 TODO 相对于GzipCompress来说，它的压缩与解压缩时间短得多，但是压缩率比它低
 * 
 * @author 韩旺坤
 * @version
 * @see
 * @since 2015年3月26日
 */
public class CompressObjectUtil<T> {
    private Logger logger = Logger.getLogger(CompressObjectUtil.class);

    /**
     * 
     * TODO 压缩对象数据 TODO 功能详细描述
     * 
     * @param obj ->需要实现系列化接口
     * @return
     * @since 2015年3月24日
     */
    public byte[] compressObject(Object obj) {
        if (!(obj instanceof Serializable)) {
            logger.error("对象没有实现序列化接口，无法进行序列化操作");
            return null;
        }
        logger.info("【压缩前】的对象所在内存大小：" + JavaSizeOf.sizeOfObj(obj));
        long compressStart = System.currentTimeMillis();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        GZIPOutputStream gzip = null;
        byte[] data = null;
        ObjectOutputStream ops = null;
        try {
            gzip = new GZIPOutputStream(baos);
            ops = new ObjectOutputStream(gzip);
            ops.writeObject(obj);
            // finish方法很关键，必须调用，否则
            gzip.finish();
            gzip.flush();
            data = baos.toByteArray();
            logger.info("【压缩后】的对象序列化数据所在内存大小：" + data.length);
            long compressEnd = System.currentTimeMillis();
            logger.info("对象序列化压缩用时：" + (compressEnd - compressStart));
            return data;

        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (baos != null) {
                    baos.close();
                }
                if (ops != null) {
                    ops.close();
                }
                if (gzip != null) {
                    gzip.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * 
     * TODO 解压缩数据 TODO 功能详细描述
     * 
     * @param objData
     * @return
     * @since 2015年3月24日
     */
    @SuppressWarnings("unchecked")
    public T uncompressObject(byte[] objData) {
        long uncompressStart = System.currentTimeMillis();
        logger.info("【解压缩前】的对象序列化数据大小：" + objData.length);
        ByteArrayInputStream bais = new ByteArrayInputStream(objData);
        GZIPInputStream gzip = null;
        ObjectInputStream ois = null;
        T obj = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            gzip = new GZIPInputStream(bais);
            ois = new ObjectInputStream(gzip);
            obj = (T) ois.readObject();
            long uncompressEnd = System.currentTimeMillis();
            logger.info("对象序列化解压缩用时：" + (uncompressEnd - uncompressStart));
            logger.info("【解压缩后】的对象数据大小：" + JavaSizeOf.sizeOfObj(obj));

            return obj;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
                if (gzip != null) {
                    gzip.close();
                }
                if (bais != null) {
                    bais.close();
                }
                if (baos != null) {
                    baos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }
}
