package com.didong.basic.zk.manage;

import java.nio.charset.Charset;

/**
 * 
 * @ClassName:ZkReader
 * @author: 韩旺坤
 * @Description:读取zookeeper中的数据
 * @date:2015年10月8日 下午8:11:16
 */
public class ZkReader
{
	ZookeeperManager zkMgr;
	// 字符编码
	Charset charSet = Charset.forName("utf-8");

	public String getNodeData(String path) throws Exception
	{
		byte[] buff = this.zkMgr.getNodeData(path);
		String result = new String(buff, charSet);
		return result;
	}

	public void setNodeData(String path, String data) throws Exception
	{
		byte[] buff = data.getBytes(charSet);
		this.zkMgr.setData4Node(path, buff);
	}

	public ZookeeperManager getZkMgr() {
		return zkMgr;
	}

	public void setZkMgr(ZookeeperManager zkMgr) {
		this.zkMgr = zkMgr;
	}

}
