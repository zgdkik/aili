package com.didong.basic.sms;

import java.util.Map;

import com.didong.basic.tools.other.HttpInvoker;

public class SendRunnable implements Runnable
{
	HttpInvoker httpInvoker;
	
	Map params;
	
	String url;
	
	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public HttpInvoker getHttpInvoker() {
		return httpInvoker;
	}


	public void setHttpInvoker(HttpInvoker httpInvoker)
	{
		this.httpInvoker = httpInvoker;
	}


	public Map getParams() {
		return params;
	}


	public void setParams(Map params)
	{
		this.params = params;
	}


	@Override
	public void run()
	{
		try
		{
			System.out.println(httpInvoker.doPost(url, params));
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}

}
