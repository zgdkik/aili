package com.didong.basic.mq.thread;

import org.springframework.jms.core.JmsTemplate;

public class SendMessageRunnable implements Runnable
{

	@Override
	public void run()
	{	   
    	this.jmsTemplate.convertAndSend(jsonMessage);		
	}
	
	//属性及相应的set方法
    private JmsTemplate jmsTemplate;
    //json消息内容
    private String jsonMessage;
    
	public void setJmsTemplate(JmsTemplate jmsTemplate)
	{
		this.jmsTemplate = jmsTemplate;
	}
	public void setJsonMessage(String jsonMessage) {
		this.jsonMessage = jsonMessage;
	}

}
