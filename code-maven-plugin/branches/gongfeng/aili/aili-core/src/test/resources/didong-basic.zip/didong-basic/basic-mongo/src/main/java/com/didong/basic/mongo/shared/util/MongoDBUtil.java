package com.didong.basic.mongo.shared.util;

import java.net.UnknownHostException;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;

/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：MongoDb数据库工具类
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 上午10:51:28
 * 模块路径：com.didong.basic.mongo.shared.util.MongoDBUtil
 * 更新记录：
 */
public class MongoDBUtil {
	
	private static Mongo mongo = null;
	
	private static MongoClient mongoClient = null;

	/**
	 * 功能描述：返回默认ip+端口的Mg数据库对象
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 上午11:34:44
	 * 更新记录：
	 * 返回数据：Mongo
	 */
	public static Mongo getMongoInstance() {
		try {
			// 连接本地MongoDB服务
			if(null == mongo) {
				mongo = new Mongo();
			}
			return mongo;
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 功能描述：返回指定ip+端口的Mg数据库对象
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 上午11:35:21
	 * 更新记录：
	 * 返回数据：Mongo
	 */
	public static Mongo getMongoInstanceByMgdb(String address, int port) {
		try {
			// 连接本地MongoDB服务
			if(null == mongo) {
				mongo = new Mongo(address, port);
			}
			return mongo;
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 功能描述：返回指定ip+端口的Mg数据库客户端对象
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 上午11:35:21
	 * 更新记录：
	 * 返回数据：Mongo
	 */
	public static MongoClient getMgdbClientByMgdb(String address, int port) {
		try {
			if(null == mongoClient) {
				mongoClient = new MongoClient(address, port);
			}
			return mongoClient;
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * 功能描述：返回默认ip+端口的Mg数据库客户端对象
	 * 模块作者：zouyong
	 * 开发时间：2015年10月31日 上午11:34:44
	 * 更新记录：
	 * 返回数据：Mongo
	 */
	public static MongoClient getMgClentInstance() {
		try {
			if(null == mongoClient) {
				mongoClient = new MongoClient();
			}
			return mongoClient;
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return null;
	}

}
