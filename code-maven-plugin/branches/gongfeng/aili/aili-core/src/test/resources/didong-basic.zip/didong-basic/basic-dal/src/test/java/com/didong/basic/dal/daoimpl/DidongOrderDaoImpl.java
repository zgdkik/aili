package com.didong.basic.dal.daoimpl;

import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.didong.basic.dal.BaseDao;
import com.didong.basic.dal.dao.DidongOrderDao;
import com.didong.basic.dal.order.DidongOrder;
@Service("didongOrderDao")
public class DidongOrderDaoImpl implements DidongOrderDao 
{

    @Resource(name="baseDao")
    BaseDao  baseDao;
    
	@Override
	public int addOrder(long id, String code)
	{
       Map<String,Object> order = new HashMap<String,Object>();
       order.put("id", id);
       order.put("code", code);
		return this.baseDao.insert("didong.addOrder", order);
	}

	@Override
	public long getOrderCount()
	{
        List<Long> list = this.baseDao.selectList("didong.selectOrderCount");
        long rs = 0;
        for(Long e:list)
        {
        	rs +=e;
        }
		return rs;
	}

	@Override
	public long addBatchOrders(List<Map<String, ?>> list)
	{
        int batchSize = 200;
		return this.baseDao.insertBatch("didong.addBatchOrders", list, batchSize);
	}

	@Override
	public void createDidongOrder()
	{
		//先删除，再创建
		this.baseDao.delete("didong.dropTable");
		this.baseDao.insert("didong.createDidongOrder");
		
	}

	@Override
	public long getCount()
	{
		return this.baseDao.getCount("didong.selectOrderCount2", null);
	}

	@Override
	public long getMax()
	{
		return this.baseDao.getMax("didong.selectMaxId", null);
	}

	@Override
	public long getMin()
	{
		return this.baseDao.getMin("didong.selectMinId", null);
	}

	@Override
	public List<DidongOrder> getOrdersById()
	{
		return this.baseDao.orderBy("didong.selectOrdersById", null, new Comparator<DidongOrder>(){

			@Override
			public int compare(DidongOrder o1, DidongOrder o2)
			{
				long sub = o1.getId()-o2.getId();
				int rs = 0;
				if(sub > 0)
				{
					rs = 1;
				}
				else if(sub < 0)
				{
					rs = -1;
				}
				return rs;
			}
			
		});
	}

}
