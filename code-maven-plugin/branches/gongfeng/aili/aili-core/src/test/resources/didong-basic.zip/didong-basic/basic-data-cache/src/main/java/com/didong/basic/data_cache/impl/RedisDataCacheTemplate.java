package com.didong.basic.data_cache.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.didong.basic.data_cache.CacheTypeEnum;
import com.didong.basic.data_cache.DidongDataCacheTemplate;
import com.didong.basic.data_cache.bean.AppCache;
import com.didong.basic.zk.manage.ZkReader;

/**
 * 
 * @ClassName:RedisDataCacheTemplate
 * @author: 韩旺坤
 * @Description:使用Redis作为集中式缓存配置
 * @date:2015年10月25日 下午11:59:52
 */
public class RedisDataCacheTemplate implements DidongDataCacheTemplate,InitializingBean
{
	Logger LOG = LoggerFactory.getLogger(RedisDataCacheTemplate.class);
    private StringRedisTemplate redisTemplate;
    private List<AppCache> cacheSettings = new ArrayList<AppCache>();
    private ZkReader zkReader;
    //应用编码
    private String appCode;

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public void setRedisTemplate(StringRedisTemplate redisTemplate)
	{
		this.redisTemplate = redisTemplate;
	}

	public void setZkReader(ZkReader zkReader) {
		this.zkReader = zkReader;
	}


	@Override
	public <T> T getCacheData(String type, Class<T> clazz)
	{
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_VALUE.value())
		{
			LOG.error("redis 读取缓存数据："+type+" 失败");
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值获取，此方法只适用于KEY_VALUE");
		}
		T value = null;
		String json = this.redisTemplate.opsForValue().get(type);
		if(!StringUtils.isEmpty(json))
		{
			value = JSON.parseObject(json, clazz);
		}
		return value;
	}

	@Override
	public <T> T getCacheData(String type, Map<String,String> key, Class<T> clazz)
	{
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_HASH_ONE.value())
		{
			LOG.error("redis 读取缓存数据："+type+" 失败");
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值获取，此方法只适用于KEY_HASH_ONE");
		}
		T value = null;
		if(key == null || key.isEmpty())
		{
			LOG.error("redis 读取缓存数据："+type+" 失败：参数key不可为空，请检查");
			throw new RuntimeException("参数key不可为空，请检查");
		}
		String hashKey = JSON.toJSONString(key);
		String json = (String) this.redisTemplate.opsForHash().get(type, hashKey);
		if(!StringUtils.isEmpty(json))
		{
			value = JSON.parseObject(json, clazz);
		}
		
		return value;
	}
	
	@Override
	public <T> List<T> getCacheDataList(String type, Class<T> clazz)
	{
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_SET.value())
		{
			LOG.error("redis 读取缓存数据："+type+" 失败");
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值获取，此方法只适用于KEY_SET");
		}
		long size = this.redisTemplate.opsForList().size(type);
		List<String> jsonList = this.redisTemplate.opsForList().range(type, 0, size-1);
		if(!CollectionUtils.isEmpty(jsonList))
		{
			List<T> values = new ArrayList<T>();
			for(String json:jsonList)
			{
				values.add(JSON.parseObject(json, clazz));
			}
			return values;
		}
		return null;
	}

	@Override
	public <T> List<T> getCacheDataList(String type, Map<String, String> key,
			Class<T> clazz)
	{
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_HASH_MUL.value())
		{
			LOG.error("redis 读取缓存数据："+type+" 失败");
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值获取，此方法只适用于KEY_HASH_MUL");
		}

		if(key == null || key.isEmpty())
		{
			LOG.error("redis 读取缓存数据："+type+" 失败：参数key不可为空，请检查");
			throw new RuntimeException("参数key不可为空，请检查");
		}
		String hashKey = JSON.toJSONString(key);
		String json = (String) this.redisTemplate.opsForHash().get(type, hashKey);
		if(!StringUtils.isEmpty(json))
		{
			List<T> values = JSON.parseArray(json, clazz);
			return values;
		}
		
		return null;
	}
	

	@Override
	public <T> void setCacheData(String type, T value)
	{
		LOG.debug("redis 设置缓存"+type+"信息开始");
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_VALUE.value())
		{
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值设置，此方法只适用于KEY_VALUE");
		}
		String json = JSON.toJSONString(value);
        this.redisTemplate.opsForValue().set(type, json);
		LOG.debug("redis 设置缓存"+type+"信息结束");
	}
	
	
	@Override
	public <T> void setCacheData(String type, List<T> value)
	{
		LOG.debug("redis 设置缓存"+type+"信息开始");
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_SET.value())
		{
			LOG.error("redis 设置缓存数据："+type+" 失败");
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值设置，此方法只适用于KEY_SET");
		}
		if(!CollectionUtils.isEmpty(value))
		{
			List<String> strList = new ArrayList<String>();
			for(T t:value)
			{
				strList.add(JSON.toJSONString(t));
			}
			//设置进缓存
			this.redisTemplate.opsForList().leftPushAll(type, strList);
		}
		LOG.debug("redis 设置缓存"+type+"信息结束");
		
	}

	@Override
	public <T> void setCacheData(String type, Map<String,String> key, T value)
	{
		LOG.debug("redis 设置缓存数据："+type+" 开始");
		AppCache cache = checkKey(type);
		if(cache.getCacheType() != CacheTypeEnum.KEY_HASH_ONE.value() 
				&& cache.getCacheType() != CacheTypeEnum.KEY_HASH_MUL.value())
		{
			LOG.error("redis 设置缓存数据："+type+" 失败");
			throw new UnsupportedOperationException("此类型缓存不适用此方法进行值设置，此方法只适用于KEY_HASH");
		}
		//值，JSON类型
		String valueJson = JSON.toJSONString(value);
		//hashKey
		String hashKey = JSON.toJSONString(key);
		//设置值
		this.redisTemplate.opsForHash().put(type, hashKey, valueJson);
		LOG.debug("redis 设置缓存数据："+type+" 结束");

	}

	@Override
	public void deleteCacheData(String type)
	{
		LOG.info("清空指定缓存信息："+type+"【开始】");
		this.redisTemplate.delete(type);
		LOG.info("清空指定缓存信息："+type+"【结束】");
	}

	@Override
	public void deleteAllCacheData()
	{
		LOG.debug("redis 清空所有缓存信息【开始】");
        Set<String> set = new HashSet<String>();
        for(AppCache ac:this.cacheSettings)
        {
        	set.add(ac.getType());
        }
        this.redisTemplate.delete(set);
		LOG.debug("redis 清空所有缓存信息【结束】");
	}

	@Override
	public void afterPropertiesSet() throws Exception
	{
        //zkPath
		LOG.info("加载应用缓存配置信息【开始】");
		String zkPath = "/"+appCode+"/cache";
		List<String> cacheTypes = this.zkReader.getZkMgr().getChildrenNode(zkPath);
		if(!CollectionUtils.isEmpty(cacheTypes))
		{
			this.cacheSettings.clear();
			for(String cacheType:cacheTypes)
			{
				String cachePath = zkPath+"/"+cacheType;
				String cacheJson = this.zkReader.getNodeData(cachePath);
				if(!StringUtils.isEmpty(cacheJson))
				{
					String json = (String) JSON.parse(cacheJson);
					LOG.info("加载到的缓存配置信息："+json);
					AppCache tmp = JSON.parseObject(json, AppCache.class);
					//加入到本地缓存配置队列中               
                    this.cacheSettings.add(tmp);
				}
			}			
		}

		LOG.info("加载应用缓存配置信息【结束】");
	}

	@Override
	public AppCache checkKey(String type)
	{
       boolean isExist = false;
       for(AppCache ac:this.cacheSettings)
       {
    	   if(ac.getType().equals(type))
    	   {
    		   isExist = true;
    		   return ac;
    	   }
       }
	   if(!isExist)
	   {
		   throw new RuntimeException("Key->"+type+" 未进行注册，请先注册！");
	   }
	   return null;
	}
	
	
    @Override
	public List<AppCache> getCacheSettings()
	{
		return cacheSettings;
	}

	@Override
	public void setTempData(String type, String json, long timeout)
	{
		 if(!isExistCacheSettings(type))
		 {
	         this.redisTemplate.opsForValue().set(type, json, timeout, TimeUnit.SECONDS);
		 }
		 else
		 {
			 String err = "type:"+type+" 的缓存已经存在于配置列表中，不能再设置为临时缓存";
			 LOG.debug(err);
			 throw new RuntimeException(err);
		 }
	
	}

	@Override
	public String getTempData(String type)
	{
		if(!isExistCacheSettings(type))
		{
			return this.redisTemplate.opsForValue().get(type);
		}
		else
		{
			 String err = "type:"+type+" 不存在这样的临时缓存，请查看！";
			 LOG.debug(err);
			 throw new RuntimeException(err);
		}
	}
	
	/**
	 * 
	 * @Title:isExistCacheSettings
	 * @Description: 判断所给缓存TYPE，是否在所配置的缓存列表中，如果存在则返回true
	 * @param type
	 * @return
	 * boolean
	 * @throws
	 */
	private boolean isExistCacheSettings(String type)
	{
		boolean rs = false;
		if(!CollectionUtils.isEmpty(cacheSettings))
		{
			for(AppCache cache:this.cacheSettings)
			{
				if(cache.getType().equals(type))
				{
					rs = true;
					break;
				}
			}
		}
		
		return rs;
	}

	@Override
	public void startTransaction()
	{
		this.redisTemplate.multi();		
	}

	@Override
	public void execTranscation()
    {
		this.redisTemplate.exec();		
	}

}
