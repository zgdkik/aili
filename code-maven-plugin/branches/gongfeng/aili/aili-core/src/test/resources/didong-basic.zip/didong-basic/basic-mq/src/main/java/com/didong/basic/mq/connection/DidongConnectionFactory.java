package com.didong.basic.mq.connection;

import javax.jms.ConnectionFactory;

import org.apache.activemq.ActiveMQConnectionFactory;
import org.apache.activemq.RedeliveryPolicy;
import org.apache.activemq.pool.PooledConnectionFactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.connection.CachingConnectionFactory;

public class DidongConnectionFactory implements InitializingBean
{
	CachingConnectionFactory springConnectionFactory;
	@Override
	public void afterPropertiesSet() throws Exception
	{
		//1、设置重试策略
		RedeliveryPolicy activeMQRedeliveryPolicy = new RedeliveryPolicy();
		activeMQRedeliveryPolicy.setMaximumRedeliveries(maximumRedeliveries);
		activeMQRedeliveryPolicy.setMaximumRedeliveryDelay(maximumRedeliveryDelay);
		
		//2、连接工厂
		ActiveMQConnectionFactory amqConnectionFactory = new ActiveMQConnectionFactory();
		amqConnectionFactory.setBrokerURL(brokerURL);
		amqConnectionFactory.setRedeliveryPolicy(activeMQRedeliveryPolicy);
		
		
		//3、采用连接池
		PooledConnectionFactoryBean poolConnectionFactory = new PooledConnectionFactoryBean();
		poolConnectionFactory.setConnectionFactory(amqConnectionFactory);
		poolConnectionFactory.setMaxConnections(maxConnections);
		poolConnectionFactory.afterPropertiesSet();
		
		//4、增加连接缓存功能，它拥有SingleConnectionFactory的所有功能，
		//同时它还新增了缓存功能，它可以缓存Session、MessageProducer和MessageConsumer
		springConnectionFactory = new CachingConnectionFactory();
		springConnectionFactory.setTargetConnectionFactory((ConnectionFactory) poolConnectionFactory.getObject());
	}
	
	//其他要配置的属性及相应的set，get方法
	/**
	 * 重试策略
	 */
	// 最大重试次数
	private int maximumRedeliveries;

	// 最大重试延迟时间，单位：ms
	private int maximumRedeliveryDelay;

	// MQ地址，如：failover:(tcp://10.100.25.110:61616,tcp://10.100.25.111:61616)?initialReconnectDelay=1000&amp;jms.prefetchPolicy.queuePrefetch=10
	private String brokerURL;
	// 连接池最大连接数
	private int maxConnections;
	public int getMaximumRedeliveries() {
		return maximumRedeliveries;
	}
	public void setMaximumRedeliveries(int maximumRedeliveries) {
		this.maximumRedeliveries = maximumRedeliveries;
	}
	public int getMaximumRedeliveryDelay() {
		return maximumRedeliveryDelay;
	}
	public void setMaximumRedeliveryDelay(int maximumRedeliveryDelay) {
		this.maximumRedeliveryDelay = maximumRedeliveryDelay;
	}
	public String getBrokerURL() {
		return brokerURL;
	}
	public void setBrokerURL(String brokerURL) {
		this.brokerURL = brokerURL;
	}
	public int getMaxConnections() {
		return maxConnections;
	}
	public void setMaxConnections(int maxConnections) {
		this.maxConnections = maxConnections;
	}
	public CachingConnectionFactory getSpringConnectionFactory() {
		return springConnectionFactory;
	}

}
