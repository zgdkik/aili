package com.didong.basic.dal.daoimpl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import com.didong.basic.dal.BaseDao;
import com.didong.basic.dal.dao.ServiceBaseDao;

public class ServiceBaseDaoImpl implements ServiceBaseDao
{
    @Resource
    BaseDao  baseDao;
	@Override
	public boolean isExistSequence(String seqName)
	{
        int count = this.baseDao.selectOne("service.selectSequenceByName", seqName);
		return count > 0;
	}

	@Override
	public long getNextValue(String seqName, int count)
	{
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("seqName", seqName);
		map.put("idCount", count);		
		return this.baseDao.selectOne("service.selectNextIdBySeqName", map);
	}

	@Override
	public boolean addNewSequence(String seqName, int step)
	{
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("seqName", seqName);
		map.put("step", step);
        int rs = this.baseDao.insert("service.addNewSequence", map);
		return false;
	}

}
