package com.didong.basic.zk.processor;

import com.didong.basic.zk.manage.ZookeeperManager;



/**
 * 
 * Processor interface that does operation flow once connected
 * @author    韩旺坤
 * @version   
 * @see       
 * @since
 */
public interface Processor
{
    void execute(ZookeeperManager zkMgr) throws Exception;
}
