package com.didong.basic.tools.other;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;

import javax.jms.BytesMessage;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.Session;

import org.springframework.jms.support.converter.MessageConversionException;

import com.alibaba.fastjson.JSON;

/**
 * TODO 在进行Message传输与消费时进行压缩与解压缩 
 * TODO 有两种方法：1、把先对象转换成JSON；2、先把对象序列化
 * 
 * @author 韩旺坤
 * @version
 * @see
 * @since 2015年3月26日
 */
public class MessageCompressUtil<T> 
{
    private CompressObjectUtil<T> util = new CompressObjectUtil<T>();
    /**
     * 
     * TODO 先把对象转换成JSON，再进行压缩，最后进行传输
     * TODO 功能详细描述
     * @param object
     * @param session
     * @return
     * @throws JMSException
     * @throws MessageConversionException
     * @since 2015年3月26日
     */
    public Message toMessageByJson(Object object, Session session)
            throws JMSException, MessageConversionException 
     {
        T log = (T) object;
        //发送前对数据进行gzip压缩
        String logStr = null;
        logStr = JSON.toJSONString(log);
        byte[] src = null;
        try 
        {
            src = logStr.getBytes("UTF-8");
        } catch (UnsupportedEncodingException e) 
        {
            e.printStackTrace();
        }
        //压缩
        byte[] buff = GzipCompress.compressBytes(src);
        BytesMessage bm = session.createBytesMessage();
        bm.writeBytes(buff);
        
        return bm;

    }

    /**
     * 
     * TODO 把通过JSON压缩后的字符串解压缩为JSON，然后再转换为指定对象，最后进行消费
     * TODO 功能详细描述
     * @param message
     * @param className ->具体要转换的类的全路径名称
     * @return
     * @throws JMSException
     * @throws MessageConversionException
     * @since 2015年3月26日
     */
    public Object fromMessageByJson(Message message,String className) throws JMSException,
            MessageConversionException {
        Object log = null;
		try {
			BytesMessage msg = (BytesMessage) message;
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			byte[] buff = new byte[8*1024];
			int n = -1;
			while((n = msg.readBytes(buff))!=-1)
			{
			    baos.write(buff, 0, n);
			}
			
			byte[] src = baos.toByteArray();
			try 
			{
			    baos.close();
			} catch (IOException e) {
			    e.printStackTrace();
			}
			//gzip解压缩
			byte[] after = GzipCompress.uncompressBytes(src);
			String logs = null;
			try 
			{
			    logs = new String(after,"UTF-8");
			} catch (UnsupportedEncodingException e) 
			{
			    e.printStackTrace();
			}
			
			log = null;
			try 
			{
			    log = JSON.parseObject(logs, Class.forName(className));
			} catch (ClassNotFoundException e) 
			{
			    e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
        
        return log;
    }
    
    /**
     * 
     * TODO 先把对象进行序列化，然后把序列化数据进行压缩，最后进行传输
     * TODO 功能详细描述
     * @param object
     * @param session
     * @return
     * @throws JMSException
     * @throws MessageConversionException
     * @since 2015年3月26日
     */
    public Message toMessage(Object object, Session session)
            throws JMSException, MessageConversionException 
    {

            if (object instanceof Serializable) 
            {
                // 压缩
                byte[] buff = util.compressObject(object);
                BytesMessage bm = session.createBytesMessage();
                bm.writeBytes(buff);

                return bm;
            }
            return null;

    }

    /**
     * 
     * TODO 把之前通过序列化压缩后的数据解压缩，然后再反序列化为指定对象，最后进行消费
     * TODO 功能详细描述
     * @param message
     * @return
     * @throws JMSException
     * @throws MessageConversionException
     * @since 2015年3月26日
     */
    public T fromMessage(Message message) throws JMSException,
            MessageConversionException {
        BytesMessage msg = (BytesMessage) message;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buff = new byte[8*1024];
        int n = -1;
        while((n = msg.readBytes(buff))!=-1)
        {
            baos.write(buff, 0, n);
        }
        
        byte[] src = baos.toByteArray();
        try 
        {
            baos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        T log = util.uncompressObject(src);

        return log;

    }    

}
