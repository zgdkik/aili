package com.didong.basic.tools.other;

public class ObjectUtil {
    
   
    /**
     * 两个对象是否相等
     * @param o1
     * @param o2
     * @return
     */
    public static boolean equals(Object o1 , Object o2){
        if(o1==null && o2==null){
            return true;
        }
        if(o1!=null && o2!=null){
            return o1.equals(o2);
        }
        return false;
    }

}
