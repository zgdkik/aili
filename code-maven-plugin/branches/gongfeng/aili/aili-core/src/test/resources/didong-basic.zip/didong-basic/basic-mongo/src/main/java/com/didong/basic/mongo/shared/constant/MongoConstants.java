package com.didong.basic.mongo.shared.constant;

/**
 * 系统名称：车辆运输跟踪系统（TTS）
 * 模块名称：
 * 模块描述：Mongodb-常量类
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年11月18日 下午10:28:04
 * 模块路径：com.didong.basic.mongo.shared.constant.MongoConstants
 * 更新记录：
 */
public class MongoConstants {
	
	// Mgdb数据库IP地址（后续改成配置文件形式）
	public static String mgdbAdrs = "123.56.160.12"; // "127.0.0.1";
	
	// Mgdb数据库端口（后续改成配置文件形式）
	public static int mgdbPort = 27017;
	
	// 图片存储表名称
	public static String mgGdfsTabName = "DDImg";
	
	// Mongodb短信库表明
	public static String mgdbTableName = "didongSmsBase";
	
	// Mongodb短信库表
	public static String smsTextTabName = "sms_text_tab";

}
