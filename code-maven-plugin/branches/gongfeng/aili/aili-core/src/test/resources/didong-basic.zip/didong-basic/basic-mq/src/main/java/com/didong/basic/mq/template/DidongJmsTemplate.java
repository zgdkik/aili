package com.didong.basic.mq.template;

import org.springframework.jms.core.JmsTemplate;


/**
 * 
 * @ClassName:DidongJmsTemplate
 * @author: 韩旺坤
 * @Description:发送消息到MQ的具体接口，包含同步发送、异步发送，每个队列一个template实例
 * @date:2015年11月12日 下午4:31:47
 */
public interface DidongJmsTemplate
{
   /**
    * 
    * @Title:asynSend
    * @Description:异步发送消息，采用线程池
    * @param jsonMessage json格式的消息
    * void
    * @throws
    */
   public void asynSend(String jsonMessage);
   
   
   /**
    * 
    * @Title:syncSend
    * @Description:同步发送消息
    * @param jsonMessage json格式的消息
    * @return
    * boolean
    * @throws
    */
   public boolean syncSend(String jsonMessage);
   
   /**
    * 
    * @Title:getJmsTemplate
    * @Description:获得Jms发送模板
    * @return
    * JmsTemplate
    * @throws
    */
   public JmsTemplate getJmsTemplate();
}
