package com.didong.basic.tools.other;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * 
 * 组对象
 * @author wangyudong
 * @version   
 * @see       
 * @since
 */
public class GroupValue {
    
    
    public static final int TYPE_BY    = 1;//group by
    public static final int TYPE_MAX   = 2;//分组函数，取最大值
    public static final int TYPE_MIN   = 3;//分组函数，取最小值
    public static final int TYPE_SUM   = 4;//分组函数，求和
    public static final int TYPE_AVG   = 5;//取平均值
    public static final int TYPE_COUNT = 6;//统计个数

    
    /**
     * 两个数字 求和 
     * @param v1
     * @param v2
     * @return v1 + v2
     */
    public static Object SUM(Object v1 , Object v2){
        if(v1==null){
            return v2;
        }
        if(v2==null){
            return v1;
        }
        Class v1_c = v1.getClass();
        Class v2_c = v2.getClass();
        
        if(v1_c!=v2_c){
            throw new RuntimeException("v1.type must same as v2.typp: v1.type=["+v1_c.getName()+"],v2.typp=["+v2_c.getName()+"]");
        }
        
        if(v1_c == short.class || v1_c == Short.class){
            short result = (short)((short)v1 + (short)v2);
            return (Short)result;
        }
        if(v1_c == int.class || v1_c == Integer.class){
            int result = (int)v1 + (int)v2;
            return (Integer)result;
        }
        if(v1_c == long.class || v1_c == Long.class){
            long result = (long)v1 + (long)v2;
            return (Long)result;
        }
        if(v1_c == float.class || v1_c == Float.class){
            float result = (float)v1 + (float)v2;
            return (Float)result;
        }
        if(v1_c == double.class || v1_c == Double.class){
            double result = (double)v1 + (double)v2;
            return (Double) result;
        }
        if(v1_c == BigDecimal.class){
            BigDecimal v1_n = (BigDecimal)v1;
            BigDecimal v2_n = (BigDecimal)v2;
            return v1_n.add(v2_n);
        }
        if(v1_c == BigInteger.class){
            BigInteger v1_n = (BigInteger)v1;
            BigInteger v2_n = (BigInteger)v2;
            return v1_n.add(v2_n);
        }
        throw new RuntimeException("SUM() 不支持这种类型的对象求和 ： " + v1_c.getName());
    }
    
    
    /**
     * 两个值取最大值
     * @param v1
     * @param v2
     * @return
     */
    public static Object MAX(Object v1 , Object v2){
        if(v1==null){
            return v2;
        }
        if(v2==null){
            return v1;
        }
        Class v1_c = v1.getClass();
        Class v2_c = v2.getClass();
        
        if(v1_c!=v2_c){
            throw new RuntimeException("v1.type must same as v2.typp: v1.type=["+v1_c.getName()+"],v2.typp=["+v2_c.getName()+"]");
        }
        
        if(!(v1 instanceof Comparable)){
            throw new RuntimeException("MAX() 只支持 实现  Comparable 接口的对象 的计算。type="+v1_c.getName());
        }
        Comparable c1 = (Comparable)v1;
        Comparable c2 = (Comparable)v2;
        
        if(c1.compareTo(c2)>=0){
            return c1;
        }else{
            return c2;
        }
    }
    
    
    
    public static Object AVG(Object sum , int count){
        if(sum==null || count<1){
            return null;
        }
        Class sumClass = sum.getClass();
        if(sumClass == short.class || sumClass == Short.class){
            short result = (short)((short)sum/count);
            return (Short)result;
        }
        if(sumClass == int.class || sumClass == Integer.class){
            int result = (int)sum/count;
            return (Integer)result;
        }
        if(sumClass == long.class || sumClass == Long.class){
            long result = (long)sum/count;
            return (Long)result;
        }
        if(sumClass == float.class || sumClass == Float.class){
            float result = (float)sum/count;
            return (Float)result;
        }
        if(sumClass == double.class || sumClass == Double.class){
            double result = (double)sum/count;
            return (Double) result;
        }
        if(sumClass == BigDecimal.class){
            BigDecimal result = ((BigDecimal)sum).divide(new BigDecimal(count));
            return result;
        }
        if(sumClass == BigInteger.class){
            BigInteger result = ((BigInteger)sum).divide(new BigInteger(count+""));
            return result;
        }
        throw new RuntimeException("AVG() 不支持这种类型的对象求和 ： " + sumClass.getName());
    }
    
    
    /**
     * 两个值取最大值
     * @param v1
     * @param v2
     * @return
     */
    public static Object MIN(Object v1 , Object v2){
        if(v1==null){
            return v2;
        }
        if(v2==null){
            return v1;
        }
        Class v1_c = v1.getClass();
        Class v2_c = v2.getClass();
        
        if(v1_c!=v2_c){
            throw new RuntimeException("v1.type must same as v2.typp: v1.type=["+v1_c.getName()+"],v2.typp=["+v2_c.getName()+"]");
        }
        
        if(!(v1 instanceof Comparable)){
            throw new RuntimeException("MAX() 只支持 实现  Comparable 接口的对象 的计算。type="+v1_c.getName());
        }
        Comparable c1 = (Comparable)v1;
        Comparable c2 = (Comparable)v2;
        
        if(c1.compareTo(c2)<=0){
            return c1;
        }else{
            return c2;
        }
    }
    
    /**
     * 构造方法
     * @param bean
     * @param columnNames
     */
    public GroupValue(Object bean , String[] columnNames){
        
        size = columnNames.length;
        fieldTypes = new int[size];
        fieldNames = new String[size];
        fieldValues = new Object[size];
        fieldValueCounts = new int[size];
        
        for(int i=0 ; i<size ;i++){
            String columnName = columnNames[i].trim();
            int index_KS = columnName.indexOf("(");
            int index_KE = columnName.indexOf(")");
            
            if(index_KS>0 && index_KE>0){
                if(columnName.startsWith("sum(")||columnName.startsWith("SUM(")){
                    fieldTypes[i]=TYPE_SUM;
                }else if(columnName.startsWith("max(")||columnName.startsWith("MAX(")){
                    fieldTypes[i]=TYPE_MAX;
                }else if(columnName.startsWith("min(")||columnName.startsWith("MIN(")){
                    fieldTypes[i]=TYPE_MIN;
                }else if(columnName.startsWith("avg(")||columnName.startsWith("AVG(")){
                    fieldTypes[i]=TYPE_AVG;
                }else if(columnName.startsWith("count(")||columnName.startsWith("COUNT(")){
                    fieldTypes[i]=TYPE_COUNT;
                }else{
                    throw new RuntimeException("错误的函数表达式:"+columnName);
                }
                
                String fname = columnName.substring(index_KS+1, index_KE).trim();
                fieldValues[i]=ReflectUtil.getFieldValue(bean, fname);
                if(fieldValues[i]!=null){
                    fieldValueCounts[i]=1;
                }else{
                    fieldValueCounts[i]=0;
                }
                fieldNames[i]=fname;
                if(columnName.length()>(index_KE+1)){
                    String bname = columnName.substring(index_KE+1).trim();
                    if(bname.length()>0){
                        fieldNames[i]=bname;
                    }
                }
                continue;
            }
            
            if(index_KS>=0 || index_KE>=0){
                throw new RuntimeException("错误的函数表达式:"+columnName);
            }
            
            fieldTypes[i]=TYPE_BY;
            String fname = null;
            String bname = null;
            int spindex  = -1;
            if((spindex=columnName.indexOf(" "))>0){
                fname = columnName.substring(0, spindex).trim();
                bname = columnName.substring(spindex).trim();
            }else{
                fname = columnName;
                bname = null;
            }
            fieldValues[i]=ReflectUtil.getFieldValue(bean, fname);
            if(fieldValues[i]!=null){
                fieldValueCounts[i]=1;
            }else{
                fieldValueCounts[i]=0;
            }
            if(bname!=null && bname.length()>0){
                fieldNames[i]=bname;
            }else{
                fieldNames[i]=fname;
            }
        }
        for(int i=0 ; i<size ; i++){
            for(int j=i+1 ;j<size ; j++){
                if(fieldNames[i].equals(fieldNames[j])){
                    throw new RuntimeException("不能有同名字段,重复字段："+fieldNames[i]);
                }
            }
        }
    }
    
    private int size = -1;
    
    private int[] fieldTypes = null;
            
    private String[] fieldNames = null;
    
    private Object[] fieldValues = null;
    
    private int[] fieldValueCounts = null;

    
    
    public int hashCode() {
        int hashCode = 0 ;
        for(int i=0 ; i<size ;i++){
            if(fieldTypes[i]==TYPE_BY && fieldValues[i]!=null){
                hashCode += fieldValues[i].hashCode();
            }
        }
        return hashCode;
    }

    
    public boolean equals(Object obj) {
        if(obj!=null && obj instanceof GroupValue){
            GroupValue gv = (GroupValue)obj;
            
            if(this.fieldValues==null && gv.getFieldValues()==null){
                return true;
            }
            if(this.fieldValues!=null && gv.getFieldValues()!=null){
                if(this.getSize()==0 && gv.getSize()==0){
                    return true;
                }
            }
            
            if(this.getSize()>0 && this.getSize()==gv.getSize()){
                for(int i=0;i<size;i++){
                    
                    if(TYPE_BY==this.fieldTypes[i]){ //参加对比的只有 TYPE_BY 类型的字段
                        Object o1 = this.fieldValues[i];
                        Object o2 = gv.getFieldValues()[i];
                        if(o1==null && o2!=null){
                            return false;
                        }
                        if(o1!=null && o2==null){
                            return false;
                        }
                        if(o1!=null && o2!=null){
                            if(!o1.equals(o2)){
                                return false;
                            }
                        }
                    }
                }
                return true;
            } 
        }
        return false;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("{");
        if(size>0){
            for(int i=0 ; i<size ; i++){
                String fieldName = fieldNames[i];
                Object fieldValue = fieldValues[i];
                if(i>0){
                    sb.append(",");
                }
                sb.append("\r\n["+fieldName+":"+fieldValue+"]");
            }
        }
        sb.append("}");
        return sb.toString();
    }


    /**
     * 把
     * TODO 一句话功能简述
     * TODO 功能详细描述
     * @param beanClass
     * @return
     */
    public <T> T toBean(Class<T> beanClass){
        try {
            T bean = beanClass.newInstance();
            for(int i=0 ; i<size ;i++){
                ReflectUtil.setProperty( bean , fieldNames[i], fieldValues[i]);
            }
            return bean;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } 
        
    }
    
    //getter and setter //
    public int getSize() {
        return size;
    }

    public int[] getFieldTypes() {
        return fieldTypes;
    }

    public String[] getFieldNames() {
        return fieldNames;
    }

    public Object[] getFieldValues() {
        return fieldValues;
    }

    public int[] getFieldValueCounts() {
        return fieldValueCounts;
    }

    public void setFieldValueCounts(int[] fieldValueCounts) {
        this.fieldValueCounts = fieldValueCounts;
    }
    
    
}
