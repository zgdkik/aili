package com.didong.basic.tools.other;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * 日期帮助工具
 * @author wangyudong
 * @version   
 * @see       
 * @since
 */
public class DateUtil {
    
    /**
     * 日期对象转换成指定格式的字符串
     * @param date
     * @param format 指定的日期格式
     * @return
     */
    public static String date2String(Date date , String format){
        if(date==null){
            return null;
        }
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(date);
    }
    
    
    /**
     * 把一定格式的日期字符串 转换成为日期对象
     * @param dateString
     * @param format
     * @return
     */
    public static Date string2Date(String dateString , String format){
        
        if(dateString==null){
            return null;
        }
        
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        try {
            return sdf.parse(dateString);
        } catch (ParseException e) {
           throw new RuntimeException(e);
        }
    }
    
    
    /**
     * 获得比当前时间早 【seconds】 秒 的时间对象
     * @param seconds
     * @return
     */
    public static Date getDateBefore(int seconds , Date date){
        Date before = new Date(date.getTime()-(seconds*1000));
        return before;
    }
    
    
    /**
    * 获得比当前时间晚【seconds】 秒 的时间对象
    * @param seconds
    * @return
    */
   public static Date getDateAfter(int seconds , Date date){
       Date after = new Date(date.getTime()+(seconds*1000));
       return after;
   }

}
