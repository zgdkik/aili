package com.didong.app.sms.bean;

/**
 * 
 * @ClassName:Suppliers
 * @author: 韩旺坤
 * @Description:短信供应商
 * @date:2015年11月14日 下午5:58:37
 */
public class Suppliers {
	// 主键
	private long id;
	// 编码
	private String code;
	// 名字
	private String name;
	// 描述
	private String desc;
	// 短信接口
	private String smsUrl;
	// 其他固定参数，json格式
	private String otherParams;
	// 短信内容字段名
	private String contentField;
	// 手机号字段名
	private String phoneField;

	
	public String getContentField() {
		return contentField;
	}

	public void setContentField(String contentField) {
		this.contentField = contentField;
	}

	public String getPhoneField() {
		return phoneField;
	}

	public void setPhoneField(String phoneField) {
		this.phoneField = phoneField;
	}

	public String getOtherParams() {
		return otherParams;
	}

	public void setOtherParams(String otherParams) {
		this.otherParams = otherParams;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getSmsUrl() {
		return smsUrl;
	}

	public void setSmsUrl(String smsUrl) {
		this.smsUrl = smsUrl;
	}

}
