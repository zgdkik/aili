package com.didong.basic.dal.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.core.io.Resource;

import com.alibaba.druid.pool.DruidDataSource;
import com.atomikos.jdbc.AtomikosDataSourceBean;
import com.didong.basic.dal.enums.DataSourceType;
import com.didong.basic.dal.template.DidongClientTemplate;

public class DataSourceInitionUtil
{
    public static List<DidongClientTemplate> create(List<Properties> props,Resource configPath) throws Exception
    {
    	List<DidongClientTemplate> templateList = new ArrayList<DidongClientTemplate>();
    	for(Properties prop:props)
    	{
    		DataSource ds = getDs(prop);
    		SqlSessionFactoryBean factory = new SqlSessionFactoryBean();
    		factory.setConfigLocation(configPath);
    		factory.setDataSource(ds);
    		factory.afterPropertiesSet();
    		
    		SqlSessionTemplate sqlTemplate = new SqlSessionTemplate(factory.getObject());

    		DidongClientTemplate dt = new DidongClientTemplate();
    		dt.setNamespace(prop.getProperty("namespace"));
    		dt.setSqlTemplate(sqlTemplate);
    		
    		templateList.add(dt);
    	}
    	return templateList;
    }
    
    /**
     * 
     * @Title:createXaDataSource
     * @Description:创建XA数据源
     * @param prop
     * @return
     * AtomikosDataSourceBean
     * @throws
     */
    public static AtomikosDataSourceBean createXaDataSource(Properties prop)
    {
    	AtomikosDataSourceBean ds = new AtomikosDataSourceBean();
    	ds.setUniqueResourceName(prop.getProperty("uniqueResourceName"));
    	ds.setXaDataSourceClassName(prop.getProperty("xaDataSourceClassName"));
    	ds.setXaProperties(prop);
    	ds.setPoolSize(Integer.parseInt(prop.getProperty("poolSize")));
    	ds.setMaxPoolSize(Integer.parseInt(prop.getProperty("maxPoolSize")));
    	ds.setMinPoolSize(Integer.parseInt(prop.getProperty("minPoolSize")));
    	ds.setBorrowConnectionTimeout(Integer.parseInt(prop.getProperty("borrowConnectionTimeout")));
    	ds.setMaintenanceInterval(Integer.parseInt(prop.getProperty("maintenanceInterval")));
    	ds.setMaxIdleTime(Integer.parseInt(prop.getProperty("maxIdleTime")));
    	ds.setReapTimeout(Integer.parseInt(prop.getProperty("reapTimeout")));
    	ds.setTestQuery(prop.getProperty("testQuery"));
    	
    	return ds;
    }
    
    /**
     * @throws Exception 
     * 
     * @Title:createDruidDataSource
     * @Description:创建普通类型数据源
     * @param prop
     * @return
     * DruidDataSource
     * @throws
     */
    public static DruidDataSource createDruidDataSource(Properties prop) throws Exception
    {
    	DruidDataSource ds = new DruidDataSource();
    	ds.setDefaultReadOnly(Boolean.valueOf(prop.getProperty("defaultReadOnly")));
    	ds.setDriverClassName(prop.getProperty("driverClassName"));
    	ds.setUrl(prop.getProperty("url"));
    	ds.setUsername(prop.getProperty("username"));
    	ds.setPassword(prop.getProperty("password"));
    	ds.setInitialSize(Integer.parseInt(prop.getProperty("initialSize")));
    	ds.setMaxActive(Integer.parseInt(prop.getProperty("maxActive")));
    	ds.setMinIdle(Integer.parseInt(prop.getProperty("minIdle")));
    	ds.setMaxWait(Long.parseLong(prop.getProperty("maxWait")));
    	ds.setValidationQuery(prop.getProperty("validationQuery"));
    	ds.setValidationQueryTimeout(Integer.parseInt(prop.getProperty("validationQueryTimeout")));
    	ds.setTimeBetweenEvictionRunsMillis(Long.parseLong(prop.getProperty("timeBetweenEvictionRunsMillis")));
    	ds.setMinEvictableIdleTimeMillis(Long.parseLong(prop.getProperty("minEvictableIdleTimeMillis")));
    	ds.setTestWhileIdle(Boolean.parseBoolean(prop.getProperty("testWhileIdle")));
    	ds.setTestOnBorrow(Boolean.parseBoolean(prop.getProperty("testOnBorrow")));
    	ds.setTestOnReturn(Boolean.parseBoolean(prop.getProperty("testOnReturn")));
    	ds.setNumTestsPerEvictionRun(Integer.parseInt(prop.getProperty("numTestsPerEvictionRun")));
    	ds.setConnectionProperties(prop.getProperty("connectionProperties"));
    	ds.setFilters(prop.getProperty("filters"));
    	ds.setPoolPreparedStatements(Boolean.parseBoolean(prop.getProperty("poolPreparedStatements")));
    	ds.setMaxPoolPreparedStatementPerConnectionSize(Integer.parseInt(prop.getProperty("maxPoolPreparedStatementPerConnectionSize")));

    	return ds;
    }
    
    
    public static DataSource getDs(Properties prop) throws Exception
    {
    	DataSource ds = null;
    	if(prop.get("dsType").equals(DataSourceType.COMMON_DS.toString()))
    	{
    		ds = createDruidDataSource(prop);
    	}
    	else if(prop.get("dsType").equals(DataSourceType.XA_DS.toString()))
    	{
    		ds = createXaDataSource(prop);
    	}
    	
    	return ds;
    }
     
}
