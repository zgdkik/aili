package com.didong.basic.dal;

import java.util.List;

import javax.annotation.Resource;

import org.apache.zookeeper.CreateMode;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.didong.basic.dal.dao.DidongOrderDao;
import com.didong.basic.dal.daoimpl.ServiceBaseDaoImpl;
import com.didong.basic.dal.order.DidongOrder;
import com.didong.basic.zk.manage.ZkReader;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class CobarTest extends AbstractJUnit4SpringContextTests 
{
    @Resource
    DidongOrderDao didongOrderDao;
    @Resource
    ZkReader zkReader;
    @Resource
    ServiceBaseDaoImpl serviceBaseDao;
	@Test
	public void test() throws Exception 
	{
		 //1、先创建测试表
		 this.didongOrderDao.createDidongOrder();
		 //2、再插入数据，先取ID
		 if(!this.serviceBaseDao.isExistSequence("mytest"))
		 {
			 this.serviceBaseDao.addNewSequence("mytest", 1);
    	 }
		 long id = this.serviceBaseDao.getNextValue("mytest", 1024);
		 for(int i=0;i<1024;i++)
		 {
			 this.didongOrderDao.addOrder(id+i, id+i+"");
		 }
		 long total = this.didongOrderDao.getOrderCount();
		 System.out.println("总共插入："+total+" 条数据");
		 //测试zookeeper
		 String zkPath = "/zookeeper/hwk";
     	this.zkReader.getZkMgr().delNode(zkPath);
		this.zkReader.getZkMgr().createNode(zkPath, CreateMode.PERSISTENT);
	    this.zkReader.setNodeData(zkPath, "didong-zookeeper");
		 String zkStr = this.zkReader.getNodeData("/zookeeper/hwk");
		 System.out.println("从zk取到的数据是："+zkStr);
	}
	
	
	@Test
	public void testCount()
	{
		System.out.println(this.didongOrderDao.getCount());
	}
	
	
	@Test
	public void testMax()
	{
		System.out.println(this.didongOrderDao.getMax());
	}
	
	@Test
	public void testMin()
	{
		System.out.println(this.didongOrderDao.getMin());
	}
	
	@Test
	public void testOrderBy()
	{
		List<DidongOrder> list = this.didongOrderDao.getOrdersById();
		System.out.println(JSON.toJSON(list));
	}

}
