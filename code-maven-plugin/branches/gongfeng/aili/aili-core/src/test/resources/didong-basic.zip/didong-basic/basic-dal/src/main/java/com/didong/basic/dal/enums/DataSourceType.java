package com.didong.basic.dal.enums;

/**
 * 
 * @ClassName:DataSourceType
 * @author: 韩旺坤
 * @Description:数据源类型
 * @date:2015年10月11日 下午4:46:43
 */
public enum DataSourceType 
{
   COMMON_DS("common"),  //普通数据源
   XA_DS("xa");      //XA数据源
   
   private String type = null;
   private DataSourceType(String type)
   {
	   this.type = type;
   }
   
   public String toString()
   {
	   return type;
   }
}
