package com.didong.basic.dal.model;

import java.util.List;

/**
 * 
 * @ClassName:Module
 * @author: 韩旺坤
 * @Description:t_app_module
 * @date:2015年10月13日 下午11:36:16
 */
public class Module {
	private long id;
	/**
	 * 应用ID
	 */
	private long appId;
	/**
	 * 模块名称
	 */
	private String moduleName;
	/**
	 * 模块编码
	 */
	private String moduleCode;
    
	/**
	 * 对应参数列表
	 */
	private List<Parameter> params;
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getAppId() {
		return appId;
	}

	public void setAppId(long appId) {
		this.appId = appId;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public String getModuleCode() {
		return moduleCode;
	}

	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}

	public List<Parameter> getParams() {
		return params;
	}

	public void setParams(List<Parameter> params) {
		this.params = params;
	}

}
