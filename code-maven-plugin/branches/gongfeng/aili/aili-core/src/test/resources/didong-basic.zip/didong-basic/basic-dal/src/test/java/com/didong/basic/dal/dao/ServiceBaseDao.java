package com.didong.basic.dal.dao;

/**
 *  对数据库didong-service的基础操作
 * @author han
 *
 */
public interface ServiceBaseDao
{
	/**
	 * 
	 *  对序列的操作
	 */
	
	 /**
	  *  判断序列是否存在
	  * @param seqName
	  * @return
	  */
     public  boolean isExistSequence(String seqName);
     
     /**
      *  如果count=1，那么返回序列的下一个步长的值
      * @param seqName
      * @param count
      * @return
      */
     public  long getNextValue(String seqName,int count);
     
     /**
      *  根据序列名称及步长值，新增序列
      * @param seqName
      * @param step
      * @return
      */
     public boolean addNewSequence(String seqName,int step);
}
