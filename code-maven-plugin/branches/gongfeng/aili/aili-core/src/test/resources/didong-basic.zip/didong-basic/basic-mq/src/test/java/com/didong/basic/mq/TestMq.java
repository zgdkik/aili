package com.didong.basic.mq;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.didong.basic.mq.container.DidongMqContainer;
import com.didong.basic.mq.template.ActiveMQJmsTemplate;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:test_queue.xml")
public class TestMq extends AbstractJUnit4SpringContextTests 
{
    @Resource
    ActiveMQJmsTemplate jmsSender;
    @Resource
    DidongMqContainer jmsContainer;
	@Test
	public void test() throws Exception 
	{
	   //停止掉监听
	   jmsContainer.getListenerContainer().stop();
       for(int i=0;i<1000;i++)
       {
    	   StudentBean stu = new StudentBean();
    	   stu.setNo(i);
    	   stu.setAge(20+i);
    	   stu.setName("han"+i);
    	   
    	   if(i%2==0)
    	     this.jmsSender.syncSend(JSON.toJSONString(stu));
    	   else
    		 this.jmsSender.asynSend(JSON.toJSONString(stu));
       }
       //启动监听
       jmsContainer.getListenerContainer().start();
       //等待消息消费完毕
       while(true)
       {
    	   
       }
	}

}
