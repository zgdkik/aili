package com.didong.basic.sms;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.didong.app.sms.http.HttpUtil;
import com.didong.basic.tools.other.HttpInvoker;
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class SmsHuaXinTest extends AbstractJUnit4SpringContextTests 
{
    //短信模板：【递咚】验证码：@，请尽快完成操作，验证码有效时间5分钟，欢迎使用递咚！	
	@Resource
	HttpUtil httpUtil;
	@Resource
	HttpInvoker httpInvoker;
	@Test
	public void testSend验证码() throws Exception 
	{
        String url = "http://sh2.ipyy.com/smsJson.aspx";
		//String url = "http://localhost:8080/server-app-web/dispatchController.do";
        Map params = new HashMap();
//        params.put("userid", "1");
        params.put("account", "yhbcs1");     
        params.put("password", "yhbcs1");
        params.put("mobile", "13917386691");  
        params.put("content", "【递咚】您的验证码：10966");     
        params.put("action", "send");
//        params.put("extno", "didong");  
        
        System.out.println(httpInvoker.doPost(url, params));
                
	}
	
	@Test
	public void testSend接单通知() throws Exception 
	{
        String url = "http://139.196.30.223:8080/server-app-web/dispatchController.do";
		//String url = "http://localhost:8080/server-app-web/dispatchController.do";
        Map<String,String> params = new HashMap<String,String>();
        params.put("serviceId", "appTestService");
        Map<String,String> contentMap = new HashMap<String,String>();
        contentMap.put("mobile", "13917386691");
        contentMap.put("content", "【递咚】尊敬的货主：张惠，您好，你的快递:920500907805已由快递员：韩旺坤（手机13438454853） 为您派送，请注意查收，欢迎使用递咚http://dowload.com");
        params.put("parameter", JSON.toJSONString(contentMap));   
        
        System.out.println(httpInvoker.doPost(url, params));
                
	}
	
	
	@Test
	public void testMutliThread()
	{
		ThreadPoolTaskExecutor threadPool = null;
		threadPool = new ThreadPoolTaskExecutor();
		threadPool.setCorePoolSize(10);
		threadPool.setMaxPoolSize(50);
		threadPool.setDaemon(true);
		threadPool.setKeepAliveSeconds(120);
		threadPool.afterPropertiesSet();
		
        String url = "http://sh2.ipyy.com/smsJson.aspx";
		List<SendRunnable> taskList = new ArrayList<SendRunnable>();
		List<String> phoneList = new ArrayList<String>();
		phoneList.add("13917386691");
		phoneList.add("18516526096");		
		phoneList.add("13734906760");
		phoneList.add("13725570260");	
		phoneList.add("13661697467");
		phoneList.add("15221142224");	
		phoneList.add("18221350365");
		phoneList.add("15179634040");		
		phoneList.add("18001639091");
		phoneList.add("13761014147");	
		phoneList.add("13365893153");
		phoneList.add("13310166870");	
		phoneList.add("18516655467");
		for(int i=0;i<39;i++)
		{
			SendRunnable runnable = new SendRunnable();
			runnable.setHttpInvoker(httpInvoker);
	        Map params = new HashMap();
//	        params.put("userid", "1");
	        params.put("account", "yhbcs1");     
	        params.put("password", "yhbcs1");
	        params.put("mobile",phoneList.get(i%phoneList.size()) );  
	        params.put("content", "您的验证码：400"+i+"【递咚】");     
	        params.put("action", "send");
	        
	        runnable.setParams(params);
	        runnable.setUrl(url);
	        
	        //加入任务列表
	        taskList.add(runnable);
		}
		
		for(Runnable task:taskList)
		{
			threadPool.execute(task);
		}
		//等待线程执行完成
		while(true)
		{
			
		}
	}
	
}
