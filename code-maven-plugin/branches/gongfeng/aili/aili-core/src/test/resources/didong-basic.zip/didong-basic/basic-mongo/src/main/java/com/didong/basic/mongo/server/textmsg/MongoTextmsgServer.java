package com.didong.basic.mongo.server.textmsg;

import com.didong.basic.mongo.shared.constant.MongoConstants;
import com.didong.basic.mongo.shared.util.MongoDBUtil;
import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.Mongo;

/**
 * 系统名称：车辆运输跟踪系统（TTS）
 * 模块名称：
 * 模块描述：短信Mg数据库操作
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年11月18日 下午10:44:58
 * 模块路径：com.didong.basic.mongo.server.textmsg.MongoTextmsgServer
 * 更新记录：
 */
public class MongoTextmsgServer {
	
	/**
	 * 功能描述：将指定内容保存到Mg数据库中
	 * 模块作者：zouyong
	 * 开发时间：2015年11月18日 下午10:35:14
	 * 更新记录：
	 * 返回数据：boolean
	 * @param key 唯一值
	 * @param smsmessage 内容
	 */
	public boolean insertText(String key, String smsmessage) {
		
		// 连接[递咚-mg]数据库
		Mongo mongo = MongoDBUtil.getMongoInstanceByMgdb(
				MongoConstants.mgdbAdrs, MongoConstants.mgdbPort);
		DB db = mongo.getDB(MongoConstants.mgdbTableName);

		// 打开短信数据库表
		DBCollection smstb = db.getCollection(MongoConstants.smsTextTabName);

		BasicDBObject query = new BasicDBObject();
		query.put("smsmsgId", key);
		query.put("smsmessage", smsmessage);
		smstb.insert(query);
		
		return true;
	}

}
