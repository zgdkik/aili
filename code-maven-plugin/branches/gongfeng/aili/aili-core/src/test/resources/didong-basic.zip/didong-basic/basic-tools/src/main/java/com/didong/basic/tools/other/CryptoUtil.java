package com.didong.basic.tools.other;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.didong.basic.tools.encypt.BASE64Decoder;
import com.didong.basic.tools.encypt.BASE64Encoder;

/**
 * 系统名称：递咚APP-开发平台
 * 模块名称：
 * 模块描述：MD5加密方式工具类
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年11月28日 下午12:36:01
 * 模块路径：com.didong.basic.dal.util.CryptoUtil
 * 更新记录：
 */
public class CryptoUtil {

	private static final Log logger = LogFactory.getLog(CryptoUtil.class);

	public CryptoUtil() {
	}

	public static String base64Encode(byte bytes[]) {
		if (bytes == null){
			return "";
		} else {
			return (new BASE64Encoder()).encode(bytes);
		}
	}

	/**
	 * 功能描述：MD5加密并返回字符串
	 * 模块作者：zouyong
	 * 开发时间：2015年12月27日 下午7:29:24
	 * 更新记录：
	 * 返回数据：String
	 */
	public static String digestByMD5(String text) {
		if (text == null){
			return null;
		}
		byte digest[] = new byte[0];
		try {
			digest = md5(text.getBytes());
			return base64Encode(digest);
		} catch (NoSuchAlgorithmException e) {
			logger.error(e);
			throw new RuntimeException(e);
		}
	}

	private static byte[] md5(byte input[]) throws NoSuchAlgorithmException {
		MessageDigest alg = MessageDigest.getInstance("MD5");
		alg.update(input);
		byte digest[] = alg.digest();
		return digest;
	}

	/**
	 * 功能描述：Base64加密
	 * 模块作者：zouyong
	 * 开发时间：2015年12月27日 下午7:30:48
	 * 更新记录：
	 * 返回数据：String
	 */
	public static String digestByEncode(String text) {
		if (text == null){
			return null;
		}
		try {
			return base64Encode(text.getBytes());
		} catch (Exception e) {
			logger.error(e);
			throw new RuntimeException(e);
		}
	}

	/**
	 * 功能描述：Base64解密返回字符串
	 * 模块作者：zouyong
	 * 开发时间：2015年12月27日 下午7:30:48
	 * 更新记录：
	 * 返回数据：String
	 */
	public static String digestByDecode(String text) {

		byte[] bytes = base64Decode(text);
		try {
			if(null == bytes) {
				return null;
			}
			return new String(bytes, "UTF-8");
		} catch (Exception e) {
			logger.error(e);
			throw new RuntimeException(e);
		}
	}
	
	/**
	 * 功能描述：Base64解密返回字符数组
	 * 模块作者：zouyong
	 * 开发时间：2015年12月27日 下午7:41:56
	 * 更新记录：
	 * 返回数据：byte[]
	 */
	public static byte[] base64Decode(String pwd) {
		if (null != pwd && !"".equals(pwd)) {
			try {
				return new BASE64Decoder().decodeBuffer(pwd);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		String test = "测试100";
		System.out.println("被加密字符：" + test);
		// md5加密
		String md5Str = digestByMD5(test);
		System.out.println("md5加密：" + md5Str);
		
		// Base64加密
		String encode = digestByEncode(test);
		System.out.println("Base64加密：" + encode);
		
		// Base64解密
		String decode = digestByDecode(encode);
		System.out.println("Base64解密：" + decode);
	}

}
