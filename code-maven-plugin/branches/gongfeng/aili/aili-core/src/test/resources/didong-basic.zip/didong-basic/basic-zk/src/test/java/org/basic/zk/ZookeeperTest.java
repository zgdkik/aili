
package org.basic.zk;

import javax.annotation.Resource;

import org.apache.curator.framework.recipes.locks.InterProcessMutex;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.didong.basic.zk.manage.ZkReader;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:zk.xml")
public class ZookeeperTest extends AbstractJUnit4SpringContextTests 
{
	@Resource
	ZkReader zkReader;
	@Test
	public void testDistLock() throws Exception
	{
		InterProcessMutex lock = this.zkReader.getZkMgr().getDistLock("/didong/lock");
		lock.acquire();
		System.out.println("xxxxxx");
		lock.release();
		this.zkReader.getZkMgr();
	}

}