package com.didong.basic.mq.template;

import javax.jms.Destination;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.jms.core.JmsTemplate;

import com.didong.basic.mq.connection.DidongConnectionFactory;
import com.didong.basic.mq.convert.ByteMessage2String;
import com.didong.basic.mq.thread.SendMessageRunnable;
import com.didong.basic.tools.other.MessageCompressUtil;
import com.didong.basic.tools.other.ThreadUtil;

/**
 * 
 * @ClassName:ActiveMQJmsTemplate
 * @author: 韩旺坤
 * @Description:发送消息时，不开启事务，加速发送过程
 * @date:2015年11月12日 下午7:28:43
 */
public class ActiveMQJmsTemplate implements DidongJmsTemplate,InitializingBean
{
    private JmsTemplate jmsTemplate;
    private ThreadUtil threadUtil;
    //如果确定要把消息进行压缩，那么就需要这个消息转换对象
    private ByteMessage2String converter;

    //连接工厂
    private DidongConnectionFactory didongConnectionFactory;
	@Override
	public void asynSend(String jsonMessage)
	{
	   //创建任务
	   SendMessageRunnable runnable = new SendMessageRunnable();
	   runnable.setJmsTemplate(jmsTemplate);
	   runnable.setJsonMessage(jsonMessage);
	   //使用线程池执行，无返回结果
       this.threadUtil.executeRunnable(runnable);
	}

	@Override
	public boolean syncSend(String jsonMessage)
	{
		this.jmsTemplate.convertAndSend(jsonMessage);
		return true;
	}

	
	// 相关属性及其set,get方法

	// 发送超时时间
	private int receiveTimeout;
	// 会话模式
	private int sessionAcknowledgeMode;
	// 消息存活时间，单位:ms
	private int timeToLive;
	// 消息发送模式
	private int deliveryMode;
	// 队列名
	private Destination queueName;
	// 是否压缩
    private boolean isCompress;
    
	public void setIsCompress(boolean isCompress) {
		this.isCompress = isCompress;
	}

	public ThreadUtil getThreadUtil() {
		return threadUtil;
	}

	public void setThreadUtil(ThreadUtil threadUtil) {
		this.threadUtil = threadUtil;
	}

	public Destination getQueueName() {
		return queueName;
	}

	public void setQueueName(Destination queueName) {
		this.queueName = queueName;
	}

	public void setDidongConnectionFactory(
			DidongConnectionFactory didongConnectionFactory) {
		this.didongConnectionFactory = didongConnectionFactory;
	}

	public int getReceiveTimeout() {
		return receiveTimeout;
	}

	public void setReceiveTimeout(int receiveTimeout) {
		this.receiveTimeout = receiveTimeout;
	}

	public int getSessionAcknowledgeMode() {
		return sessionAcknowledgeMode;
	}

	public void setSessionAcknowledgeMode(int sessionAcknowledgeMode) {
		this.sessionAcknowledgeMode = sessionAcknowledgeMode;
	}

	public int getTimeToLive() {
		return timeToLive;
	}

	public void setTimeToLive(int timeToLive) {
		this.timeToLive = timeToLive;
	}

	public int getDeliveryMode() {
		return deliveryMode;
	}

	public void setDeliveryMode(int deliveryMode) {
		this.deliveryMode = deliveryMode;
	}

	@Override
	public void afterPropertiesSet() throws Exception
	{		
		//1、创建发送模板
		this.jmsTemplate = new JmsTemplate();
		this.jmsTemplate.setConnectionFactory(this.didongConnectionFactory.getSpringConnectionFactory());
		this.jmsTemplate.setReceiveTimeout(receiveTimeout);
		this.jmsTemplate.setSessionAcknowledgeMode(sessionAcknowledgeMode);
		this.jmsTemplate.setTimeToLive(timeToLive);
		this.jmsTemplate.setDeliveryMode(deliveryMode);
		this.jmsTemplate.setDefaultDestination(queueName);
		
		//2、创建消息转换类，需要时使用
		if(this.isCompress)
		{
			this.converter = new ByteMessage2String();
			this.converter.setMessageCompressUtil(new MessageCompressUtil<String>());
			this.jmsTemplate.setMessageConverter(converter);
		}
		
		this.jmsTemplate.afterPropertiesSet();		
		
	}

	@Override
	public JmsTemplate getJmsTemplate()
	{
		return this.jmsTemplate;
	}

}
