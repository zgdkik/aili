package com.didong.basic.message_push;

import cn.jpush.api.JPushClient;
import cn.jpush.api.common.APIConnectionException;
import cn.jpush.api.common.APIRequestException;
import cn.jpush.api.push.PushResult;
import cn.jpush.api.push.model.Message;
import cn.jpush.api.push.model.Options;
import cn.jpush.api.push.model.Platform;
import cn.jpush.api.push.model.PushPayload;
import cn.jpush.api.push.model.audience.Audience;
import cn.jpush.api.push.model.notification.IosNotification;
import cn.jpush.api.push.model.notification.Notification;

/**
 * Jpush消息推送工具类
 * @author 戴智青
 * @data 2015年10月31日 下午10:36:16
 */
public class JPushUtil {
	/**
	 * 应用信息
	 */
	private static final String APP_KEY = "2facc010c50c6c50699c9bfe";
	private static final String MASTER_SECRET = "ead7bd87dd2171c02a4e52d4";
	
	/**
	 * 
	 * TODO(发送PushPayload 对象) : 需要构建PushPayload 对象，不同的PushPayload对象会产生不同的结果
	 * @Title: sendNotice
	 * @return void
	 * @Exception
	 */
	public static void sendNotice(PushPayload payload) throws APIConnectionException , APIRequestException{
		JPushClient jpushClient = new JPushClient(MASTER_SECRET, APP_KEY, 3);
		PushResult result = jpushClient.sendPush(payload);
        
        System.out.println(result);
//        try {
//            
//        } 
//        catch (APIConnectionException e) {
//            // Connection error, should retry later
//        	System.err.println("Connection error, should retry later"+e);
//
//        } catch (APIRequestException e) {
//            // Should review the error, and fix the request
//            System.err.println("Should review the error, and fix the request");
//            System.err.println("HTTP Status: " + e.getStatus());
//            System.err.println("Error Code: " + e.getErrorCode());
//            System.err.println("Error Message: " + e.getErrorMessage());
//        }
	}
	 /**
	  * @Title: buildPushObject_all_all_alert
	  * @Description: 广播--"发送给所有人"
	  * @return PushPayload
	  * @Exception
	  */
     public static PushPayload buildPushObject_all_all_alert(String alertMsg) {
    	 	return PushPayload.alertAll(alertMsg);
     }
     /**
      * 
      * @Title: buildPushObject_all_message
      * @Description: 发送消息给所有人
      * @return PushPayload
      * @Exception
      */
     public static PushPayload buildPushObject_all_message(String msg){
    	 return PushPayload.messageAll(msg);
     }
	 /**
	  * 
	  * @Title: buildPushObject_android_tag_MessageTitle
	  * @Description: 推送消息到指定的TAG用户
	  * @return PushPayload
	  * @Exception
	  */
     public static PushPayload buildPushObject_android_tag_MessageTitle(String TAG) {
	        return PushPayload.newBuilder()
	                .setPlatform(Platform.android())
	                .setAudience(Audience.tag(new String[]{TAG}))
	                .setMessage(Message.newBuilder()
	                        .setMsgContent("消息的正文····")
	                        .addExtra("from", "JPush")//添加的参数
	                        .build())
	                .build();

	  }
 	/**
 	 * 
 	 * TODO(推送Notification到Android平台)
 	 * @Title: buildPushObject_android_tag_alertWithTitle
 	 * @Description: TODO
 	 * @return PushPayload
 	 * @Exception
 	 */
 	 public static PushPayload buildPushObject_android_tag_alertWithTitle(String TAG,String content,String title) {
 	        return PushPayload.newBuilder()
 	                .setPlatform(Platform.android())
 	                .setAudience(Audience.tag(new String[]{TAG}))
 	                .setNotification(Notification.android(content, title, null))
 	                .build();
 	  }
     /**
      * 构建推送对象：所有平台，推送目标是别名为 "alias"，通知内容为 alertMsg。
      * @param alias
      * @param alertMsg
      * @return
      */
     public static PushPayload buildPushObject_all_alias_alert(String alias , String alertMsg ) {
         return PushPayload.newBuilder()
                 .setPlatform(Platform.all())
                 .setAudience(Audience.alias(alias))
                 .setNotification(Notification.alert(alertMsg))
                 .build();
     }
     
     public static void main(String[] args) throws Exception {
		JPushUtil.sendNotice(JPushUtil.buildPushObject_all_all_alert("Hello Didong"));
	}
}
