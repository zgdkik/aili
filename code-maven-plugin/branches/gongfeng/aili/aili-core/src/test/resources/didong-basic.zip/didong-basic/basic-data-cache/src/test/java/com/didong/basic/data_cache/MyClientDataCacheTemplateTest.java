
package com.didong.basic.data_cache;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.AbstractJUnit4SpringContextTests;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.alibaba.fastjson.JSON;
import com.didong.basic.data_cache.bean.TestCacheBean;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations="classpath:applicationContext.xml")
public class MyClientDataCacheTemplateTest extends AbstractJUnit4SpringContextTests 
{
	@Resource
	MyClientDataCacheTemplate myClientDataCacheTemplate;
	@Test
	public void testTempData() throws Exception 
	{
       //以短信验证码为例
	   String mobileNo = "13917386691";
	   String type = "SMS-"+mobileNo;
	   String data = "10086"; //验证码的内容，有效时间60秒
	   this.myClientDataCacheTemplate.setTempData(type, data, 60);
	   System.out.println(this.myClientDataCacheTemplate.getTempData(type));
	   //让线程等待60秒
	   Thread.sleep(60*1000);
	   System.out.println(this.myClientDataCacheTemplate.getTempData(type));
	}
	
	
	@Test
	public void testKeyValue()
	{
		String type="TEST_VALUE";
		TestCacheBean value = this.myClientDataCacheTemplate.getCacheData(type, null, TestCacheBean.class);
		System.out.println("KEY_VALUE:"+JSON.toJSONString(value));
	}
	
	
	@Test
	public void testKeySet()
	{
		String type = "TEST_SET";
		List<TestCacheBean> list = this.myClientDataCacheTemplate.getCacheDataList(type, null, TestCacheBean.class);
		System.out.println("KEY_SET:"+JSON.toJSONString(list));
	}
	
	
	@Test
	public void testKeyHashOne()
	{
		String type="TEST_HASH_ONE";
		Map<String,String> param = new HashMap<String,String>();
		param.put("pwd", "123456");
		param.put("userName", "hanwangkun");
		TestCacheBean value = this.myClientDataCacheTemplate.getCacheData(type, param, TestCacheBean.class);
		System.out.println("KEY_HASH_ONE:"+JSON.toJSONString(value));
	}
	
	
	@Test
	public void testKeyHashMul()
	{
		String type = "TEST_HASH_MUL";
		Map<String,String> param = new HashMap<String,String>();
		param.put("pwd", "123456");
		List<TestCacheBean> list = this.myClientDataCacheTemplate.getCacheDataList(type, param, TestCacheBean.class);
		System.out.println("KEY_HASH_MUL:"+JSON.toJSONString(list));
	}
	
	
	@Test
	public void testDistLock()
	{
		
	}

}