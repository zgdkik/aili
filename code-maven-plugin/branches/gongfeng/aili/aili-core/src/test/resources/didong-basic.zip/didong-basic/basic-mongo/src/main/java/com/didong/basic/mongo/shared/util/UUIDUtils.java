package com.didong.basic.mongo.shared.util;

import java.util.UUID;

/**
 * 系统名称：快递收/送件平台-递咚App
 * 模块名称：
 * 模块描述：
 * 功能列表：
 * 模块作者：zouyong
 * 开发时间：2015年10月31日 上午11:53:21
 * 模块路径：com.didong.basic.mongo.shared.util.UUIDUtils
 * 更新记录：
 */
public class UUIDUtils {

	/**
	 * 
	 * 通过jdk自带的uuid生成器生成36位的uuid；
	 * @author zhengwl
	 * @date 2012-10-17 上午11:43:55
	 */
	public static String getUUID() {
		// 使用JDK自带的UUID生成器
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
}
