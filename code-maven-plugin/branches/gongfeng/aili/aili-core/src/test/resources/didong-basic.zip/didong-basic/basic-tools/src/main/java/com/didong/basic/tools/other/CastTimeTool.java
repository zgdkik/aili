package com.didong.basic.tools.other;

public class CastTimeTool
{
  private static long startTime;
  public static void start(){
    startTime = System.currentTimeMillis();
  }
  public static long cast(){
    return (System.currentTimeMillis()-startTime);
  }
}
