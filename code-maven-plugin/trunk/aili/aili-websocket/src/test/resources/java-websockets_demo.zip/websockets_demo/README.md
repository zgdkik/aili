websocket demo
本地测试能够使用

jdk：1.7.0_45
tomcat :7.0.52（lib下有tomcat7对websocket支持的jar）
http://www.oschina.net/translate/java-ee-html5-websocket-example


2013-03-03
本地jdk 1.7.03 tomcat：7.0.52也能使用
chat页面下 修改ws://localhost:8080/chat 修改为本地ip 实现局域网聊天