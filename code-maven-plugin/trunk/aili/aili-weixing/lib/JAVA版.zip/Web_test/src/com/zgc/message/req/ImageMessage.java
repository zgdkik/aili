package com.zgc.message.req;


/*
 * ͼƬ��Ϣ
 * @author zhangguangchao	
 * @date 2013-07-17
 * */
public class ImageMessage extends BaseMessage{

	private String PicUrl;  
	  
    public String getPicUrl() {  
        return PicUrl;  
    }  
  
    public void setPicUrl(String picUrl) {  
        PicUrl = picUrl;  
    }  
	
}
