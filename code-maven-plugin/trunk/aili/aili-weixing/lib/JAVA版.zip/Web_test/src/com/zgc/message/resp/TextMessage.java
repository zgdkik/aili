package com.zgc.message.resp;

/** 
 * �ı���Ϣ 
 *  
 * @author zhangguangchao	 
 * @date 2013-07-17 
 */  
public class TextMessage extends BaseMessage {  
    // �ظ�����Ϣ����  
    private String Content;  
  
    public String getContent() {  
        return Content;  
    }  
  
    public void setContent(String content) {  
        Content = content;  
    }  
}  
